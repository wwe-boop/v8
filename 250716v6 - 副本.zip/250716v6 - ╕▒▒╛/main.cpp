#include <stdio.h>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <string.h>
#include <time.h>
#include "git_master/src/keyword-spotter.h"

const int MONO_2S_SHORT_LEN = 32000;

using namespace kws2k2_faith;

int fsize(FILE *fp){
    int n;
    fpos_t fpos; //当前位置
    fgetpos(fp, &fpos); //获取当前位置
    fseek(fp, 0, SEEK_END);
    n = ftell(fp);
    fsetpos(fp,&fpos); //恢复之前的位置
    return n;
}

int remove_wav_header(FILE *file_wav) {
    int i;
    int headsize;
    char data[256];
    fread(data, sizeof(char), sizeof(data), file_wav);
    //非pcm文件
    if (strncmp(data, "RIFF", 4) != 0 || strncmp(data + 8, "WAVEfmt", 7) != 0) {
        return 0;
    }
    //查找data标志
    for (i = 0; i < sizeof(data) - 4; i++) {
        if ('d' == data[i] && 'a' == data[i + 1] && 't' == data[i + 2] && 'a' == data[i + 3]) {
            break;
        }
    }
    if (i >= sizeof(data) - 1) {
        printf("错误：wav头中未找到data字节\n");
        return -1;
    }
    headsize = i;
    headsize += 4; // data
    headsize += 4; // len

    //跳过wav文件头
    fseek(file_wav, headsize, SEEK_SET);
    return headsize;
}

char TEST_LIST_FILE[512] = "./test_file.txt";
int main(int32_t argc, char *argv[]) {
    if (argc > 1) {
        memset(TEST_LIST_FILE, 0, sizeof(TEST_LIST_FILE));
        memcpy(TEST_LIST_FILE, argv[1], strlen(argv[1]));
    }
    // 读测试序列
    char cmdString[300];
    char wav_filename[1024];
    short in_short[32000] = { 0 };
    std::string filename;
    int length = 0;
    int ret;
    int cnt_success = 0;
    int cnt = 0;
    FILE *testList = fopen(TEST_LIST_FILE, "r");
    if (0 == testList) {
        printf("can not open list file:%s!\n", TEST_LIST_FILE);
    }
    while (!feof(testList)) {
        if (0 == fgets(cmdString, sizeof(cmdString) - 1, testList)) {
            break;
        }
        if (cmdString[0] == '#') {
            break;
        }
        ret = sscanf(cmdString, "%[^\n]", wav_filename);
        printf("%s\n", wav_filename);
        filename = wav_filename;
        FILE* fp = fopen(wav_filename, "r");
        if (fp != nullptr) {
            length = fsize(fp);
            if (filename.find(".wav") != std::string::npos) {
                //fread(in_short, 22, sizeof(short), fp);
                remove_wav_header(fp);
                fread(in_short, MONO_2S_SHORT_LEN, sizeof(short), fp);
            }else{
                fread(in_short, MONO_2S_SHORT_LEN, sizeof(short), fp);
            }
            fclose(fp);
        } else {
            printf("can not open pcm file:%s\n", wav_filename);
        }
        std::time_t start = time(nullptr); // 获取当前时间的 time_t 表示
        long long start_timestamp = start * 1000; // 转换为毫秒级的时间戳

        int max_active_paths = 10;
        int num_tailing_blanks = 8;
        float keywords_score = 1.0;
        float keywords_threshold = 0.1;

        const std::string lexiconPath = "git_master/model/";

        KeywordSpotterConfig config(max_active_paths, num_tailing_blanks, keywords_score, keywords_threshold, lexiconPath); // 输入配置
        std::vector<KeywordResult> results(1); // 输出

        printf("%s\n",config.ToString().c_str());
        cnt++;
        KeywordSpotter keyword_spotter; // 主类
        // ret = keyword_spotter.Process(in_short, 32000, config, &results); // 运行函数
        ret = keyword_spotter.KwsInit(config);
        if (ret != 0) {
            printf("kws2k2 init err\n");
        }
        ret  = keyword_spotter.Process(in_short, 32000, config, &results);
        if (ret != 0) {
            printf("kws2k2 KwsDestory err\n");
        }
        ret = keyword_spotter.KwsDestory();
        if (ret != 0) {
            printf("kws2k2 KwsDestory err\n");
        }
        
        int res = 0;
        printf("zxw 0113 results[0].keyword === %s\n", results[0].keyword.c_str());
        if (!results[0].keyword.empty()) {
            cnt_success++;
            res = 1;
#if 0
            char fn[300], *p, out_pcm[256]="out_pcm/";
            strcpy(fn, (p = strrchr(wav_filename, '/')) ? p + 1 : wav_filename); //去除路径的文件名
            strcat(out_pcm, fn);
            printf("out:%s\n", out_pcm);
            FILE *fpWrite = fopen(out_pcm,"wb");
            fwrite(in_short, 32000, 2, fpWrite);
            fclose(fpWrite);
#endif
        }
        std::time_t end = time(nullptr); // 获取当前时间的 time_t 表示
        long long end_timestamp = end * 1000; // 转换为毫秒级的时间戳
        printf("use time: %lld, cnt_success=%d\n", end_timestamp - start_timestamp, cnt_success);
        printf("wav_filename:%s res:%d\n", wav_filename, res);
        // exit(0);
    }
    printf("cnt_success/cnt = %d/%d\n",cnt_success, cnt);
    printf("all_cnt:%d\n",cnt_success);
    
    FILE *fplog = fopen("logs/result.txt","a");
    fprintf(fplog,"%s %d\n", TEST_LIST_FILE, cnt_success);
    fclose(fplog);
}
