/**
 * @file iva_fft_adapter.cpp
 * @brief IVA的FFT适配器实现，封装iMedia FFT功能
 */

#include "iva_fft_adapter.h"
#include "../imedia_fft.h"
#include "../alg_log.h"

#include <vector>
#include <cstring>
#include <cmath>

#define LOG_TAG "IVA_FFT_ADAPTER"

namespace kws2k2_faith {

// Global state for FFT adapter
static struct {
    bool initialized;
    int fft_size;
    std::vector<float> work_buffer;
} g_fft_state = {false, 0, {}};

int iva_fft_init(int fft_size) {
    if (g_fft_state.initialized) {
        ALG_LOGE("FFT adapter already initialized");
        if (g_fft_state.fft_size == fft_size) {
            return 0;  // Same size, no need to reinitialize
        } else {
            // Different size, need to reinitialize
            iva_fft_destroy();
        }
    }
    
    // Validate FFT size (must be power of 2)
    if (fft_size <= 0 || (fft_size & (fft_size - 1)) != 0) {
        ALG_LOGE("Invalid FFT size: %d (must be power of 2)", fft_size);
        return -1;
    }
    
    g_fft_state.fft_size = fft_size;
    
    // Allocate work buffer for iMedia FFT
    // iMedia_K2NS_common_FFT expects real data format
    g_fft_state.work_buffer.resize(fft_size);
    
    g_fft_state.initialized = true;
    
    ALG_LOGI("FFT adapter initialized with size %d", fft_size);
    return 0;
}

int iva_fft_forward(const std::complex<float>* time_in,
                    std::complex<float>* freq_out,
                    int fft_size) {
    if (!g_fft_state.initialized) {
        ALG_LOGE("FFT adapter not initialized");
        return -1;
    }

    if (fft_size != g_fft_state.fft_size) {
        ALG_LOGE("FFT size mismatch: expected %d, got %d", g_fft_state.fft_size, fft_size);
        return -1;
    }

    if (!time_in || !freq_out) {
        ALG_LOGE("Null pointer in FFT forward");
        return -1;
    }

    // For complex input, we need to handle real and imaginary parts separately
    // Since iMedia FFT only supports real FFT, we'll use a workaround
    float* work_buf = g_fft_state.work_buffer.data();

    // Extract real part and do real FFT
    for (int i = 0; i < fft_size; ++i) {
        work_buf[i] = time_in[i].real();
    }

    // Call iMedia real FFT
    iMedia_K2NS_common_FFT(static_cast<IMEDIA_INT16>(fft_size), work_buf);

    // Convert packed real FFT output to complex format
    // iMedia real FFT output format: [R[0], R[n/2], R[1], I[1], R[2], I[2], ...]
    freq_out[0] = std::complex<float>(work_buf[0], 0.0f);  // DC component
    freq_out[fft_size/2] = std::complex<float>(work_buf[1], 0.0f);  // Nyquist component

    for (int i = 1; i < fft_size/2; ++i) {
        freq_out[i] = std::complex<float>(work_buf[2*i], work_buf[2*i+1]);
        freq_out[fft_size-i] = std::complex<float>(work_buf[2*i], -work_buf[2*i+1]); // Conjugate symmetry
    }

    return 0;
}

int iva_fft_inverse(const std::complex<float>* freq_in,
                    std::complex<float>* time_out,
                    int fft_size) {
    if (!g_fft_state.initialized) {
        ALG_LOGE("FFT adapter not initialized");
        return -1;
    }

    if (fft_size != g_fft_state.fft_size) {
        ALG_LOGE("FFT size mismatch: expected %d, got %d", g_fft_state.fft_size, fft_size);
        return -1;
    }

    if (!freq_in || !time_out) {
        ALG_LOGE("Null pointer in FFT inverse");
        return -1;
    }

    // Convert complex frequency domain to packed real format for iMedia IFFT
    float* work_buf = g_fft_state.work_buffer.data();

    // Pack frequency domain data in iMedia format: [R[0], R[n/2], R[1], I[1], R[2], I[2], ...]
    work_buf[0] = freq_in[0].real();  // DC component (should be real)
    work_buf[1] = freq_in[fft_size/2].real();  // Nyquist component (should be real)

    for (int i = 1; i < fft_size/2; ++i) {
        work_buf[2*i] = freq_in[i].real();
        work_buf[2*i+1] = freq_in[i].imag();
    }

    // Call iMedia real IFFT
    iMedia_K2NS_common_IFFT(static_cast<IMEDIA_INT16>(fft_size), work_buf);

    // Convert real output to complex format (imaginary parts are zero)
    for (int i = 0; i < fft_size; ++i) {
        time_out[i] = std::complex<float>(work_buf[i] * 2.0f / fft_size, 0.0f);  // Apply scaling for consistency
    }

    return 0;
}

int iva_fft_destroy() {
    if (!g_fft_state.initialized) {
        return 0;
    }
    
    g_fft_state.work_buffer.clear();
    g_fft_state.fft_size = 0;
    g_fft_state.initialized = false;
    
    ALG_LOGI("FFT adapter destroyed");
    return 0;
}

int iva_rfft_forward(const float* real_in,
                     std::complex<float>* complex_out,
                     int fft_size) {
    if (!g_fft_state.initialized) {
        ALG_LOGE("FFT adapter not initialized");
        return -1;
    }

    if (fft_size != g_fft_state.fft_size) {
        ALG_LOGE("FFT size mismatch: expected %d, got %d", g_fft_state.fft_size, fft_size);
        return -1;
    }

    if (!real_in || !complex_out) {
        ALG_LOGE("Null pointer in RFFT forward");
        return -1;
    }

    // Copy real input to work buffer
    float* work_buf = g_fft_state.work_buffer.data();
    for (int i = 0; i < fft_size; ++i) {
        work_buf[i] = real_in[i];
    }

    // Call iMedia real FFT
    iMedia_K2NS_common_FFT(static_cast<IMEDIA_INT16>(fft_size), work_buf);

    // Convert packed real FFT output to complex format
    complex_out[0] = std::complex<float>(work_buf[0], 0.0f);  // DC component
    complex_out[fft_size/2] = std::complex<float>(work_buf[1], 0.0f);  // Nyquist component

    for (int i = 1; i < fft_size/2; ++i) {
        complex_out[i] = std::complex<float>(work_buf[2*i], work_buf[2*i+1]);
        complex_out[fft_size-i] = std::complex<float>(work_buf[2*i], -work_buf[2*i+1]); // Conjugate symmetry
    }

    return 0;
}

int iva_rifft_inverse(const std::complex<float>* complex_in,
                      float* real_out,
                      int fft_size) {
    if (!g_fft_state.initialized) {
        ALG_LOGE("FFT adapter not initialized");
        return -1;
    }

    if (fft_size != g_fft_state.fft_size) {
        ALG_LOGE("FFT size mismatch: expected %d, got %d", g_fft_state.fft_size, fft_size);
        return -1;
    }

    if (!complex_in || !real_out) {
        ALG_LOGE("Null pointer in RIFFT inverse");
        return -1;
    }

    // Convert complex frequency domain to packed real format for iMedia IFFT
    float* work_buf = g_fft_state.work_buffer.data();

    // Pack frequency domain data in iMedia format
    work_buf[0] = complex_in[0].real();  // DC component
    work_buf[1] = complex_in[fft_size/2].real();  // Nyquist component

    for (int i = 1; i < fft_size/2; ++i) {
        work_buf[2*i] = complex_in[i].real();
        work_buf[2*i+1] = complex_in[i].imag();
    }

    // Call iMedia real IFFT
    iMedia_K2NS_common_IFFT(static_cast<IMEDIA_INT16>(fft_size), work_buf);

    // Copy real output with scaling
    for (int i = 0; i < fft_size; ++i) {
        real_out[i] = work_buf[i] * 2.0f / fft_size;
    }

    return 0;
}

} // namespace kws2k2_faith
