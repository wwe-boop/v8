/**
 * @file auxiva_cpp.cpp
 * @brief AuxIVA算法的纯C++实现
 */

#include "auxiva_cpp.h"
#include "../imedia_common_basic_op.h"
#include "../alg_log.h"
#include <cmath>
#include <algorithm>
#include <random>

namespace kws2k2_faith {

/**
 * @brief 初始化AuxIVA处理器
 *
 * 验证配置参数，分配内存缓冲区，初始化解混矩阵为单位矩阵
 */
int AuxIVAProcessor::Initialize(const AuxIVAConfig& config) {
    config_ = config;

    // 验证配置参数
    if (config_.num_sources <= 0 || config_.num_channels <= 0 ||
        config_.freq_bins <= 0) {
        ALG_LOGE("Invalid AuxIVA configuration: sources=%d, channels=%d, freq_bins=%d",
                 config_.num_sources, config_.num_channels, config_.freq_bins);
        return -1;
    }

    // 允许初始化时时间帧为零(将在处理过程中设置)
    if (config_.time_frames < 0) {
        ALG_LOGE("Invalid time frames: %d", config_.time_frames);
        return -1;
    }

    if (config_.num_sources > config_.num_channels) {
        ALG_LOGE("Number of sources (%d) cannot exceed number of channels (%d)",
                 config_.num_sources, config_.num_channels);
        return -1;
    }

    // 分配解混矩阵 [频率][源][通道]
    demixing_matrices_.resize(config_.freq_bins);
    for (int f = 0; f < config_.freq_bins; f++) {
        demixing_matrices_[f].resize(config_.num_sources);
        for (int s = 0; s < config_.num_sources; s++) {
            demixing_matrices_[f][s].resize(config_.num_channels);
        }
    }

    // 分配工作缓冲区
    temp_matrix_.resize(config_.num_channels);
    for (int i = 0; i < config_.num_channels; i++) {
        temp_matrix_[i].resize(config_.num_channels);
    }

    source_powers_.resize(config_.num_sources);
    source_models_.resize(config_.num_sources);
    for (int s = 0; s < config_.num_sources; s++) {
        source_models_[s].resize(config_.time_frames);
    }

    InitializeDemixingMatrices();

    initialized_ = true;
    ALG_LOGI("AuxIVA processor initialized: %d sources, %d channels, %d freq bins",
             config_.num_sources, config_.num_channels, config_.freq_bins);

    return 0;
}

/**
 * @brief 初始化解混矩阵为单位矩阵
 *
 * 将所有频率箱的解混矩阵初始化为单位矩阵，提供算法迭代的中性起点
 */
void AuxIVAProcessor::InitializeDemixingMatrices() {
    // 将解混矩阵W初始化为单位矩阵
    for (int i = 0; i < config_.freq_bins; i++) {
        for (int n = 0; n < config_.num_sources; n++) {
            for (int m = 0; m < config_.num_channels; m++) {
                Complex val = (n == m) ? Complex(1.0f, 0.0f) : Complex(0.0f, 0.0f);
                demixing_matrices_[i][n][m] = val;
            }
        }
    }
}

/**
 * @brief 执行AuxIVA盲源分离处理
 *
 * 对输入的频域多通道信号执行完整的AuxIVA算法，包括迭代更新解混矩阵、
 * 源模型估计、归一化处理和反投影校正
 */
int AuxIVAProcessor::Process(const ComplexTensor& input, ComplexTensor& output) {
    if (!initialized_) {
        ALG_LOGE("AuxIVA processor not initialized");
        return -1;
    }

    // 验证输入维度
    if (input.size() != static_cast<size_t>(config_.freq_bins) ||
        input[0].size() != static_cast<size_t>(config_.time_frames) ||
        input[0][0].size() != static_cast<size_t>(config_.num_channels)) {
        ALG_LOGE("Invalid input dimensions");
        return -1;
    }

    // 调整输出大小
    output.resize(config_.freq_bins);
    for (int f = 0; f < config_.freq_bins; f++) {
        output[f].resize(config_.time_frames);
        for (int t = 0; t < config_.time_frames; t++) {
            output[f][t].resize(config_.num_sources);
        }
    }
    
    // 初始化：计算初始分离源和源模型
    ApplyDemixing(input, output);
    UpdateSourceModels(output);

    // 保存前一次迭代的解混矩阵用于收敛检查
    ComplexTensor prev_demixing_matrices;

    // 主迭代循环
    for (int iter = 0; iter < config_.max_iterations; iter++) {
        // 保存当前解混矩阵用于收敛检查
        if (iter > 0) {  // 从第二次迭代开始检查收敛
            prev_demixing_matrices = demixing_matrices_;
        }

        // 步骤1: 更新源模型 R
        UpdateSourceModels(output);

        // 步骤2: 按频率bin更新解混矩阵（匹配主目录 iva 的顺序）
        for (int f = 0; f < config_.freq_bins; f++) {
            for (int s = 0; s < config_.num_sources; s++) {
                // 为每个频率和源更新解混向量
                UpdateDemixingMatrixFreqSource(f, s, input[f]);
            }
        }

        // 步骤3: 应用解混矩阵得到新的分离源
        ApplyDemixing(input, output);

        // 步骤4: 归一化处理
        if (config_.normalize_demixing) {
            NormalizeDemixingMatrices();
            // 归一化后重新计算分离源
            ApplyDemixing(input, output);
        }

        // 步骤5: 收敛性检查
        if (config_.use_convergence_check && iter > 0 && CheckConvergence(prev_demixing_matrices, config_.convergence_threshold)) {
            ALG_LOGI("AuxIVA converged after %d iterations", iter + 1);
            break;
        }
    }
    
    // Apply demixing to get separated sources
    ComplexTensor temp_separated;
    temp_separated.resize(config_.freq_bins);
    for (int f = 0; f < config_.freq_bins; f++) {
        temp_separated[f].resize(config_.time_frames);
        for (int t = 0; t < config_.time_frames; t++) {
            temp_separated[f][t].resize(config_.num_sources);
        }
    }

    ApplyDemixing(input, temp_separated);

    // Apply back projection for amplitude correction
    ApplyBackProjection(temp_separated, input, 0, output);

    return 0;
}

/**
 * @brief 应用解混矩阵进行源分离
 *
 * 将学习到的解混矩阵应用于输入信号，计算分离后的源信号
 * y_s(f,t) = sum_c W_s,c(f) * x_c(f,t)
 */
void AuxIVAProcessor::ApplyDemixing(const ComplexTensor& input, ComplexTensor& output) {
    for (int f = 0; f < config_.freq_bins; f++) {
        for (int t = 0; t < config_.time_frames; t++) {
            for (int s = 0; s < config_.num_sources; s++) {
                output[f][t][s] = Complex(0.0f, 0.0f);

                // y_s(f,t) = sum_c W_s,c(f) * x_c(f,t)
                for (int c = 0; c < config_.num_channels; c++) {
                    output[f][t][s] += demixing_matrices_[f][s][c] * input[f][t][c];
                }
            }
        }
    }
}

void AuxIVAProcessor::ApplyBackProjection(const ComplexTensor& separated_sources,
                                        const ComplexTensor& original_input,
                                        int ref_mic_index,
                                        ComplexTensor& corrected_output) {

    // 参数有效性检查
    if (ref_mic_index < 0 || ref_mic_index >= config_.num_channels) {
        ALG_LOGE("Invalid reference microphone index: %d", ref_mic_index);
        // 回退到简单复制
        for (int f = 0; f < config_.freq_bins; f++) {
            for (int t = 0; t < config_.time_frames; t++) {
                for (int s = 0; s < config_.num_sources; s++) {
                    corrected_output[f][t][s] = separated_sources[f][t][s];
                }
            }
        }
        return;
    }

    // 对每个频率bin进行反向投影
    for (int f = 0; f < config_.freq_bins; f++) {
        // 步骤1: 计算 Yi*Yi' (M x M 矩阵)
        std::vector<std::vector<Complex>> YiYi(config_.num_sources,
                                              std::vector<Complex>(config_.num_sources));

        for (int m = 0; m < config_.num_sources; m++) {
            for (int n = 0; n < config_.num_sources; n++) {
                Complex sum(0.0f, 0.0f);
                for (int t = 0; t < config_.time_frames; t++) {
                    Complex y_m = separated_sources[f][t][m];
                    Complex y_n = separated_sources[f][t][n];
                    sum += y_m * std::conj(y_n);
                }
                YiYi[m][n] = sum;
            }
        }

        // 步骤2: 计算 X(f,:,ref_mic)*Yi' (1 x M 向量)
        std::vector<Complex> XYi(config_.num_sources);
        for (int m = 0; m < config_.num_sources; m++) {
            Complex sum(0.0f, 0.0f);
            for (int t = 0; t < config_.time_frames; t++) {
                Complex x_ref = original_input[f][t][ref_mic_index];
                Complex y_m = separated_sources[f][t][m];
                sum += x_ref * std::conj(y_m);
            }
            XYi[m] = sum;
        }

        // 步骤3: 求解 A = XYi / YiYi
        std::vector<Complex> A(config_.num_sources);
        for (int m = 0; m < config_.num_sources; m++) {
            double denominator = std::real(YiYi[m][m]);  // 双精度
            if (denominator > config_.eps) {
                A[m] = XYi[m] / static_cast<float>(denominator);  // 转换为float
            } else {
                A[m] = Complex(1.0, 0.0);  // 回退值，双精度
            }
        }

        // 步骤4: 应用缩放 Z(f,:,m) = A(m)*Y(f,:,m)
        for (int t = 0; t < config_.time_frames; t++) {
            for (int m = 0; m < config_.num_sources; m++) {
                Complex y_val = separated_sources[f][t][m];
                corrected_output[f][t][m] = A[m] * y_val;
            }
        }
    }

    ALG_LOGI("Applied back projection with reference mic %d", ref_mic_index);
}



/**
 * @brief 更新源模型(功率谱密度)
 *
 * 基于当前分离的源信号计算每个源在每个时间帧的功率，
 * 用作辅助函数优化中的权重。r_{j,n} = sum_i |y_{i,j,n}|^2
 */
void AuxIVAProcessor::UpdateSourceModels(const ComplexTensor& separated_sources) {
    // r_{j,n} = sum_i |y_{i,j,n}|^2 (无平方根！)
    for (int s = 0; s < config_.num_sources; s++) {
        for (int t = 0; t < config_.time_frames; t++) {
            double power = 0.0;  // 双精度累加

            // 计算所有频率的功率: sum_i |y_{i,j,n}|^2
            for (int f = 0; f < config_.freq_bins; f++) {
                Complex y = separated_sources[f][t][s];
                power += y.real() * y.real() + y.imag() * y.imag();  // 双精度计算
            }

            // 应用最小值限制
            if (power < config_.eps) {
                power = config_.eps;
            }

            // 存储功率
            source_models_[s][t] = power;
        }
    }
}

void AuxIVAProcessor::UpdateDemixingMatrix(int freq_bin,
                                          const ComplexMatrix& input_freq,
                                          const std::vector<std::vector<double>>& source_models) {  

    // 提取当前频点的解混矩阵 W_freq
    ComplexMatrix W_freq(config_.num_sources, std::vector<Complex>(config_.num_channels));
    for (int s = 0; s < config_.num_sources; s++) {
        for (int m = 0; m < config_.num_channels; m++) {
            W_freq[s][m] = demixing_matrices_[freq_bin][s][m];
        }
    }

    for (int source_idx = 0; source_idx < config_.num_sources; source_idx++) {
        // 步骤1: 计算协方差矩阵 D = (1/J) * sum_j (x_j * x_j^H / r_j)
        ComputeCovarianceMatrix(freq_bin, source_idx, input_freq, source_models[source_idx]);

        // 步骤2: 求解线性方程
        std::vector<Complex> new_demixing_vector(config_.num_channels);
        if (SolveDemixingVector(source_idx, W_freq, new_demixing_vector)) {
            // 步骤3: 更新解混矩阵 W[source_idx, :, freq_bin] = w_vector^H
            for (int m = 0; m < config_.num_channels; m++) {
                // 存储共轭转置
                demixing_matrices_[freq_bin][source_idx][m] = std::conj(new_demixing_vector[m]);
            }
        }
    }
}

void AuxIVAProcessor::ComputeCovarianceMatrix(int freq_bin, int source_idx,
                                            const ComplexMatrix& input_freq,
                                            const std::vector<double>& source_model) {  

    // 初始化协方差矩阵为零
    for (int i = 0; i < config_.num_channels; i++) {
        for (int j = 0; j < config_.num_channels; j++) {
            temp_matrix_[i][j] = Complex(0.0, 0.0);  // 双精度初始化
        }
    }

    // D = (1/J) * sum_j (x_j * x_j^H / r_j)
    for (int t = 0; t < config_.time_frames; t++) {
        // 获取 r_j = R[freq_idx, j, source_idx]
        double r_val = source_model[t];  
        if (r_val < config_.eps) {
            r_val = config_.eps;  // 避免除零，匹配主目录 iva
        }

        // 计算 x_j * x_j^H / r_j 并累加到 D
        for (int m1 = 0; m1 < config_.num_channels; m1++) {
            for (int m2 = 0; m2 < config_.num_channels; m2++) {
                Complex x_m1 = input_freq[t][m1];
                Complex x_m2_conj = std::conj(input_freq[t][m2]);
                Complex contrib = (x_m1 * x_m2_conj) / static_cast<float>(r_val);  
                temp_matrix_[m1][m2] += contrib;
            }
        }
    }

    // 除以时间帧数 J
    double scale = 1.0 / config_.time_frames;  // 双精度缩放
    for (int m1 = 0; m1 < config_.num_channels; m1++) {
        for (int m2 = 0; m2 < config_.num_channels; m2++) {
            temp_matrix_[m1][m2] *= scale;
        }
    }
}

bool AuxIVAProcessor::SolveDemixingVector(int source_idx, const ComplexMatrix& W_freq, std::vector<Complex>& demixing_vector) {
    // w = (W * D)^{-1} * e_n，然后归一化 w = w / sqrt(w^H * D * w)

    // 步骤1: 计算 WD = W_freq * D
    ComplexMatrix WD(config_.num_channels, std::vector<Complex>(config_.num_channels));
    for (int i = 0; i < config_.num_channels; i++) {
        for (int j = 0; j < config_.num_channels; j++) {
            WD[i][j] = Complex(0.0f, 0.0f);
            for (int k = 0; k < config_.num_channels; k++) {
                WD[i][j] += W_freq[i][k] * temp_matrix_[k][j];
            }
        }
    }

    // 步骤2: 求逆 WD_inv = (W * D)^{-1}
    ComplexMatrix WD_inv = WD;  // 复制用于求逆
    if (!InvertMatrix(WD_inv)) {
        ALG_LOGE("Failed to invert WD matrix in SolveDemixingVector");
        return false;
    }

    // 步骤3: 构造单位向量 e_n
    std::vector<Complex> unit_vector(config_.num_channels, Complex(0.0f, 0.0f));
    unit_vector[source_idx] = Complex(1.0f, 0.0f);

    // 步骤4: 求解 w = WD_inv * e_n
    demixing_vector.resize(config_.num_channels);
    for (int i = 0; i < config_.num_channels; i++) {
        demixing_vector[i] = Complex(0.0f, 0.0f);
        for (int j = 0; j < config_.num_channels; j++) {
            demixing_vector[i] += WD_inv[i][j] * unit_vector[j];
        }
    }

    // 步骤5: 归一化处理（严格匹配主目录 iva）
    // 计算 D * w
    std::vector<Complex> Dw(config_.num_channels);
    for (int i = 0; i < config_.num_channels; i++) {
        Dw[i] = Complex(0.0f, 0.0f);
        for (int j = 0; j < config_.num_channels; j++) {
            Dw[i] += temp_matrix_[i][j] * demixing_vector[j];
        }
    }

    // 计算 w^H * D * w
    Complex wHDw(0.0f, 0.0f);
    for (int i = 0; i < config_.num_channels; i++) {
        wHDw += std::conj(demixing_vector[i]) * Dw[i];
    }

    // 归一化: w = w / sqrt(w^H * D * w) 
    // w^H * D * w 对于 Hermitian D 应该是实数，取实部并开方
    float wHDw_real = std::real(wHDw);
    float norm_factor = std::sqrt(wHDw_real);
    if (norm_factor > static_cast<float>(config_.eps)) {
        for (int i = 0; i < config_.num_channels; i++) {
            demixing_vector[i] /= norm_factor;
        }
    }

    return true;
}

bool AuxIVAProcessor::InvertMatrix(ComplexMatrix& matrix) {
    int n = matrix.size();
    if (n == 0 || matrix[0].size() != static_cast<size_t>(n)) {
        return false;
    }

    // 计算矩阵迹用于相对对角加载
    double matrix_trace = 0.0;  // 双精度
    for (int i = 0; i < n; i++) {
        matrix_trace += std::real(matrix[i][i]);
    }

    // 计算对角加载值
    double diag_load = std::max(config_.diag_load_abs,
                               config_.diag_load_rel * matrix_trace / n);  // 双精度计算

    // Create augmented matrix [A|I] with diagonal loading
    std::vector<std::vector<Complex>> aug(n, std::vector<Complex>(2 * n));

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            aug[i][j] = matrix[i][j];
            if (i == j) {
                aug[i][j] += Complex(diag_load, 0.0f);  // 添加对角加载
            }
            aug[i][j + n] = (i == j) ? Complex(1.0f, 0.0f) : Complex(0.0f, 0.0f);
        }
    }

    // Gauss-Jordan elimination
    for (int i = 0; i < n; i++) {
        // Find pivot
        int pivot = i;
        double max_abs = std::abs(aug[i][i]);  
        for (int k = i + 1; k < n; k++) {
            double abs_val = std::abs(aug[k][i]);  
            if (abs_val > max_abs) {
                max_abs = abs_val;
                pivot = k;
            }
        }

        double threshold = std::max(config_.eps, 1e-12);  // 双精度阈值
        if (max_abs < threshold) {
            ALG_LOGE("Matrix singular in InvertMatrix: max_abs=%.2e, threshold=%.2e", max_abs, threshold);
            return false;  // Singular matrix
        }

        // Swap rows
        if (pivot != i) {
            std::swap(aug[i], aug[pivot]);
        }

        // Scale pivot row
        Complex pivot_val = aug[i][i];
        for (int j = 0; j < 2 * n; j++) {
            aug[i][j] /= pivot_val;
        }

        // Eliminate column
        for (int k = 0; k < n; k++) {
            if (k != i) {
                Complex factor = aug[k][i];
                for (int j = 0; j < 2 * n; j++) {
                    aug[k][j] -= factor * aug[i][j];
                }
            }
        }
    }

    // Extract inverse matrix
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            matrix[i][j] = aug[i][j + n];
        }
    }

    return true;
}

void AuxIVAProcessor::UpdateDemixingMatrixFreqSource(int freq_bin, int source_idx, const ComplexMatrix& input_freq) {


    // 步骤1: 计算协方差矩阵 D
    ComputeCovarianceMatrix(freq_bin, source_idx, input_freq, source_models_[source_idx]);

    // 步骤2: 提取当前频点的解混矩阵 W_freq
    ComplexMatrix W_freq(config_.num_sources, std::vector<Complex>(config_.num_channels));
    for (int s = 0; s < config_.num_sources; s++) {
        for (int m = 0; m < config_.num_channels; m++) {
            W_freq[s][m] = demixing_matrices_[freq_bin][s][m];
        }
    }

    // 步骤3: 求解解混向量（严格按照主目录 iva: w = (W * D)^{-1} * e_n）
    std::vector<Complex> new_demixing_vector(config_.num_channels);
    if (SolveDemixingVector(source_idx, W_freq, new_demixing_vector)) {
        // 步骤4: 更新解混矩阵 W[source_idx, :, freq_bin] = w_vector^H
        for (int m = 0; m < config_.num_channels; m++) {
            // 存储共轭转置（匹配主目录 iva）
            demixing_matrices_[freq_bin][source_idx][m] = std::conj(new_demixing_vector[m]);
        }
    }
}

void AuxIVAProcessor::NormalizeDemixingMatrices() {
    // 严格匹配主目录 iva 的 auxiva_normalize_demixing_matrices 实现
    // lambda[n] = sqrt(sum_{i,j} P[i,j,n] / (I*J))

    std::vector<double> lambda(config_.num_sources);

    // 步骤1: 计算每个源的归一化因子 lambda[n]
    for (int n = 0; n < config_.num_sources; n++) {
        double total_power = 0.0;

        // source_models_[n][j] 已经是对所有频率求和的结果（相当于主目录iva的R）
        // 所以这里只需要对时间求和
        for (int j = 0; j < config_.time_frames; j++) {
            total_power += source_models_[n][j];
        }

        // lambda[n] = sqrt(total_power / (I * J))
        // 由于source_models_已经对频率求和，所以这里相当于主目录iva的sum(P)
        lambda[n] = std::sqrt(total_power / (config_.freq_bins * config_.time_frames));

        // 避免除零
        if (lambda[n] < config_.eps) {
            lambda[n] = 1.0;
        }
    }

    // 步骤2: 归一化解混矩阵 W[n,:,:] = W[n,:,:] / lambda[n]
    for (int n = 0; n < config_.num_sources; n++) {
        for (int m = 0; m < config_.num_channels; m++) {
            for (int i = 0; i < config_.freq_bins; i++) {
                demixing_matrices_[i][n][m] /= static_cast<float>(lambda[n]);
            }
        }
    }

    // 步骤3: 归一化源模型 P[:,:,n] = P[:,:,n] / lambda[n]^2
    for (int n = 0; n < config_.num_sources; n++) {
        double lambda_sq = lambda[n] * lambda[n];
        for (int j = 0; j < config_.time_frames; j++) {
            source_models_[n][j] /= lambda_sq;
        }
    }
}

bool AuxIVAProcessor::CheckConvergence(const ComplexTensor& prev_demixing, double threshold) {
    // 计算解混矩阵的相对变化量

    double total_diff = 0.0;
    double total_norm = 0.0;

    for (int f = 0; f < config_.freq_bins; f++) {
        for (int s = 0; s < config_.num_sources; s++) {
            for (int c = 0; c < config_.num_channels; c++) {
                Complex curr = demixing_matrices_[f][s][c];
                Complex prev = prev_demixing[f][s][c];
                Complex diff = curr - prev;

                // 累计差异的平方和
                total_diff += std::norm(diff);
                // 累计当前值的平方和
                total_norm += std::norm(curr);
            }
        }
    }

    // 避免除零
    if (total_norm < config_.eps) {
        return true;  // 如果矩阵接近零，认为已收敛
    }

    // 计算相对变化量
    double relative_change = std::sqrt(total_diff / total_norm);

    ALG_LOGI("Convergence check: relative_change=%.2e, threshold=%.2e",
             relative_change, threshold);

    return relative_change < threshold;
}



void AuxIVAProcessor::Reset() {
    if (initialized_) {
        InitializeDemixingMatrices();
    }
}

void AuxIVAProcessor::Cleanup() {
    demixing_matrices_.clear();
    temp_matrix_.clear();
    source_powers_.clear();
    source_models_.clear();
    initialized_ = false;
}

} // namespace kws2k2_faith
