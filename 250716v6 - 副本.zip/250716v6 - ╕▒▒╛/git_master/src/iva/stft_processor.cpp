/**
 * @file stft_processor.cpp
 * @brief STFT处理器的实现，提供多通道音频的时频变换功能
 */

#include "stft_processor.h"
#include "iva_fft_adapter.h"
#include "../imedia_common_basic_op.h"
#include "../alg_log.h"
#include <cmath>
#include <algorithm>

namespace kws2k2_faith {

int STFTProcessor::Initialize(const STFTConfig& config) {
    config_ = config;
    
    // Validate configuration
    if (config_.fft_size <= 0 || config_.hop_size <= 0 || config_.window_size <= 0) {
        ALG_LOGE("Invalid STFT configuration");
        return -1;
    }
    
    if (config_.hop_size > config_.fft_size) {
        ALG_LOGE("Hop size (%d) cannot be larger than FFT size (%d)", 
                 config_.hop_size, config_.fft_size);
        return -1;
    }
    
    // Initialize FFT
    if (iva_fft_init(config_.fft_size) != 0) {
        ALG_LOGE("Failed to initialize FFT");
        return -1;
    }
    
    freq_bins_ = config_.fft_size / 2 + 1;
    
    // Generate window
    GenerateWindow();
    
    // Allocate working buffers
    fft_buffer_.resize(config_.fft_size);
    temp_frame_.resize(config_.fft_size);
    
    initialized_ = true;
    ALG_LOGI("STFT processor initialized: FFT size=%d, hop size=%d, freq bins=%d", 
             config_.fft_size, config_.hop_size, freq_bins_);
    
    return 0;
}

void STFTProcessor::GenerateWindow() {
    window_.resize(config_.window_size);
    synthesis_window_.resize(config_.window_size);
    
    for (int i = 0; i < config_.window_size; i++) {
        float w = 0.0f;
        float n = static_cast<float>(i);
        float N = static_cast<float>(config_.window_size - 1);
        
        switch (config_.window_type) {
            case STFTConfig::HANN:
                w = 0.5f * (1.0f - std::cos(2.0f * M_PI * n / N));
                break;
            case STFTConfig::HAMMING:
                w = 0.54f - 0.46f * std::cos(2.0f * M_PI * n / N);
                break;
            case STFTConfig::BLACKMAN:
                w = 0.42f - 0.5f * std::cos(2.0f * M_PI * n / N) + 
                    0.08f * std::cos(4.0f * M_PI * n / N);
                break;
        }
        
        window_[i] = w;
        synthesis_window_[i] = w;
    }
    
    // Normalize synthesis window for perfect reconstruction
    float window_sum = 0.0f;
    for (int i = 0; i < config_.window_size; i++) {
        window_sum += synthesis_window_[i] * synthesis_window_[i];
    }
    
    if (window_sum > 0.0f) {
        float norm_factor = static_cast<float>(config_.hop_size) / window_sum;
        for (int i = 0; i < config_.window_size; i++) {
            synthesis_window_[i] *= norm_factor;
        }
    }
}

int STFTProcessor::GetTimeFrames(int input_length) const {
    if (input_length < config_.fft_size) {
        return 0;
    }
    return (input_length - config_.fft_size) / config_.hop_size + 1;
}

int STFTProcessor::Forward(const std::vector<std::vector<float>>& input, ComplexTensor& output) {
    if (!initialized_) {
        ALG_LOGE("STFT processor not initialized");
        return -1;
    }
    
    if (input.empty() || input[0].empty()) {
        ALG_LOGE("Empty input");
        return -1;
    }
    
    int num_channels = input.size();
    int input_length = input[0].size();
    int time_frames = GetTimeFrames(input_length);
    
    if (time_frames <= 0) {
        ALG_LOGE("Input too short for STFT");
        return -1;
    }
    
    // Resize output [freq][time][channel]
    output.resize(freq_bins_);
    for (int f = 0; f < freq_bins_; f++) {
        output[f].resize(time_frames);
        for (int t = 0; t < time_frames; t++) {
            output[f][t].resize(num_channels);
        }
    }
    
    // Process each channel
    for (int ch = 0; ch < num_channels; ch++) {
        for (int frame = 0; frame < time_frames; frame++) {
            int frame_start = frame * config_.hop_size;
            
            // Extract and window frame
            std::fill(temp_frame_.begin(), temp_frame_.end(), 0.0f);
            
            for (int i = 0; i < config_.window_size && (frame_start + i) < input_length; i++) {
                temp_frame_[i] = input[ch][frame_start + i] * window_[i];
            }
            
            // Perform FFT
            std::vector<Complex> freq_frame(freq_bins_);
            PerformFFT(temp_frame_, freq_frame);
            
            // Store in output tensor
            for (int f = 0; f < freq_bins_; f++) {
                output[f][frame][ch] = freq_frame[f];
            }
        }
    }
    
    return 0;
}

int STFTProcessor::Inverse(const ComplexTensor& input, std::vector<std::vector<float>>& output) {
    if (!initialized_) {
        ALG_LOGE("STFT processor not initialized");
        return -1;
    }
    
    if (input.empty() || input[0].empty() || input[0][0].empty()) {
        ALG_LOGE("Empty input");
        return -1;
    }
    
    int freq_bins = input.size();
    int time_frames = input[0].size();
    int num_channels = input[0][0].size();
    
    if (freq_bins != freq_bins_) {
        ALG_LOGE("Frequency bins mismatch: expected %d, got %d", freq_bins_, freq_bins);
        return -1;
    }
    
    // Calculate output length
    int output_length = (time_frames - 1) * config_.hop_size + config_.fft_size;

    // Resize output and overlap buffers
    output.resize(num_channels);
    overlap_buffer_.resize(num_channels);
    for (int ch = 0; ch < num_channels; ch++) {
        output[ch].resize(output_length, 0.0f);
        overlap_buffer_[ch].resize(output_length, 0.0f);
    }
    
    // Process each channel
    for (int ch = 0; ch < num_channels; ch++) {
        for (int frame = 0; frame < time_frames; frame++) {
            // Extract frequency frame
            std::vector<Complex> freq_frame(freq_bins_);
            for (int f = 0; f < freq_bins_; f++) {
                freq_frame[f] = input[f][frame][ch];
            }
            
            // Perform IFFT
            std::vector<float> time_frame(config_.fft_size);
            PerformIFFT(freq_frame, time_frame);
            
            // Apply synthesis window and overlap-add
            for (int i = 0; i < config_.window_size; i++) {
                time_frame[i] *= synthesis_window_[i];
            }
            
            int frame_start = frame * config_.hop_size;
            OverlapAdd(time_frame, output[ch], frame_start);
        }
    }

    return 0;
}

void STFTProcessor::PerformFFT(const std::vector<float>& input, std::vector<Complex>& output) {
    // Convert to complex
    for (int i = 0; i < config_.fft_size; i++) {
        if (i < static_cast<int>(input.size())) {
            fft_buffer_[i] = Complex(input[i], 0.0f);
        } else {
            fft_buffer_[i] = Complex(0.0f, 0.0f);
        }
    }
    
    // Perform FFT using iMedia FFT adapter
    std::vector<Complex> fft_output(config_.fft_size);
    iva_fft_forward(fft_buffer_.data(), fft_output.data(), config_.fft_size);
    
    // Extract positive frequencies only
    output.resize(freq_bins_);
    for (int i = 0; i < freq_bins_; i++) {
        output[i] = fft_output[i];
    }
}

void STFTProcessor::PerformIFFT(const std::vector<Complex>& input, std::vector<float>& output) {
    // Reconstruct full spectrum (conjugate symmetry)
    std::vector<Complex> full_spectrum(config_.fft_size);
    
    for (int i = 0; i < freq_bins_; i++) {
        full_spectrum[i] = input[i];
    }
    
    for (int i = freq_bins_; i < config_.fft_size; i++) {
        int mirror_idx = config_.fft_size - i;
        if (mirror_idx > 0 && mirror_idx < freq_bins_) {
            full_spectrum[i] = std::conj(input[mirror_idx]);
        } else {
            full_spectrum[i] = Complex(0.0f, 0.0f);
        }
    }
    
    // Perform IFFT
    std::vector<Complex> ifft_output(config_.fft_size);
    iva_fft_inverse(full_spectrum.data(), ifft_output.data(), config_.fft_size);
    
    // Extract real part (scaling already applied in FFT adapter)
    output.resize(config_.fft_size);
    for (int i = 0; i < config_.fft_size; i++) {
        output[i] = ifft_output[i].real();  // FFT适配器已经应用了2.0/fft_size缩放
    }
}

void STFTProcessor::OverlapAdd(const std::vector<float>& frame, std::vector<float>& output, int frame_start) {
    for (int i = 0; i < static_cast<int>(frame.size()) && (frame_start + i) < static_cast<int>(output.size()); i++) {
        output[frame_start + i] += frame[i];
    }
}

void STFTProcessor::Cleanup() {
    if (initialized_) {
        iva_fft_destroy();
        window_.clear();
        synthesis_window_.clear();
        fft_buffer_.clear();
        temp_frame_.clear();
        overlap_buffer_.clear();
        initialized_ = false;
    }
}

} // namespace kws2k2_faith
