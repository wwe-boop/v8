
#include "imedia_common_basic_op.h"

namespace kws2k2_faith {
#define IMEDIA_M_PI   3.14159265358979323846f /* pi */
#define IMEDIA_M_PI_2 1.57079632679489661923f /* pi/2 */

static const IMEDIA_FLOAT32 iMedia_afSinf[4] = {
    -0.00018365f,  //p7
    -0.16664831f,  //p3
    +0.00830636f,  //p5
    +0.99999661f,  //p1
};

const IMEDIA_FLOAT32 iMedia_afArctanf[4] = {
    -0.0443265554792128,  //p7
    -0.3258083974640975,  //p3
    +0.1555786518463281,  //p5
    +0.9997878412794807,  //p1
};

/******************************************************************************
Function:       iMedia_sinf_c
Description:    �������Һ���
Input:          x : �����ƽǶ�
Output:         ��
Return:         r = sin(x)
Test Range:     -pi < x < pi
Peak Error:     0.000071525574%
 *******************************************************************************/
IMEDIA_FLOAT32 iMedia_sinf_c(IMEDIA_FLOAT32 fVarin)
{
    union {
        IMEDIA_FLOAT32 fTmp;
        IMEDIA_INT32 iTmp;
    } aVarTmp;

    IMEDIA_FLOAT32 fVarout, fTmpA, fTmpB, fTmpxx;
    IMEDIA_INT32 iTmpm, iTmpn;
    IMEDIA_UINT32 uTmpm, uTmpn;
    aVarTmp.fTmp = iMedia_fabsf_c(fVarin);

    //Range Reduction:
    iTmpm = (IMEDIA_INT32)(aVarTmp.fTmp * 2.0f / IMEDIA_M_PI);
    aVarTmp.fTmp = aVarTmp.fTmp - (((IMEDIA_FLOAT32)iTmpm) * IMEDIA_M_PI / 2.0f);

    //Test Quadrant
    iTmpn = iTmpm & 1;
    aVarTmp.fTmp = aVarTmp.fTmp - iTmpn * IMEDIA_M_PI / 2.0;
    iTmpm = iTmpm >> 1;

    //iTmpn = (IMEDIA_UINT32)iTmpn ^ (IMEDIA_UINT32)iTmpm;
    uTmpm = (IMEDIA_UINT32)iTmpn;
    uTmpn = (IMEDIA_UINT32)iTmpm;

    uTmpn = uTmpn ^ uTmpm;
    //iTmpn = (IMEDIA_INT32)uTmpn;

    //iTmpm = (fVarin < 0.0 ? 1 : 0);
    if (fVarin < 0.0f) {
        uTmpm = 1;
    } else {
        uTmpm = 0;
    }

    //iTmpn = (IMEDIA_UINT32)iTmpn ^ (IMEDIA_UINT32)iTmpm;
    //uTmpm = (IMEDIA_UINT32)iTmpm;
    uTmpn = uTmpn ^ uTmpm;
    iTmpn = (IMEDIA_INT32)uTmpn;

    iTmpn = iTmpn << 31;
    aVarTmp.iTmp = aVarTmp.iTmp ^ iTmpn;

    //Taylor Polynomial (Estrins)
    fTmpxx = aVarTmp.fTmp * aVarTmp.fTmp;
    fTmpA = (iMedia_afSinf[0] * aVarTmp.fTmp) * fTmpxx + (iMedia_afSinf[2] * aVarTmp.fTmp);
    fTmpB = (iMedia_afSinf[1] * aVarTmp.fTmp) * fTmpxx + (iMedia_afSinf[3] * aVarTmp.fTmp);
    fTmpxx = fTmpxx * fTmpxx;
    fVarout = fTmpB + fTmpA * fTmpxx;

    return fVarout;
}

/******************************************************************************
Function:       iMedia_cosf_c
Description:    �������Һ���
Input:          x : �����ƽǶ�
Output:         ��
Return:         r = cos(x)
Test Range:     0 < x < 2*pi
Peak Error:     0.000077486038%
 *******************************************************************************/
IMEDIA_FLOAT32 iMedia_cosf_c(IMEDIA_FLOAT32 fVarin)
{
    return iMedia_sinf_c(fVarin + IMEDIA_M_PI_2);
}

/******************************************************************************
Function:       iMedia_atanf_c
Description:    ���㷴���к���
Input:          x : �����ƽǶ�
Output:         ��
Return:         r = atanf_c(x)
Test Range:     -10000.0 < x < 10000.0
Peak Error:     ~0.024390220642%
 *******************************************************************************/
IMEDIA_FLOAT32 iMedia_atanf_c(IMEDIA_FLOAT32 fVarin)
{
    IMEDIA_FLOAT32 fTmpA, fTmpB, fTmpC, fTmpxx;
    IMEDIA_INT32 iTmpM;

    union {
        IMEDIA_FLOAT32 fTmp;
        IMEDIA_INT32 iTmp;
    } xinv, aVarTmp;

    aVarTmp.fTmp = iMedia_fabsf_c(fVarin);

    //fast inverse approximation (2x newton)
    xinv.fTmp = aVarTmp.fTmp;
    iTmpM = 0x3F800000 - (xinv.iTmp & 0x7F800000);
    xinv.iTmp = xinv.iTmp + iTmpM;
    xinv.fTmp = 1.41176471f - 0.47058824f * xinv.fTmp;
    xinv.iTmp = xinv.iTmp + iTmpM;
    fTmpB = 2.0f - xinv.fTmp * aVarTmp.fTmp;
    xinv.fTmp = xinv.fTmp * fTmpB;
    fTmpB = 2.0f - xinv.fTmp * aVarTmp.fTmp;
    xinv.fTmp = xinv.fTmp * fTmpB;

    //if |x| > 1.0 -> ax = -1/ax, r = pi/2
    xinv.fTmp = xinv.fTmp + aVarTmp.fTmp;
    fTmpA = (aVarTmp.fTmp > 1.0f);
    aVarTmp.fTmp = aVarTmp.fTmp - fTmpA * xinv.fTmp;
    fTmpC = fTmpA * IMEDIA_M_PI_2;

    //polynomial evaluation
    fTmpxx = aVarTmp.fTmp * aVarTmp.fTmp;
    fTmpA = (iMedia_afArctanf[0] * aVarTmp.fTmp) * fTmpxx + (iMedia_afArctanf[2] * aVarTmp.fTmp);
    fTmpB = (iMedia_afArctanf[1] * aVarTmp.fTmp) * fTmpxx + (iMedia_afArctanf[3] * aVarTmp.fTmp);
    fTmpxx = fTmpxx * fTmpxx;
    fTmpB = fTmpB + fTmpA * fTmpxx;
    fTmpC = fTmpC + fTmpB;

    //if x < 0 -> r = -r
    fTmpA = 2 * fTmpC;
    fTmpB = (fVarin < 0.0f);
    fTmpC = fTmpC - fTmpA * fTmpB;

    return fTmpC;
}

/******************************************************************************
Function:       iMedia_fabsf_c
Description:    �������ֵ����
Input:          x : ������
Output:         ��
Return:         r = |x|
Test Range:     |x| < 2147483648,int�ܱ�ʾ�����ֵ
Peak Error:     0
 *******************************************************************************/
IMEDIA_FLOAT32 iMedia_fabsf_c(IMEDIA_FLOAT32 fVarin)
{
    union {
        IMEDIA_FLOAT32 fTmp;
        IMEDIA_INT32 iTmp;
    } aVarTmpxx;

    aVarTmpxx.fTmp = fVarin;
    aVarTmpxx.iTmp = aVarTmpxx.iTmp & 0x7FFFFFFF;
    return aVarTmpxx.fTmp;
}

}  // namespace kws2k2_faith
