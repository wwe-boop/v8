#ifndef _IMEDIA_TYPEDEF_
#define _IMEDIA_TYPEDEF_

// 使用uniDSP宏定义防止重复定义引起的编译报错
#ifndef UNI_TYPE_DEF
#define UNI_TYPE_DEF

// 16位数据类型重定义
typedef signed short          IMEDIA_INT16;

// 32位数据类型重定义
typedef unsigned int          IMEDIA_UINT32;
typedef signed int            IMEDIA_INT32;

// 浮点数据类型重定义: 与uniDSP平台头文件兼容
typedef float                 IMEDIA_FLOAT;

// 浮点数据类型重定义: 与VTC、VQE算法库内定义一致
typedef float                 IMEDIA_FLOAT32;

// VOID重定义，与uniDSP平台头文件兼容
#ifndef     IMEDIA_VOID
#define     IMEDIA_VOID              void
#endif

#endif    // end of #ifndef UNI_TYPE_DEF

#ifndef     IMEDIA_NULL
#define     IMEDIA_NULL         ((IMEDIA_VOID *)0)
#endif

#endif    // end of #ifndef _IMEDIA_TYPEDEF_
