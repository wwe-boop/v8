#include <stdio.h>
#include <iostream>
#include <string>
#include <fstream>
#include "E2EProcessor.h"
#include "feature_pipeline.h"
#include "faith_api.h"
#include "alg_log.h"
#define LOG_TAG "kws2k2E2E:E2Eprocesser"

namespace kws2k2_faith {
    // input:124/40;output:124/512;weight:512/40
    int CalPreFnn(std::vector<std::vector<float>> inBuff, float *out_buff, const int hiddenDim) {
        if (inBuff.empty()) {
            ALG_LOGE("inBuff is empty.\n");
            return -1;
        }
        // inBuff不用转置，只有40个点
        for (int k = 0; k < inBuff.size(); k++) {
            for (int i = 0; i < hiddenDim; i++) {
                out_buff[k * hiddenDim + i] = pre_fnn_bias[i];
                for (int j = 0; j < num_bins; j++)
                {
                    out_buff[k * hiddenDim + i] += pre_fnn_weight[i * num_bins + j] * inBuff[k][j];
                }
            }
        }

        return 0;
    }

    void E2EProcessor::RecAudioForE2E(const short *buf, int32_t bufLen) {
        if (buf == nullptr || bufLen == 0) {
            ALG_LOGI("Invalid E2E wav buffer");
            return;
        }

        wav.clear();
        wav.reserve(bufLen);

        for (int i = 0; i < bufLen; ++i) {
            wav.push_back(static_cast<float>(buf[i]));
        }
    }

    float E2EProcessor::E2EProcess(std::shared_ptr<FaithInference> encoder) {
        if (wav.empty()) {
            ALG_LOGI("wav for e2e is empty\n");
            return 0;
        }

        int res = 0;

        kws2k2_faith::FeaturePipelineConfig feature_config(num_bins, sr);
        kws2k2_faith::FeaturePipeline feature_pipeline(feature_config);
        // extract feats
        std::vector<std::vector<float>> feats;
        feats = feature_pipeline.AcceptWaveform(wav);

        float featsIn[frame_2s * hiddenDim];
        float outBuff[frame_2s * hiddenDim];
        float cache[hiddenDim * cache_size] = {0.0f};

        CalPreFnn(feats, featsIn, hiddenDim);

        std::vector<float> inputData;
        int fbanksize_t = frame_2s * hiddenDim;
        int cachesize_t = hiddenDim * cache_size;
        for (int i = 0; i < fbanksize_t; i++) {
            inputData.push_back(featsIn[i]);
        }
        for (int i = 0; i < cachesize_t; ++i) {
            inputData.push_back(cache[i]);
        }

        kws2k2_faith::FaithInference faith_inference_e2e_encoder;
        
        int ret = encoder->Compute(inputData, fbanksize_t + cachesize_t, outBuff, frame_2s * hiddenDim);
        if (ret != 0) {
            ALG_LOGI("E2E encoder Compute failed.\n");
            return -1;
        }

        // 修改faith输出顺序
        float output[frame_2s][hiddenDim];
        for (int i = 0; i < feats.size(); i++) {
            for (int j = 0; j < hiddenDim; j++) {
                output[i][j] = outBuff[i * hiddenDim + j];
            }
        }
        // out_fnn
        float out_fnn_out[frame_2s][class_num] = {0};
        for (int i = 0; i < frame_2s; ++i) {
            for (int j = 0; j < hiddenDim; ++j) {
                out_fnn_out[i][0] += output[i][j] * out_fnn_weight0[j];
                out_fnn_out[i][1] += output[i][j] * out_fnn_weight1[j];
            }
        }
        // softmax
        int i = 0;
        float pmax = 0;
        for (; i < frame_2s; ++i) {
            float out_max = std::max(out_fnn_out[i][0], out_fnn_out[i][1]);
            float exp_sum = std::exp(out_fnn_out[i][0] - out_max) + std::exp(out_fnn_out[i][1] - out_max);
            float post_proi = std::exp(out_fnn_out[i][1] - out_max) / exp_sum;
            if (pmax < post_proi) {
                pmax = post_proi;
            }
        }
        ALG_LOGI("E2E pmax === %f\n", pmax);

        return pmax;
    }
} /* namespace kws2k2_faith */
