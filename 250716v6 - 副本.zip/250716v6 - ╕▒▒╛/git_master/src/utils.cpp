#include <iostream>
#include <sstream>
#include <string>
#include <utility>
#include <vector>
#include "utils.h"
#include "alg_log.h"

#define LOG_TAG "kws2k2:utils"
namespace kws2k2_faith {

static bool EncodeBase(std::istream &is, const SymbolTable &symbol_table, std::vector<std::vector<int32_t>> *ids,
                       std::vector<std::string> *phrases, std::vector<std::string> *pinyins, std::vector<std::vector<float>> *scores, std::vector<float> *thresholds)
{
    if (ids == nullptr) {
        ALG_LOGE("ids is nullptr\n");
        return -1;
    }
    ids->clear();

    std::vector<int32_t> tmp_ids;
    std::vector<float> tmp_scores;
    std::vector<float> tmp_thresholds;
    std::vector<std::string> tmp_phrases;
    std::vector<std::string> tmp_pinyins;

    std::string line;
    std::string word;
    bool has_scores = false;
    bool has_thresholds = false;
    bool has_phrases = false;
    bool has_pinyins = false;
    int i = 0;

    while (std::getline(is, line)) {
        float score = 0;
        float threshold = 0;
        std::string phrase = "";
        std::string pinyin = "";

        std::istringstream iss(line);
        while (iss >> word) {
            if (word.size() >= 3) {
                // For BPE-based models, we replace ▁ with a space
                // Unicode 9601, hex 0x2581, utf8 0xe29681
                const uint8_t *p = reinterpret_cast<const uint8_t *>(word.c_str());
                if (p[0] == 0xe2 && p[1] == 0x96 && p[2] == 0x81) {
                    word = word.replace(0, 3, " ");
                }
            }
            if (symbol_table.Contains(word)) {
                int32_t id = symbol_table[word];
                tmp_ids.push_back(id);
            } else {
                switch (word[0]) {
                    case ':':  // boosting score for current keyword
                        tmp_scores.push_back(std::stof(word.substr(1)));
                        has_scores = true;
                        break;
                    case '#':  // triggering threshold (probability) for current keyword
                        threshold = std::stof(word.substr(1));
                        has_thresholds = true;
                        break;
                    case '@':  // the original keyword string
                        phrase = word.substr(1);
                        has_phrases = true;
                        break;
                    case '$':  // the original pinyin string
                        pinyin = word.substr(1);
                        has_pinyins = true;
                        break;
                    default:
                        ALG_LOGE(
                            "Cannot find ID for token %s at line: %s. (Hint: words on "
                            "the same line are separated by spaces)\n",
                            word.c_str(), line.c_str());
                        return false;
                }
            }
        }
        if (has_scores && tmp_scores.size() == 1) {
            for (i = 1; i < tmp_ids.size(); i++) {
                tmp_scores.push_back(tmp_scores[0]);
            }
        } else if (tmp_scores.size() == 0) {
            for (i = 0; i < tmp_ids.size(); i++) {
                tmp_scores.push_back(0.0f);
            }
        }
        scores->push_back(std::move(tmp_scores));
        ids->push_back(std::move(tmp_ids));
        tmp_phrases.push_back(phrase);
        tmp_pinyins.push_back(pinyin);
        tmp_thresholds.push_back(threshold);
    }
    if (phrases != nullptr) {
        if (has_phrases) {
            *phrases = std::move(tmp_phrases);
        } else {
            phrases->clear();
        }
    }
    if (pinyins != nullptr) {
        if (has_pinyins) {
            *pinyins = std::move(tmp_pinyins);
        } else {
            pinyins->clear();
        }
    }
    if (thresholds != nullptr) {
        if (has_thresholds) {
            thresholds->swap(tmp_thresholds);
        } else {
            thresholds->clear();
        }
    }
    return true;
}

bool EncodeHotwords(std::istream &is, const SymbolTable &symbol_table, std::vector<std::vector<int32_t>> *hotwords)
{
    return EncodeBase(is, symbol_table, hotwords, nullptr, nullptr, nullptr, nullptr);
}

bool EncodeKeywords(std::istream &is, const SymbolTable &symbol_table, std::vector<std::vector<int32_t>> *keywords_id,
                    std::vector<std::string> *keywords, std::vector<std::string> *pinyins, std::vector<std::vector<float>> *boost_scores, std::vector<float> *threshold)
{
    return EncodeBase(is, symbol_table, keywords_id, keywords, pinyins, boost_scores, threshold);
}

}  // namespace kws2k2_faith
