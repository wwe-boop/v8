#ifndef _KWS2K2_ALG_LOG_H_
#define _KWS2K2_ALG_LOG_H_

#if 0
//#if defined(ANDROID) || defined(_ANDROID_) || defined(__ANDROID__)
    #include <android/log.h>
    #define ALG_LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
    #define ALG_LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)
    #define ALG_LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#else
    #include <stdio.h>
    #define ALG_LOGI printf
    #define ALG_LOGD printf
    #define ALG_LOGE printf
#endif

#endif
