/**
 * @file faith_api.h
 * @brief Faith推理引擎API接口定义
 */

#ifndef KWS2K2_FAITH_CSRC_FAITH_API_H_
#define KWS2K2_FAITH_CSRC_FAITH_API_H_

#include <vector>
#include <fcntl.h>
#include <getopt.h>
#include <sched.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <string>
#include <memory>
#include <stdexcept>

#include "bolt.h"

#define MAX_TENSOR_NUM 16       ///< 最大张量数量
#define MAX_NAME_LEN   1024     ///< 最大名称长度
#define MAX_DIM_LEN    4        ///< 最大维度长度
#define DIM_N          0        ///< N维度索引
#define DIM_C          1        ///< C维度索引
#define DIM_H          2        ///< H维度索引
#define DIM_W          3        ///< W维度索引

#ifdef __aarch64__
typedef __fp16 F16;
#else
typedef float F16;
#endif

using namespace std;

namespace kws2k2_faith {

using Buffer = void *;
using BufferArray = Buffer[MAX_TENSOR_NUM];
using NameArray = char *[MAX_TENSOR_NUM];
using DimArray = int[MAX_DIM_LEN][MAX_TENSOR_NUM];
using DataTypeArray = DATA_TYPE[MAX_TENSOR_NUM];
using DataFormatArray = DATA_FORMAT[MAX_TENSOR_NUM];

/**
 * @brief 返回状态枚举
 */
enum class ReturnStatus {
    SUCCESS = 0,  ///< 成功
    FAIL = -1,    ///< 失败
    NULLPTR = -2  ///< 空指针
};

/**
 * @brief 张量规格数组结构体
 */
struct TensorSpecArray {
    int length {0};
    NameArray names {NULL};
    DimArray dims {0};
    DataTypeArray dts {(DATA_TYPE) 0};
    DataFormatArray dfs { (DATA_FORMAT) 0};

    TensorSpecArray(int n) : length(n)
    {
        for (int i = 0; i < n; ++i) {
            names[i] = new char[MAX_NAME_LEN];
        }
    }

    ~TensorSpecArray()
    {
        for (int i = 0; i < length; ++i) {
            delete[] names[i];
        }
    }
};

/**
 * @brief 安全创建shared_ptr的模板函数
 */
template<class T, class... Args>
inline std::shared_ptr<T> MakeSharedNoThrow(Args &&...args)
{
    try {
        return std::make_shared<T>(args...);
    } catch (std::bad_alloc) {
        return nullptr;
    } catch (std::length_error err) {
        return nullptr;
    }
}

/**
 * @brief Faith推理引擎类
 */
class FaithInference {
public:
    FaithInference() {};
    ~FaithInference() {};

    /**
     * @brief 计算张量元素数量
     */
    size_t NumElements(const DimArray &shape, int tensorId);

    /**
     * @brief 获取数据类型的字节数
     */
    size_t GetBytesOfDataType(DATA_TYPE type);

    /**
     * @brief 创建输入缓冲区数组
     */
    void CreateInputBufferArray(const TensorSpecArray *inputSpecs, BufferArray &buffers);

    /**
     * @brief 销毁输入缓冲区数组
     */
    void DestroyInputBufferArray(BufferArray &buffers, int numBuffer);

    /**
     * @brief 初始化缓冲区
     */
    void InitBuffer(const std::vector<float> &vals, const TensorSpecArray *specs, int tensorId, size_t offset,
                    BufferArray &buffers);

    /**
     * @brief 初始化缓冲区数组
     */
    void InitBufferArray(const std::vector<float> &vals, const TensorSpecArray *specs, BufferArray &buffers);

    /**
     * @brief 创建模型文件系统
     */
    ReturnStatus CreateModelFs(char const *modelPath, int *dataFd, char **dataBuf, size_t *dataLen);

    /**
     * @brief 销毁模型文件系统
     */
    void DestroyModelFs(int dataFd, char *dataBuf, size_t dataLen);

    /**
     * @brief 初始化模型引擎
     */
    int32_t InitModelEng(char const *modelPath);

    /**
     * @brief 执行推理计算
     */
    int32_t Compute(const std::vector<float> inputData, const uint32_t inputSize, float *outputData,
                    const uint32_t outputSize);

    /**
     * @brief 销毁模型引擎
     */
    int32_t DestroyModelEng();

private:
    int modelFd {-1};
    char *modelFs {NULL};
    size_t modelFsLen {0};
    ResultHandle modelResult {NULL};
    shared_ptr<TensorSpecArray> inputSpecs;
    shared_ptr<TensorSpecArray> outputSpecs;
    BufferArray inputBuffers {NULL};
    ModelHandle model {NULL};
    shared_ptr<float> output;
};
}  // namespace kws2k2_faith
#endif