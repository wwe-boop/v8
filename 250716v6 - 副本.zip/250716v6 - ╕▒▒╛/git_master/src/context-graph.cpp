#include <algorithm>
#include <cassert>
#include <queue>
#include <string>
#include <tuple>
#include <utility>
#include <numeric>
#include "context-graph.h"
#include "alg_log.h"

#define LOG_TAG "kws2k2:context-graph"

namespace kws2k2_faith {
void ContextGraph::Build(const std::vector<std::vector<int32_t>> &token_ids, const std::vector<std::vector<float>> &scores,
                         const std::vector<std::string> &phrases, const std::vector<std::string> &pinyins, const std::vector<float> &ac_thresholds) const
{
    if (!scores.empty()) {
        if (token_ids.size() != scores.size()) {
            ALG_LOGE("token_ids.size():%zu != scores.size():%zu\n",token_ids.size(), scores.size());
            return;
        }
    }
    if (!phrases.empty()) {
        if (token_ids.size() != phrases.size()) {
            ALG_LOGE("token_ids.size():%zu != phrases.size():%zu\n", token_ids.size(), phrases.size());
            return;
        }
    }
    if (!pinyins.empty()) {
        if (token_ids.size() != pinyins.size()) {
            ALG_LOGE("token_ids.size():%zu != pinyins.size():%zu\n", token_ids.size(), pinyins.size());
            return;
        }
    }
    if (!ac_thresholds.empty()) {
        if (token_ids.size() != ac_thresholds.size()) {
            ALG_LOGE("token_ids.size():%zu != ac_thresholds.size():%zu\n", token_ids.size(), ac_thresholds.size());
            return;
        }
    }
    for (int32_t i = 0; i < token_ids.size(); ++i) {
        auto node = root_.get();
        std::vector<float> score(token_ids[i].size(), context_score_);
        std::vector<float> fina_score = accumulate(scores[i].begin(), scores[i].end(), 0) == 0 ? score : scores[i];
        float ac_threshold = ac_thresholds.empty() ? 0.0f : ac_thresholds[i];
        ac_threshold = ac_threshold == 0.0f ? ac_threshold_ : ac_threshold;
        std::string phrase = phrases.empty() ? std::string() : phrases[i];
        std::string pinyin = pinyins.empty() ? std::string() : pinyins[i];
        if (token_ids[i].size() != fina_score.size()) {
            ALG_LOGE("token_ids[%d].size():%zu != fina_score.size():%zu\n", i, token_ids[i].size(), fina_score.size());
            return;
        }
        for (int32_t j = 0; j < token_ids[i].size(); ++j) {
            int32_t token = token_ids[i][j];
            if (0 == node->next.count(token)) {
                bool is_end = j == token_ids[i].size() - 1;
                node->next[token] = std::make_unique<ContextState>(
                    token, fina_score[j], node->node_score + fina_score[j], is_end ? node->node_score + fina_score[j] : 0, j + 1,
                    is_end ? ac_threshold : 0.0f, is_end, is_end ? phrase : std::string(), is_end ? pinyin : std::string());
            } else {
                float token_score = std::max(fina_score[j], node->next[token]->token_score);
                node->next[token]->token_score = token_score;
                float node_score = node->node_score + token_score;
                node->next[token]->node_score = node_score;
                bool is_end = (j == token_ids[i].size() - 1) || node->next[token]->is_end;
                node->next[token]->output_score = is_end ? node_score : 0.0f;
                node->next[token]->is_end = is_end;
                if (j == token_ids[i].size() - 1) {
                    node->next[token]->phrase = phrase;
                    node->next[token]->pinyin = pinyin;
                    node->next[token]->ac_threshold = ac_threshold;
                }
            }
            node = node->next[token].get();
        }
    }
    FillFailOutput();
}

std::tuple<float, const ContextState *, const ContextState *> ContextGraph::ForwardOneStep(
    const ContextState *state, int32_t token, bool strict_mode) const
{
    const ContextState *node;
    float score;
    if (1 == state->next.count(token)) {
        node = state->next.at(token).get();
        score = node->token_score;
    } else {
        node = state->fail;
        while (0 == node->next.count(token)) {
            node = node->fail;
            if (-1 == node->token) {
                break;  // root
            }
        }
        if (1 == node->next.count(token)) {
            node = node->next.at(token).get();
        }
        score = node->node_score - state->node_score;
    }

    const ContextState *matched_node = node->is_end ? node : (node->output != nullptr ? node->output : nullptr);
    if (!strict_mode && node->output_score != 0) {
        float output_score =
            node->is_end ? node->node_score : (node->output != nullptr ? node->output->node_score : node->node_score);
        return std::make_tuple(score + output_score - node->node_score, root_.get(), matched_node);
    }
    return std::make_tuple(score + node->output_score, node, matched_node);
}

std::pair<float, const ContextState *> ContextGraph::Finalize(const ContextState *state) const
{
    float score = -state->node_score;
    return std::make_pair(score, root_.get());
}

std::pair<bool, const ContextState *> ContextGraph::IsMatched(const ContextState *state) const
{
    bool status = false;
    const ContextState *node = nullptr;
    if (state->is_end) {
        status = true;
        node = state;
    } else {
        if (state->output != nullptr) {
            status = true;
            node = state->output;
        }
    }
    return std::make_pair(status, node);
}

void ContextGraph::FillFailOutput() const
{
    std::queue<const ContextState *> node_queue;
    for (auto &kv : root_->next) {
        kv.second->fail = root_.get();
        node_queue.push(kv.second.get());
    }
    while (!node_queue.empty()) {
        auto current_node = node_queue.front();
        node_queue.pop();
        for (auto &kv : current_node->next) {
            auto fail = current_node->fail;
            if (1 == fail->next.count(kv.first)) {
                fail = fail->next.at(kv.first).get();
            } else {
                fail = fail->fail;
                while (0 == fail->next.count(kv.first)) {
                    fail = fail->fail;
                    if (-1 == fail->token) {
                        break;
                    }
                }
                if (1 == fail->next.count(kv.first)) {
                    fail = fail->next.at(kv.first).get();
                }
            }
            kv.second->fail = fail;
            // fill the output arc
            auto output = fail;
            while (!output->is_end) {
                output = output->fail;
                if (-1 == output->token) {
                    output = nullptr;
                    break;
                }
            }
            kv.second->output = output;
            kv.second->output_score += output == nullptr ? 0 : output->output_score;
            node_queue.push(kv.second.get());
        }
    }
}
}  // namespace kws2k2_faith
