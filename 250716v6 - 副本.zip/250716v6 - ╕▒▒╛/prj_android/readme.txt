1. 当前路径下执行编译生成Android可执行程序：ndk-build NDK_PROJECT_PATH=. NDK_APPLICATION_MK=./android_compile_exe/Application.mk APP_BUILD_SCRIPT=./android_compile_exe/Android.mk
2. 执行push.bat
3. 到手机路径下，执行./run_dataset.sh
