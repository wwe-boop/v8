#!/bin/sh

echo "=== KWS + IVA Processing on Android ==="
echo "Starting KWS + IVA processing..."
echo "Working directory: $(pwd)"

# 确保目录存在
mkdir -p logs
mkdir -p artifacts

echo "Available files:"
ls -la

# 检查测试文件 (支持短文件名)
TEST_FILE="test_file.txt"
if [ -f "list.txt" ]; then
    TEST_FILE="list.txt"
    echo "Using short filename: list.txt"
fi

if [ -f "$TEST_FILE" ]; then
    echo "Test file list contents:"
    cat "$TEST_FILE"
else
    echo "Error: Test file not found! (tried test_file.txt and list.txt)"
    exit 1
fi

# 检查音频文件
if [ -f "test2.wav" ]; then
    echo "test2.wav found ($(ls -lh test2.wav | awk '{print $5}'))"
else
    echo "Warning: test2.wav not found!"
fi

# 检查可执行文件 (支持短文件名)
EXE_FILE="k2_android_exe"
if [ -f "kws_exe" ]; then
    EXE_FILE="kws_exe"
    echo "Using short executable name: kws_exe"
fi

# 设置库路径
export LD_LIBRARY_PATH=.

# 运行双通道 IVA + KWS 处理
echo ""
echo "Running IVA + KWS processing with $TEST_FILE..."
echo "Command: ./$EXE_FILE $TEST_FILE"
./"$EXE_FILE" "$TEST_FILE" > logs/iva_kws.log 2>&1

echo "Processing completed. Check logs/iva_kws.log for details."
echo "Artifacts saved in artifacts/ directory."

# 显示结果
if [ -f "logs/iva_kws.log" ]; then
    echo "=== Processing Log ==="
    tail -20 logs/iva_kws.log
fi

if [ -f "logs/result.txt" ]; then
    echo "=== Results ==="
    cat logs/result.txt
fi

if [ -d "artifacts" ]; then
    echo "=== Generated Artifacts ==="
    ls -la artifacts/
fi
