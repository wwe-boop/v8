filename,num_channels,result,kws_score_first,e2e_score_first,final_decision_first,kws_score_second,final_decision_second,detected_keyword,total_time_ms,iva_time_ms
pcm/long1.pcm,2,0,0.000000,0.003918,0,0.000000,0,NA,988.9140,779.1430
pcm/long2.pcm,2,0,0.000000,0.004196,0,0.000000,0,NA,1000.3260,775.7200
pcm/long3.pcm,2,0,0.000000,0.005566,0,0.000000,0,NA,1005.6470,780.1350
