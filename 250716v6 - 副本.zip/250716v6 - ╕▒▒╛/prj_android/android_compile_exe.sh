CurDir=$(pwd)
echo "Current directory: $CurDir"
echo "NDK Root: $ANDROID_NDK_ROOT"
# /opt/homebrew/bin/
# 检查NDK是否可用
if [ ! -f "$ANDROID_NDK_ROOT/build/ndk-build" ]; then
    echo "ERROR: NDK not found at $ANDROID_NDK_ROOT"
    echo "Please ensure NDK is properly installed"
    exit 1
fi

echo "Starting NDK build..."
$ANDROID_NDK_ROOT/build/ndk-build NDK_PROJECT_PATH=. \
                                  NDK_APPLICATION_MK=./android_compile_exe/Application.mk \
                                  APP_BUILD_SCRIPT=./android_compile_exe/Android.mk

if [ $? -eq 0 ]; then
    echo " Build successful!"
    echo "Executable: libs/arm64-v8a/k2_android_exe"
    ls -la libs/arm64-v8a/
else
    echo " Build failed!"
    exit 1
fi
