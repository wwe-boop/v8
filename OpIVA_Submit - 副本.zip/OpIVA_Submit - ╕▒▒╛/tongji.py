
# -*- coding: utf-8 -*-
import csv
import os
from collections import defaultdict

stats = defaultdict(lambda: {'total': 0, 'result_1': 0, 'fd1_1': 0})

with open(r'prj_android\artifacts_android\artifacts\1.csv',
          newline='', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        filename = row['filename']
        parts = os.path.normpath(filename).split(os.sep)
        if len(parts) < 2:
            continue
        folder = parts[-2]

        stats[folder]['total'] += 1

        # result ��
        if row['result'] == '1':
            stats[folder]['result_1'] += 1

        # final_decision_first �У�ֻ���������ҵ���1ʱ��ͳ��
        fd1 = row['final_decision_first']
        if fd1 == '1':          # ֻ�����ַ�'1'��NA/0/�������ֶ���ͳ��
            stats[folder]['fd1_1'] += 1

print('folder,total,result_1,final_decision_first_1')
for folder, v in stats.items():
    print(f'{folder},{v["total"]},{v["result_1"]},{v["fd1_1"]}')