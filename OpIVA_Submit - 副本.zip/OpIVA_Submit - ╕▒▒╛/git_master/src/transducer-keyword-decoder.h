#ifndef KWS2K2_FAITH_CSRC_TRANSDUCER_KEYWORD_DECODER_H_
#define KWS2K2_FAITH_CSRC_TRANSDUCER_KEYWORD_DECODER_H_

#include <string>
#include <utility>
#include <vector>

#include "hypothesis.h"
#include "faith_api.h"

namespace kws2k2_faith {

struct TransducerKeywordResult {
    // The decoded token IDs for keywords
    std::vector<int32_t> tokens;
    // The triggered keyword
    std::string keyword;
    std::string pinyin;
    // number of trailing blank frames decoded so far
    int32_t num_tailing_blanks = 0;
    // timestamps[i] contains the output frame index where tokens[i] is decoded.
    std::vector<int32_t> timestamps;
    float ys_prob = 0;
    std::vector<float> ys_probs;
};

class TransducerKeywordDecoder {
public:
    TransducerKeywordDecoder(int32_t max_active_paths, int32_t num_tailing_blanks, int32_t unk_id)
        : max_active_paths_(max_active_paths), num_tailing_blanks_(num_tailing_blanks), unk_id_(unk_id)
    {}

    ~TransducerKeywordDecoder() {};

    int32_t Decode(float* encoder_out, const uint32_t outputSize, ContextGraphPtr contextGraphPrt,
                    std::vector<TransducerKeywordResult>* result,
                    std::shared_ptr<FaithInference> k2Decoder, std::shared_ptr<FaithInference> k2Joiner,
                    int isEchoScene);

private:
    int32_t max_active_paths_;
    int32_t num_tailing_blanks_;
    int32_t unk_id_;
};

}  // namespace kws2k2_faith

#endif  // TRANSDUCER_KEYWORD_DECODER_H_
