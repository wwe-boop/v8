#include "noise-reduction.h"
#include "imedia_fft.h"
#include "faith_api.h"
#include "alg_log.h"
#include <cmath>

#define LOG_TAG "kws2k2:noise_reduction"

namespace kws2k2_faith {

void NoiseReduction::dct(float* x, float* y, int N, int frum_num)
{
    int i, j;
    float* tmp = x;
    int half_len = N / 2;
    for (i = 0; i < frum_num; i++) {
        //flip cat
        for (j = 0; j < half_len; j++) {
            y[j] = x[2 * j + i * N];
            y[N - j - 1] = x[2 * j + 1 + i * N];
        }

        iMedia_K2NS_common_FFT(N, y);
        //重新排列fft输出  dct
        x[i * N + 0] = 2 * (y[0] * imedia_k2ns_dctcos[0] + 0 * imedia_k2ns_dctsin[0]);
        for (j = 1; j < half_len; j++) {
            x[i * N + j] = 2 * (y[2 * j] * imedia_k2ns_dctcos[j] + y[2 * j + 1] * imedia_k2ns_dctsin[j]);
            x[i * N + N - j] = 2 * (y[2 * j] * imedia_k2ns_dctcos[N - j] - y[2 * j + 1] * imedia_k2ns_dctsin[N - j]);
        }
        x[i * N + half_len] = 2 * (y[1] * imedia_k2ns_dctcos[half_len] + 0 * imedia_k2ns_dctsin[half_len]);
    }
}

void NoiseReduction::idct(float* x, float* y, int N, int frum_num)
{
    int i, j;
    float* tmp = x;
    int half_len = N / 2;
    float* tmpr = y + N;
    float* tmpi = y + 2 * N;

    for (i = 0; i < frum_num; i++) {
        // *0.5 flip
        y[0] = 0 * x[0 + i * N];
        x[0 + i * N] = x[0 + i * N] * 0.5;
        for (j = 1; j < N; j++) {
            y[j] = -0.5 * x[N - j + i * N];
            x[j + i * N] = x[j + i * N] * 0.5;
        }
        for (j = 0; j < N; j++) {
            tmpr[j] =
                x[j + i * N] * imedia_k2ns_dctcos[j] - y[j] * (-imedia_k2ns_dctsin[j]);  //dct和idct这里sin系数相反
            tmpi[j] = x[j + i * N] * (-imedia_k2ns_dctsin[j]) + y[j] * imedia_k2ns_dctcos[j];
        }
        y[0] = tmpr[0];
        y[1] = tmpr[half_len];
        for (j = 1; j < half_len; j++) {
            y[2 * j] = tmpr[j];
            y[2 * j + 1] = -tmpi[j];
        }
        iMedia_K2NS_common_IFFT(N, y);
        for (j = 0; j < half_len; j++) {
            x[2 * j + i * N] = y[j] / 256;
            x[2 * j + 1 + i * N] = y[N - j - 1] / 256;
        }
    }
}

void overlap_and_add(float *signal, int frames, int frame_length, int frame_step, short *result, int result_len) {
    // 计算输出大小
    int output_size = (frames - 1) * frame_step + frame_length;

    // 初始化结果数组
    for (int i = 0; i < result_len; i++) {
        result[i] = 0;
    }

    // 计算子帧长度和步长
    int subframe_length = frame_length; // 假设没有重叠
    int subframe_step = frame_step; // 假设步长等于帧步长
    int subframes_per_frame = frame_length / subframe_length;

    // 遍历每一帧
    for (int f = 0; f < frames; f++) {
        for (int s = 0; s < subframes_per_frame; s++) {
            int index = f * frame_step + s * subframe_length;
            for (int l = 0; l < subframe_length; l++) {
                if (index + l < result_len) {
                    float tmp_out = signal[f * frame_length + l] * INT16_MAX_F / 2.0;
                    if(tmp_out > INT16_MAX) tmp_out = INT16_MAX;
                    else if(tmp_out < INT16_MIN) tmp_out = INT16_MIN;
                    result[index + l] += (short)(tmp_out);
                }
            }
        }
    }
}
int NoiseReduction::Apply(const short *in, int in_size, short *out, int out_size, std::shared_ptr<FaithInference> inferNs, int isSqrt)
{
    int i,j, frame_idx,tmp_idx;
    int nframe;
    float ftmp;
    int ret = 0;
    if (IMEDIA_K2NS_2S_LEN != out_size) {
        return IMEDIA_K2NS_INV_LEN;
    }

    int address_offset = 0;
    float *fbase = new float[IMEDIA_K2NS_DCT_DIM_WIN*3 + IMEDIA_K2NS_NFRAME * IMEDIA_K2NS_DCT_DIM_WIN + IMEDIA_K2NS_NFRAME * IMEDIA_K2NS_DCT_DIM_WIN + IMEDIA_K2NS_2S_LEN]();
    float *fwin = fbase + address_offset;
    address_offset += IMEDIA_K2NS_DCT_DIM_WIN*3;
    float *fdct = fbase + address_offset;
    address_offset += IMEDIA_K2NS_NFRAME * IMEDIA_K2NS_DCT_DIM_WIN;
    float *fmask = fbase + address_offset;
    address_offset += IMEDIA_K2NS_NFRAME * IMEDIA_K2NS_DCT_DIM_WIN;
    float *fin = fbase + address_offset;

    for(i = 0; i < IMEDIA_K2NS_2S_LEN; i++){
        fin[i] = in[i] / INT16_MAX_F;
    }
    // add window
    for (frame_idx = 0; frame_idx < IMEDIA_K2NS_NFRAME_OUT; frame_idx++) {
        for (i = 0; i < IMEDIA_K2NS_DCT_DIM_WIN; i++) {
            if(frame_idx * IMEDIA_K2NS_FRAME_SHIFT + i < IMEDIA_K2NS_2S_LEN) {
                fdct[frame_idx * IMEDIA_K2NS_DCT_DIM_WIN + i] = fin[frame_idx * IMEDIA_K2NS_FRAME_SHIFT + i] * imedia_k2ns_addWin[i];
            }
        }
    }

    dct(fdct, fwin, IMEDIA_K2NS_DCT_DIM_WIN, IMEDIA_K2NS_NFRAME);

    //推理, in=fdct, out=fmask
    std::vector<float> fdct_v(IMEDIA_K2NS_NFRAME * IMEDIA_K2NS_DCT_DIM_WIN, 0);
    for (i = 0; i < IMEDIA_K2NS_NFRAME * IMEDIA_K2NS_DCT_DIM_WIN; i++) {
        fdct_v[i] = fdct[i];
    }

    ret = inferNs->Compute(fdct_v, IMEDIA_K2NS_NFRAME * IMEDIA_K2NS_DCT_DIM_WIN, fmask, IMEDIA_K2NS_NFRAME_OUT * IMEDIA_K2NS_DCT_DIM_WIN);
    if (ret != 0) {
        ALG_LOGE("ns Compute failed.\n");
        delete [] fbase;
        return -1;
    }

    for (i = 0; i < IMEDIA_K2NS_NFRAME_OUT* IMEDIA_K2NS_DCT_DIM_WIN; i++) {
        if(isSqrt){
            fdct[i] = fdct[i] * sqrt(fmask[i]);
        }else{
            fdct[i] = fdct[i] * fmask[i];
        }
    }

    idct(fdct, fwin, IMEDIA_K2NS_DCT_DIM_WIN, IMEDIA_K2NS_NFRAME_OUT);

    // add window
    for (frame_idx = 0; frame_idx < IMEDIA_K2NS_NFRAME_OUT; frame_idx++) {
        for (i = 0; i < IMEDIA_K2NS_DCT_DIM_WIN; i++) {
            fdct[frame_idx * IMEDIA_K2NS_DCT_DIM_WIN + i] = fdct[frame_idx * IMEDIA_K2NS_DCT_DIM_WIN + i] * imedia_k2ns_addWin[i];
        }
    }
    overlap_and_add(fdct, IMEDIA_K2NS_NFRAME_OUT, IMEDIA_K2NS_DCT_DIM_WIN, IMEDIA_K2NS_FRAME_SHIFT, out, out_size);
    delete [] fbase;
    return IMEDIA_K2NS_EOK;
}

}  // namespace kws2k2_faith