#include <fcntl.h>
#include <getopt.h>
#include <string.h>
#include <sched.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <iostream>
#include <fstream>
#include <vector>

#include "faith_api.h"

#define LOG_TAG "kws2k2:faith_api"
#include "alg_log.h"

using namespace std;

namespace kws2k2_faith {
size_t FaithInference::NumElements(const DimArray &shape, int tensorId)
{
    size_t NumElements = 1;
    if (shape[DIM_N][tensorId] > 0) {
        NumElements *= shape[DIM_N][tensorId];
    }
    if (shape[DIM_C][tensorId] > 0) {
        NumElements *= shape[DIM_C][tensorId];
    }
    if (shape[DIM_H][tensorId] > 0) {
        NumElements *= shape[DIM_H][tensorId];
    }
    if (shape[DIM_W][tensorId] > 0) {
        NumElements *= shape[DIM_W][tensorId];
    }
    return NumElements;
}

size_t FaithInference::GetBytesOfDataType(DATA_TYPE type)
{
    switch (type) {
        case DATA_TYPE::INT_32:
        case DATA_TYPE::UINT_32:
        case DATA_TYPE::FP_32:
            return sizeof(int);
        case DATA_TYPE::FP_16:
            return sizeof(F16);
        default:
            return 0;
    }
}

void FaithInference::CreateInputBufferArray(const TensorSpecArray *inputSpecs, BufferArray &buffers)
{
    for (int inIdx = 0; inIdx < inputSpecs->length; ++inIdx) {
        size_t bufferSize = NumElements(inputSpecs->dims, inIdx) * GetBytesOfDataType(inputSpecs->dts[inIdx]);
        buffers[inIdx] = new char[bufferSize];
    }
}

void FaithInference::DestroyInputBufferArray(BufferArray &buffers, int numBuffer)
{
    for (int inIdx = 0; inIdx < numBuffer; ++inIdx) {
        delete[] reinterpret_cast<char *>(buffers[inIdx]);
    }
}

void FaithInference::InitBuffer(const std::vector<float> &vals, const TensorSpecArray *specs, int tensorId,
                                size_t offset, BufferArray &buffers)
{
    size_t numElem = NumElements(specs->dims, tensorId);
    if (vals.size() - offset < numElem) {
        float *data = reinterpret_cast<float *>(buffers[tensorId]);
        size_t dataLen = numElem * GetBytesOfDataType(specs->dts[tensorId]) / sizeof(float);
        std::fill(data, data + dataLen, 1.0f);
        return;
    }
    const float *valPtr = vals.data() + offset;
    switch (specs->dts[tensorId]) {
        case DATA_TYPE::FP_16: {
            F16 *data = reinterpret_cast<F16 *>(buffers[tensorId]);
            for (size_t valIdx = 0; valIdx < numElem; ++valIdx) {
                data[valIdx] = (F16)valPtr[valIdx];
            }
            break;
        }

        case DATA_TYPE::FP_32: {
            float *data = reinterpret_cast<float *>(buffers[tensorId]);
            for (size_t valIdx = 0; valIdx < numElem; ++valIdx) {
                data[valIdx] = valPtr[valIdx];
            }
            break;
        }

        case DATA_TYPE::INT_32: {
            int *data = reinterpret_cast<int *>(buffers[tensorId]);
            for (size_t valIdx = 0; valIdx < numElem; ++valIdx) {
                data[valIdx] = (int)valPtr[valIdx];
            }
            break;
        }

        case DATA_TYPE::UINT_32: {
            unsigned int *data = reinterpret_cast<unsigned int *>(buffers[tensorId]);
            for (size_t valIdx = 0; valIdx < numElem; ++valIdx) {
                data[valIdx] = (unsigned int)valPtr[valIdx];
            }
            break;
        }

        default:
            break;
    }
}

void FaithInference::InitBufferArray(const std::vector<float> &vals, const TensorSpecArray *specs, BufferArray &buffers)
{
    size_t offset = 0;
    for (int idx = 0; idx < specs->length; ++idx) {
        InitBuffer(vals, specs, idx, offset, buffers);
        offset += NumElements(specs->dims, idx);
    }
}

ReturnStatus FaithInference::CreateModelFs(char const *modelPath, int *dataFd, char **dataBuf, size_t *dataLen)
{
    int fd = open(modelPath, O_RDONLY);
    if (fd == -1) {
        ALG_LOGE("Failed to open file, fd = %d .\n", fd);
        return ReturnStatus::FAIL;
    }
    struct stat ss;
    if (fstat(fd, &ss) == -1) {
        ALG_LOGE("Failed to get file size, ret = -1 .\n");
        close(fd); // 关闭文件
        return ReturnStatus::FAIL;
    }
    size_t len = ss.st_size;
    char *buf = (char *)mmap(nullptr, len, PROT_READ, MAP_SHARED, fd, 0);
    if (buf == MAP_FAILED) {
        ALG_LOGE("Failed to mmap file .\n");
        close(fd); // 关闭文件
        return ReturnStatus::FAIL;
    }
    *dataFd = fd;
    *dataBuf = buf;
    *dataLen = len;
    return ReturnStatus::SUCCESS;
}

void FaithInference::DestroyModelFs(int dataFd, char *dataBuf, size_t dataLen)
{
    munmap(dataBuf, dataLen);
    if (-1 != dataFd) {
        close(dataFd);
    }
}

int32_t FaithInference::InitModelEng(char const *modelPath)
{
    ReturnStatus ret = ReturnStatus::SUCCESS;
    ALG_LOGI("InitInfer start,modelPath = %s\n", modelPath);
    // read model file
    ret = CreateModelFs(modelPath, &modelFd, &modelFs, &modelFsLen);
    if (ret != ReturnStatus::SUCCESS) {
        ALG_LOGE("CreateModelFs failed. \n");
        return -1;
    }

    AFFINITY_TYPE backend = AFFINITY_TYPE::CPU_HIGH_PERFORMANCE;

    // INIT
    if (model == NULL) {
        model = CreateModelWithFileStream(modelFs, backend, NULL);
    }
    if (model == NULL) {
        ALG_LOGE("CreateModelWithFileStream failed. \n");
        DestroyModelFs(modelFd, modelFs, modelFsLen);
        return -1;
    }
    inputSpecs = MakeSharedNoThrow<TensorSpecArray>(GetNumInputsFromModel(model));
    GetInputDataInfoFromModel(model, inputSpecs.get()->length, inputSpecs.get()->names, inputSpecs.get()->dims[DIM_N],
                              inputSpecs.get()->dims[DIM_C], inputSpecs.get()->dims[DIM_H],
                              inputSpecs.get()->dims[DIM_W], inputSpecs.get()->dts, inputSpecs.get()->dfs);
    PrepareModel(model, inputSpecs.get()->length, (const char **)inputSpecs.get()->names, inputSpecs.get()->dims[DIM_N],
                 inputSpecs.get()->dims[DIM_C], inputSpecs.get()->dims[DIM_H], inputSpecs.get()->dims[DIM_W],
                 inputSpecs.get()->dts, inputSpecs.get()->dfs);
    modelResult = AllocAllResultHandle(model);
    CreateInputBufferArray(inputSpecs.get(), inputBuffers);
    outputSpecs = MakeSharedNoThrow<TensorSpecArray>(GetNumOutputsFromResultHandle(modelResult));
    GetOutputDataInfoFromResultHandle(modelResult, outputSpecs.get()->length, outputSpecs.get()->names,
                                      outputSpecs.get()->dims[DIM_N], outputSpecs.get()->dims[DIM_C],
                                      outputSpecs.get()->dims[DIM_H], outputSpecs.get()->dims[DIM_W],
                                      outputSpecs.get()->dts, outputSpecs.get()->dfs);
    if (modelFd != -1 || modelFs != NULL) {
        DestroyModelFs(modelFd, modelFs, modelFsLen);
    }
    return 0;
}

int32_t FaithInference::Compute(const std::vector<float> inputData, const uint32_t inputSize, float *outputData,
                                const uint32_t outputSize)
{
    if (inputData.empty() || inputSize == 0) {
        ALG_LOGE("Input null pointer or matrix is empty, size: %u\n", inputSize);
        return -1;
    }
    InitBufferArray(inputData, inputSpecs.get(), inputBuffers);  // copy
    RunModel(model, modelResult, inputSpecs.get()->length, (const char **)inputSpecs.get()->names, inputBuffers);
    BufferArray outputBuffers;
    GetOutputDataFromResultHandle(modelResult, outputSpecs.get()->length, outputBuffers);
    for (int idx = 0; idx < outputSpecs.get()->length; ++idx) {
        switch (outputSpecs.get()->dts[idx]) {
            case DATA_TYPE::FP_16: {
                F16 *pfData = reinterpret_cast<F16 *>(outputBuffers[0]);
                for (int i = 0; i < outputSize; i++) {
                    outputData[i] = (float)pfData[i];
                }
                break;
            }
            case DATA_TYPE::FP_32: {
                float *pfData = reinterpret_cast<float *>(outputBuffers[0]);
                for (int i = 0; i < outputSize; i++) {
                    outputData[i] = pfData[i];
                }
                break;
            }
            case DATA_TYPE::INT_32: {
                int *pfData = reinterpret_cast<int *>(outputBuffers[0]);
                for (int i = 0; i < outputSize; i++) {
                    outputData[i] = (int)pfData[i];
                }
                break;
            }
            case DATA_TYPE::UINT_32: {
                unsigned int *pfData = reinterpret_cast<unsigned int *>(outputBuffers[0]);
                for (int i = 0; i < outputSize; i++) {
                    outputData[i] = (unsigned int)pfData[i];
                }
                break;
            }
            default:
                break;
        }
    }
    return 0;
}

int32_t FaithInference::DestroyModelEng()
{
    if (modelResult != NULL) {
        FreeResultHandle(modelResult);
    }
    if (inputSpecs != nullptr) {
        DestroyInputBufferArray(inputBuffers, inputSpecs.get()->length);
    }
    if (model != NULL) {
        DestroyModel(model);
        model = NULL;
    }
    return 0;
}
}  // namespace kws2k2_faith