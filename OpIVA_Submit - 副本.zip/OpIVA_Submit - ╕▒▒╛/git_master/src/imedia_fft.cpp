#include "imedia_fft.h"
#include "imedia_common_basic_op.h"
#include "alg_log.h"

#define LOG_TAG "kws2k2:imedia_fft"
namespace kws2k2_faith {
//FFT��������
#define IMEDIA_FFT_LEN_8K      ( 256)
#define IMEDIA_FFT_LEN_16K     ( 512)
#define IMEDIA_FFT_LEN_32K     (1024)


/*
���� ����Ҷ/����/���� �任
    ά��       :һά
    ���ݳ���   :2��������
    decimation :Ƶ��
    ����       :4, 2
    ����       :inplace
    ����       :use
����
    cdft: ������ɢ����Ҷ�任
    rdft: ʵ����ɢ����Ҷ�任
    ddct: ��ɢ���ұ任
    ddst: ��ɢ���ұ任
    dfct: RDFT�����ұ任 (Real Symmetric DFT)
    dfst: RDFT�����ұ任 (Real Anti-symmetric DFT)
����ԭ��
    IMEDIA_VOID cdft(IMEDIA_INT32, IMEDIA_INT32, IMEDIA_FLOAT *, IMEDIA_INT32 *, IMEDIA_FLOAT *);
    IMEDIA_VOID rdft(IMEDIA_INT32, IMEDIA_INT32, IMEDIA_FLOAT *, IMEDIA_INT32 *, IMEDIA_FLOAT *);
    IMEDIA_VOID ddct(IMEDIA_INT32, IMEDIA_INT32, IMEDIA_FLOAT *, IMEDIA_INT32 *, IMEDIA_FLOAT *);
    IMEDIA_VOID ddst(IMEDIA_INT32, IMEDIA_INT32, IMEDIA_FLOAT *, IMEDIA_INT32 *, IMEDIA_FLOAT *);
    IMEDIA_VOID dfct(IMEDIA_INT32, IMEDIA_FLOAT *, IMEDIA_FLOAT *, IMEDIA_INT32 *, IMEDIA_FLOAT *);
    IMEDIA_VOID dfst(IMEDIA_INT32, IMEDIA_FLOAT *, IMEDIA_FLOAT *, IMEDIA_INT32 *, IMEDIA_FLOAT *);


-------- ���� DFT (Discrete Fourier Transform��ɢ����Ҷ�任) --------
    [����]
        <����һ>
            X[k] = sum_j=0^n-1 fx[j]*exp(2*pi*i*j*ik/n), 0<=ik<n
        <������>
            X[k] = sum_j=0^n-1 fx[j]*exp(-2*pi*i*j*ik/n), 0<=ik<n
        (ע��: sum_j=0^n-1 is a summation from j=0 to n-1)
    [�÷�]
        <����һ>
            ip[0] = 0; // ��ʼ��һ��
            cdft(2*n, 1, fa, ip, fw);
        <������>
            ip[0] = 0; // ��ʼ��һ��
            cdft(2*n, -1, fa, ip, fw);
    [����]
        2*n            :���ݳ��� (int)
                        n >= 1, n = 2�ı���
        fa[0...2*n-1]   :input/output data (float *)
                        ��������
                            fa[2*j] = Re(x[j]),
                            fa[2*j+1] = Im(x[j]), 0<=j<n
                        �������
                            fa[2*k] = Re(X[k]),
                            fa[2*k+1] = Im(X[k]), 0<=k<n
        ip[0...*]       :ջ�ռ� for bit reversal (int *)
                        ip�ĳ��� >= 2+sqrt(n)
                        ip�ĳ��� >= 2+(1<<(int)(log(n+0.5)/log(2))/2).
                        ip[0],ip[1] Ϊָ�� cos/sin �����ָ��.
        fw[0...n/2-1]   :cos/sin ���� (float *)
                        fw[],ip[] are initialized if ip[0] == 0.
    [ע��]
            cdft(2*n, -1, fa, ip, fw);
            �ķ��任Ϊ:
            cdft(2*n, 1, fa, ip, fw);
            for (j = 0; j <= 2 * n - 1; j++) {
                fa[j] *= 1.0 / n;
            }
        .


-------- ʵ�� DFT / ʵ�� IDFT --------
    [����]
        <����һ> RDFT
            R[k] = sum_j=0^n-1 fa[j]*cos(2*pi*j*ik/n), 0<=ik<=n/2
            I[k] = sum_j=0^n-1 fa[j]*sin(2*pi*j*ik/n), 0<ik<n/2
        <������> IRDFT (excluding scale)
            fa[k] = (R[0] + R[n/2]*cos(pi*ik))/2 +
                   sum_j=1^n/2-1 R[j]*cos(2*pi*j*ik/n) +
                   sum_j=1^n/2-1 I[j]*sin(2*pi*j*ik/n), 0<=ik<n
    [�÷�]
        <����һ>
            ip[0] = 0; // ��ʼ��һ֡
            rdft(n, 1, fa, ip, fw);
        <������>
            ip[0] = 0; // ��ʼ��һ֡
            rdft(n, -1, fa, ip, fw);
    [����]
        n              :���ݳ��� (int)
                        n >= 2, n = 2��������
        fa[0...n-1]     :����������� (float *)
                        <����һ>
                            �������
                                fa[2*ik] = R[ik], 0<=ik<n/2
                                fa[2*ik+1] = I[ik], 0<ik<n/2
                                fa[1] = R[n/2]
                        <������>
                            ��������
                                fa[2*j] = R[j], 0<=j<n/2
                                fa[2*j+1] = I[j], 0<j<n/2
                                fa[1] = R[n/2]
        ip[0...*]       :ջ�ռ� for bit reversal (int *)
                        ip�ĳ��� >= 2+sqrt(n/2)
                        strictly,
                        ip�ĳ��� >= 2+(1<<(int)(log(n/2+0.5)/log(2))/2).
                        ip[0],ip[1] Ϊָ�� cos/sin �����ָ��.
        fw[0...n/2-1]   :cos/sin ���� (float *)
                        fw[],ip[] are initialized if ip[0] == 0.
    [ע��]
            rdft(n, 1, fa, ip, fw);
        �ķ��任Ϊ
            rdft(n, -1, fa, ip, fw);
            for (j = 0; j <= n - 1; j++) {
                fa[j] *= 2.0 / n;
            }
        .


-------- DCT (Discrete Cosine Transforml ��ɢ���ұ任) / DCT ���任--------
    [����]
        <����һ> IDCT (excluding scale)
            C[k] = sum_j=0^n-1 fa[j]*cos(pi*j*(ik+1/2)/n), 0<=ik<n
        <������> DCT
            C[k] = sum_j=0^n-1 fa[j]*cos(pi*(j+1/2)*ik/n), 0<=ik<n
    [ʹ��]
        <����һ>
            ip[0] = 0; // ��ʼ��һ֡
            ddct(n, 1, fa, ip, fw);
        <������>
            ip[0] = 0; // ��ʼ��һ֡
            ddct(n, -1, fa, ip, fw);
    [����]
        n              :���ݳ��� (int)
                        n >= 2, n = 2��������
        fa[0...n-1]     :����������� (float *)
                        �������
                            fa[ik] = C[ik], 0<=ik<n
        ip[0...*]       :ջ�ռ� for bit reversal (int *)
                        ip�ĳ��� >= 2+sqrt(n/2)
                        ip�ĳ��� >= 2+(1<<(int)(log(n/2+0.5)/log(2))/2).
                        ip[0],ip[1] Ϊָ�� cos/sin �����ָ��.
        fw[0...n*5/4-1] :cos/sin ���� (float *)
                        fw[],ip[] are initialized if ip[0] == 0.
    [ע��]
            ddct(n, -1, fa, ip, fw);
        �ķ��任Ϊ
            fa[0] *= 0.5;
            ddct(n, 1, fa, ip, fw);
            for (j = 0; j <= n - 1; j++) {
                fa[j] *= 2.0 / n;
            }
        .


-------- DST (Discrete Sine Transform ��ɢ���ұ仯) / DST ���任--------
    [����]
        <����һ> IDST (excluding scale)
            S[k] = sum_j=1^n fa[j]*sin(pi*j*(ik+1/2)/n), 0<=ik<n
        <case2> DST
            S[k] = sum_j=0^n-1 fa[j]*sin(pi*(j+1/2)*ik/n), 0<ik<=n
    [ʹ��]
        <����һ>
            ip[0] = 0; // ��ʼ��һ֡
            ddst(n, 1, fa, ip, fw);
        <������>
            ip[0] = 0; // ��ʼ��һ֡
            ddst(n, -1, fa, ip, fw);
    [����]
        n              :���ݳ��� (int)
                        n >= 2, n = 2��������
        fa[0...n-1]     :����������� (float *)
                        <����һ>
                            ��������
                                fa[j] = A[j], 0<j<n
                                fa[0] = A[n]
                            �������
                                fa[k] = S[k], 0<=ik<n
                        <������>
                            �������
                                fa[k] = S[k], 0<ik<n
                                fa[0] = S[n]
        ip[0...*]       :ջ�ռ� for bit reversal (int *)
                        ip�ĳ��� >= 2+sqrt(n/2)
                        ip�ĳ��� >= 2+(1<<(int)(log(n/2+0.5)/log(2))/2).
                        ip[0],ip[1] Ϊָ�� cos/sin �����ָ��.
        fw[0...n*5/4-1] :cos/sin ���� (float *)
                        fw[],ip[] are initialized if ip[0] == 0.
    [ע��]
            ddst(n, -1, fa, ip, fw);
        �ķ��任Ϊ
            fa[0] *= 0.5;
            ddst(n, 1, fa, ip, fw);
            for (j = 0; j <= n - 1; j++) {
                fa[j] *= 2.0 / n;
            }
        .


-------- RDFT �����ұ任 (Real Symmetric DFT) --------
    [����]
        C[k] = sum_j=0^n fa[j]*cos(pi*j*ik/n), 0<=ik<=n
    [ʹ��]
        ip[0] = 0; // ��ʼ��һ֡
        dfct(n, fa, t, ip, fw);
    [����]
        n              :���ݳ��� - 1 (int)
                        n >= 2, n = 2��������
        fa[0...n]       :����������� (float *)
                        �������
                            fa[ik] = C[ik], 0<=ik<=n
        ft[0...n/2]     :ջ�ռ� (float *)
        ip[0...*]       :ջ�ռ� for bit reversal (int *)
                        ip�ĳ��� >= 2+sqrt(n/4)
                        ip�ĳ��� >= 2+(1<<(int)(log(n/4+0.5)/log(2))/2).
                        ip[0],ip[1] Ϊָ�� cos/sin �����ָ��.
        fw[0...n*5/8-1] :cos/sin ���� (float *)
                        fw[],ip[] are initialized if ip[0] == 0.
    [ע��]
            fa[0] *= 0.5;
            fa[n] *= 0.5;
            dfct(n, fa, t, ip, fw);
        �ķ��任Ϊ
            fa[0] *= 0.5;
            fa[n] *= 0.5;
            dfct(n, fa, t, ip, fw);
            for (j = 0; j <= n; j++) {
                fa[j] *= 2.0 / n;
            }
        .


-------- RDFT �����ұ任(Real Anti-symmetric DFT) --------
    [����]
        S[k] = sum_j=1^n-1 fa[j]*sin(pi*j*ik/n), 0<ik<n
    [ʹ��]
        ip[0] = 0; // ��ʼ��һ֡
        dfst(n, fa, ft, ip, fw);
    [����]
        n              :���ݳ��� + 1 (int)
                        n >= 2, n = 2��������
        fa[0...n-1]     :����������� (float *)
                        �������
                            fa[ik] = S[ik], 0<ik<n
                        (fa[0] is used for work area)
        ft[0...n/2-1]   :ջ�ռ� (float *)
        ip[0...*]       :ջ�ռ� for bit reversal (int *)
                        ip�ĳ��� >= 2+sqrt(n/4)
                        ip�ĳ��� >= 2+(1<<(int)(log(n/4+0.5)/log(2))/2).
                        ip[0],ip[1] Ϊָ�� cos/sin �����ָ��.
        fw[0...n*5/8-1] :cos/sin ���� (float *)
                        fw[],ip[] are initialized if ip[0] == 0.
    [ע��]
            dfst(n, fa, ft, ip, fw);
        �ķ��任Ϊ
            dfst(n, fa, ft, ip, fw);
            for (j = 1; j <= n - 1; j++) {
                fa[j] *= 2.0 / n;
            }
        .


��¼ :
    cos/sin ����Ϊ���߼���.
    fw[] �� ip[] ���м��������.
*/

IMEDIA_VOID cdft(IMEDIA_INT32 n, IMEDIA_INT32 isgn, IMEDIA_FLOAT *fa, IMEDIA_INT32 *ip, IMEDIA_FLOAT *fw)
{
    IMEDIA_VOID makewt(IMEDIA_INT32 inw, IMEDIA_INT32 * ip, IMEDIA_FLOAT * fw);
    IMEDIA_VOID bitrv2(IMEDIA_INT32 n, IMEDIA_INT32 * ip, IMEDIA_FLOAT * fa);
    IMEDIA_VOID bitrv2conj(IMEDIA_INT32 n, IMEDIA_INT32 * ip, IMEDIA_FLOAT * fa);
    IMEDIA_VOID cftfsub(IMEDIA_INT32 n, IMEDIA_FLOAT * fa, IMEDIA_FLOAT * fw);
    IMEDIA_VOID cftbsub(IMEDIA_INT32 n, IMEDIA_FLOAT * fa, IMEDIA_FLOAT * fw);

    if (n > (ip[0] << 2))
    {
        makewt(n >> 2, ip, fw);
    }
    if (n > 4)
    {
        if (isgn >= 0)
        {
            bitrv2(n, ip + 2, fa);
            cftfsub(n, fa, fw);
        }
        else
        {
            bitrv2conj(n, ip + 2, fa);
            cftbsub(n, fa, fw);
        }
    }
    else if (n == 4)
    {
        cftfsub(n, fa, fw);
    }
}

IMEDIA_VOID rdft(IMEDIA_INT32 n, IMEDIA_INT32 isgn, IMEDIA_FLOAT *fa, IMEDIA_INT32 *ip, IMEDIA_FLOAT *fw)
{
    IMEDIA_VOID makewt(IMEDIA_INT32 inw, IMEDIA_INT32 * ip, IMEDIA_FLOAT * fw);
    IMEDIA_VOID makect(IMEDIA_INT32 inc, IMEDIA_INT32 * ip, IMEDIA_FLOAT * fc);
    IMEDIA_VOID bitrv2(IMEDIA_INT32 n, IMEDIA_INT32 * ip, IMEDIA_FLOAT * fa);
    IMEDIA_VOID cftfsub(IMEDIA_INT32 n, IMEDIA_FLOAT * fa, IMEDIA_FLOAT * fw);
    IMEDIA_VOID cftbsub(IMEDIA_INT32 n, IMEDIA_FLOAT * fa, IMEDIA_FLOAT * fw);
    IMEDIA_VOID rftfsub(IMEDIA_INT32 n, IMEDIA_FLOAT * fa, IMEDIA_INT32 inc, IMEDIA_FLOAT * fc);
    IMEDIA_VOID rftbsub(IMEDIA_INT32 n, IMEDIA_FLOAT * fa, IMEDIA_INT32 inc, IMEDIA_FLOAT * fc);
    IMEDIA_INT32 inw, inc;
    IMEDIA_FLOAT fxi;

    inw = ip[0];
    if (n > (inw << 2))
    {
        inw = n >> 2;
        makewt(inw, ip, fw);
    }
    inc = ip[1];
    if (n > (inc << 2))
    {
        inc = n >> 2;
        makect(inc, ip, fw + inw);
    }
    if (isgn >= 0)
    {
        if (n > 4)
        {
            bitrv2(n, ip + 2, fa);
            cftfsub(n, fa, fw);
            rftfsub(n, fa, inc, fw + inw);
        }
        else if (n == 4)
        {
            cftfsub(n, fa, fw);
        }
        fxi = fa[0] - fa[1];
        fa[0] += fa[1];
        fa[1] = fxi;
    }
    else
    {
        fa[1] = 0.5f * (fa[0] - fa[1]);
        fa[0] -= fa[1];
        if (n > 4)
        {
            rftbsub(n, fa, inc, fw + inw);
            bitrv2(n, ip + 2, fa);
            cftbsub(n, fa, fw);
        }
        else if (n == 4)
        {
            cftfsub(n, fa, fw);
        }
    }
}

IMEDIA_VOID ddct(IMEDIA_INT32 n, IMEDIA_INT32 isgn, IMEDIA_FLOAT *fa, IMEDIA_INT32 *ip, IMEDIA_FLOAT *fw)
{
    IMEDIA_VOID makewt(IMEDIA_INT32 inw, IMEDIA_INT32 * ip, IMEDIA_FLOAT * fw);
    IMEDIA_VOID makect(IMEDIA_INT32 inc, IMEDIA_INT32 * ip, IMEDIA_FLOAT * fc);
    IMEDIA_VOID bitrv2(IMEDIA_INT32 n, IMEDIA_INT32 * ip, IMEDIA_FLOAT * fa);
    IMEDIA_VOID cftfsub(IMEDIA_INT32 n, IMEDIA_FLOAT * fa, IMEDIA_FLOAT * fw);
    IMEDIA_VOID cftbsub(IMEDIA_INT32 n, IMEDIA_FLOAT * fa, IMEDIA_FLOAT * fw);
    IMEDIA_VOID rftfsub(IMEDIA_INT32 n, IMEDIA_FLOAT * fa, IMEDIA_INT32 inc, IMEDIA_FLOAT * fc);
    IMEDIA_VOID rftbsub(IMEDIA_INT32 n, IMEDIA_FLOAT * fa, IMEDIA_INT32 inc, IMEDIA_FLOAT * fc);
    IMEDIA_VOID dctsub(IMEDIA_INT32 n, IMEDIA_FLOAT * fa, IMEDIA_INT32 inc, IMEDIA_FLOAT * fc);
    IMEDIA_INT32 j, inw, inc;
    IMEDIA_FLOAT fxr;

    inw = ip[0];
    if (n > (inw << 2))
    {
        inw = n >> 2;
        makewt(inw, ip, fw);
    }
    inc = ip[1];
    if (n > inc)
    {
        inc = n;
        makect(inc, ip, fw + inw);
    }
    if (isgn < 0)
    {
        fxr = fa[n - 1];
        for (j = n - 2; j >= 2; j -= 2)
        {
            fa[j + 1] = fa[j] - fa[j - 1];
            fa[j] += fa[j - 1];
        }
        fa[1] = fa[0] - fxr;
        fa[0] += fxr;
        if (n > 4)
        {
            rftbsub(n, fa, inc, fw + inw);
            bitrv2(n, ip + 2, fa);
            cftbsub(n, fa, fw);
        }
        else if (n == 4)
        {
            cftfsub(n, fa, fw);
        }
    }
    dctsub(n, fa, inc, fw + inw);
    if (isgn >= 0)
    {
        if (n > 4)
        {
            bitrv2(n, ip + 2, fa);
            cftfsub(n, fa, fw);
            rftfsub(n, fa, inc, fw + inw);
        }
        else if (n == 4)
        {
            cftfsub(n, fa, fw);
        }
        fxr = fa[0] - fa[1];
        fa[0] += fa[1];
        for (j = 2; j < n; j += 2)
        {
            fa[j - 1] = fa[j] - fa[j + 1];
            fa[j] += fa[j + 1];
        }
        fa[n - 1] = fxr;
    }
}

IMEDIA_VOID ddst(IMEDIA_INT32 n, IMEDIA_INT32 isgn, IMEDIA_FLOAT *fa, IMEDIA_INT32 *ip, IMEDIA_FLOAT *fw)
{
    IMEDIA_VOID makewt(IMEDIA_INT32 inw, IMEDIA_INT32 * ip, IMEDIA_FLOAT * fw);
    IMEDIA_VOID makect(IMEDIA_INT32 inc, IMEDIA_INT32 * ip, IMEDIA_FLOAT * fc);
    IMEDIA_VOID bitrv2(IMEDIA_INT32 n, IMEDIA_INT32 * ip, IMEDIA_FLOAT * fa);
    IMEDIA_VOID cftfsub(IMEDIA_INT32 n, IMEDIA_FLOAT * fa, IMEDIA_FLOAT * fw);
    IMEDIA_VOID cftbsub(IMEDIA_INT32 n, IMEDIA_FLOAT * fa, IMEDIA_FLOAT * fw);
    IMEDIA_VOID rftfsub(IMEDIA_INT32 n, IMEDIA_FLOAT * fa, IMEDIA_INT32 inc, IMEDIA_FLOAT * fc);
    IMEDIA_VOID rftbsub(IMEDIA_INT32 n, IMEDIA_FLOAT * fa, IMEDIA_INT32 inc, IMEDIA_FLOAT * fc);
    IMEDIA_VOID dstsub(IMEDIA_INT32 n, IMEDIA_FLOAT * fa, IMEDIA_INT32 inc, IMEDIA_FLOAT * fc);
    IMEDIA_INT32 j, inw, inc;
    IMEDIA_FLOAT fxr;

    inw = ip[0];
    if (n > (inw << 2))
    {
        inw = n >> 2;
        makewt(inw, ip, fw);
    }
    inc = ip[1];
    if (n > inc)
    {
        inc = n;
        makect(inc, ip, fw + inw);
    }
    if (isgn < 0)
    {
        fxr = fa[n - 1];
        for (j = n - 2; j >= 2; j -= 2)
        {
            fa[j + 1] = -fa[j] - fa[j - 1];
            fa[j] -= fa[j - 1];
        }
        fa[1] = fa[0] + fxr;
        fa[0] -= fxr;
        if (n > 4)
        {
            rftbsub(n, fa, inc, fw + inw);
            bitrv2(n, ip + 2, fa);
            cftbsub(n, fa, fw);
        }
        else if (n == 4)
        {
            cftfsub(n, fa, fw);
        }
    }
    dstsub(n, fa, inc, fw + inw);
    if (isgn >= 0)
    {
        if (n > 4)
        {
            bitrv2(n, ip + 2, fa);
            cftfsub(n, fa, fw);
            rftfsub(n, fa, inc, fw + inw);
        }
        else if (n == 4)
        {
            cftfsub(n, fa, fw);
        }
        fxr = fa[0] - fa[1];
        fa[0] += fa[1];
        for (j = 2; j < n; j += 2)
        {
            fa[j - 1] = -fa[j] - fa[j + 1];
            fa[j] -= fa[j + 1];
        }
        fa[n - 1] = -fxr;
    }
}

IMEDIA_VOID dfct(IMEDIA_INT32 n, IMEDIA_FLOAT *fa, IMEDIA_FLOAT *ft, IMEDIA_INT32 *ip, IMEDIA_FLOAT *fw)
{
    IMEDIA_VOID makewt(IMEDIA_INT32 inw, IMEDIA_INT32 * ip, IMEDIA_FLOAT * fw);
    IMEDIA_VOID makect(IMEDIA_INT32 inc, IMEDIA_INT32 * ip, IMEDIA_FLOAT * fc);
    IMEDIA_VOID bitrv2(IMEDIA_INT32 n, IMEDIA_INT32 * ip, IMEDIA_FLOAT * fa);
    IMEDIA_VOID cftfsub(IMEDIA_INT32 n, IMEDIA_FLOAT * fa, IMEDIA_FLOAT * fw);
    IMEDIA_VOID rftfsub(IMEDIA_INT32 n, IMEDIA_FLOAT * fa, IMEDIA_INT32 inc, IMEDIA_FLOAT * fc);
    IMEDIA_VOID dctsub(IMEDIA_INT32 n, IMEDIA_FLOAT * fa, IMEDIA_INT32 inc, IMEDIA_FLOAT * fc);
    IMEDIA_INT32 j, ik, il, im, imh, inw, inc;
    IMEDIA_FLOAT fxr, fxi, fyr, fyi;

    inw = ip[0];
    if (n > (inw << 3))
    {
        inw = n >> 3;
        makewt(inw, ip, fw);
    }
    inc = ip[1];
    if (n > (inc << 1))
    {
        inc = n >> 1;
        makect(inc, ip, fw + inw);
    }
    im = n >> 1;
    fyi = fa[im];
    fxi = fa[0] + fa[n];
    fa[0] -= fa[n];
    ft[0] = fxi - fyi;
    ft[im] = fxi + fyi;
    if (n > 2)
    {
        imh = im >> 1;
        for (j = 1; j < imh; j++)
        {
            ik = im - j;
            fxr = fa[j] - fa[n - j];
            fxi = fa[j] + fa[n - j];
            fyr = fa[ik] - fa[n - ik];
            fyi = fa[ik] + fa[n - ik];
            fa[j] = fxr;
            fa[ik] = fyr;
            ft[j] = fxi - fyi;
            ft[ik] = fxi + fyi;
        }
        ft[imh] = fa[imh] + fa[n - imh];
        fa[imh] -= fa[n - imh];
        dctsub(im, fa, inc, fw + inw);
        if (im > 4)
        {
            bitrv2(im, ip + 2, fa);
            cftfsub(im, fa, fw);
            rftfsub(im, fa, inc, fw + inw);
        }
        else if (im == 4)
        {
            cftfsub(im, fa, fw);
        }
        fa[n - 1] = fa[0] - fa[1];
        fa[1] = fa[0] + fa[1];
        for (j = im - 2; j >= 2; j -= 2)
        {
            fa[2 * j + 1] = fa[j] + fa[j + 1];
            fa[2 * j - 1] = fa[j] - fa[j + 1];
        }
        il = 2;
        im = imh;
        while (im >= 2)
        {
            dctsub(im, ft, inc, fw + inw);
            if (im > 4)
            {
                bitrv2(im, ip + 2, ft);
                cftfsub(im, ft, fw);
                rftfsub(im, ft, inc, fw + inw);
            }
            else if (im == 4)
            {
                cftfsub(im, ft, fw);
            }
            fa[n - il] = ft[0] - ft[1];
            fa[il] = ft[0] + ft[1];
            ik = 0;
            for (j = 2; j < im; j += 2)
            {
                ik += il << 2;
                fa[ik - il] = ft[j] - ft[j + 1];
                fa[ik + il] = ft[j] + ft[j + 1];
            }
            il <<= 1;
            imh = im >> 1;
            for (j = 0; j < imh; j++)
            {
                ik = im - j;
                ft[j] = ft[im + ik] - ft[im + j];
                ft[ik] = ft[im + ik] + ft[im + j];
            }
            ft[imh] = ft[im + imh];
            im = imh;
        }
        fa[il] = ft[0];
        fa[n] = ft[2] - ft[1];
        fa[0] = ft[2] + ft[1];
    }
    else
    {
        fa[1] = fa[0];
        fa[2] = ft[0];
        fa[0] = ft[1];
    }
}

IMEDIA_VOID dfst(IMEDIA_INT32 n, IMEDIA_FLOAT *fa, IMEDIA_FLOAT *ft, IMEDIA_INT32 *ip, IMEDIA_FLOAT *fw)
{
    IMEDIA_VOID makewt(IMEDIA_INT32 inw, IMEDIA_INT32 * ip, IMEDIA_FLOAT * fw);
    IMEDIA_VOID makect(IMEDIA_INT32 inc, IMEDIA_INT32 * ip, IMEDIA_FLOAT * fc);
    IMEDIA_VOID bitrv2(IMEDIA_INT32 n, IMEDIA_INT32 * ip, IMEDIA_FLOAT * fa);
    IMEDIA_VOID cftfsub(IMEDIA_INT32 n, IMEDIA_FLOAT * fa, IMEDIA_FLOAT * fw);
    IMEDIA_VOID rftfsub(IMEDIA_INT32 n, IMEDIA_FLOAT * fa, IMEDIA_INT32 inc, IMEDIA_FLOAT * fc);
    IMEDIA_VOID dstsub(IMEDIA_INT32 n, IMEDIA_FLOAT * fa, IMEDIA_INT32 inc, IMEDIA_FLOAT * fc);
    IMEDIA_INT32 j, ik, il, im, imh, inw, inc;
    IMEDIA_FLOAT fxr, fxi, fyr, fyi;

    inw = ip[0];
    if (n > (inw << 3))
    {
        inw = n >> 3;
        makewt(inw, ip, fw);
    }
    inc = ip[1];
    if (n > (inc << 1))
    {
        inc = n >> 1;
        makect(inc, ip, fw + inw);
    }
    if (n > 2)
    {
        im = n >> 1;
        imh = im >> 1;
        for (j = 1; j < imh; j++)
        {
            ik = im - j;
            fxr = fa[j] + fa[n - j];
            fxi = fa[j] - fa[n - j];
            fyr = fa[ik] + fa[n - ik];
            fyi = fa[ik] - fa[n - ik];
            fa[j] = fxr;
            fa[ik] = fyr;
            ft[j] = fxi + fyi;
            ft[ik] = fxi - fyi;
        }
        ft[0] = fa[imh] - fa[n - imh];
        fa[imh] += fa[n - imh];
        fa[0] = fa[im];
        dstsub(im, fa, inc, fw + inw);
        if (im > 4)
        {
            bitrv2(im, ip + 2, fa);
            cftfsub(im, fa, fw);
            rftfsub(im, fa, inc, fw + inw);
        }
        else if (im == 4)
        {
            cftfsub(im, fa, fw);
        }
        fa[n - 1] = fa[1] - fa[0];
        fa[1] = fa[0] + fa[1];
        for (j = im - 2; j >= 2; j -= 2)
        {
            fa[2 * j + 1] = fa[j] - fa[j + 1];
            fa[2 * j - 1] = -fa[j] - fa[j + 1];
        }
        il = 2;
        im = imh;
        while (im >= 2)
        {
            dstsub(im, ft, inc, fw + inw);
            if (im > 4)
            {
                bitrv2(im, ip + 2, ft);
                cftfsub(im, ft, fw);
                rftfsub(im, ft, inc, fw + inw);
            }
            else if (im == 4)
            {
                cftfsub(im, ft, fw);
            }
            fa[n - il] = ft[1] - ft[0];
            fa[il] = ft[0] + ft[1];
            ik = 0;
            for (j = 2; j < im; j += 2)
            {
                ik += il << 2;
                fa[ik - il] = -ft[j] - ft[j + 1];
                fa[ik + il] = ft[j] - ft[j + 1];
            }
            il <<= 1;
            imh = im >> 1;
            for (j = 1; j < imh; j++)
            {
                ik = im - j;
                ft[j] = ft[im + ik] + ft[im + j];
                ft[ik] = ft[im + ik] - ft[im + j];
            }
            ft[0] = ft[im + imh];
            im = imh;
        }
        fa[il] = ft[0];
    }
    fa[0] = 0;
}

/* -------- ��ʼ�� -------- */
IMEDIA_VOID makewt(IMEDIA_INT32 inw, IMEDIA_INT32 *ip, IMEDIA_FLOAT *fw)
{
    IMEDIA_VOID bitrv2(IMEDIA_INT32 n, IMEDIA_INT32 * ip, IMEDIA_FLOAT * fa);
    IMEDIA_INT32 j, inwh;
    IMEDIA_FLOAT fdelta, fx, fy;

    ip[0] = inw;
    ip[1] = 1;
    if (inw > 2)
    {
        inwh = inw >> 1;
        fdelta = (IMEDIA_FLOAT)iMedia_atanf_c(1.0f) / inwh;
        //fdelta = (IMEDIA_FLOAT)atan(1.0f) / inwh;
        fw[0] = 1;
        fw[1] = 0;


        fw[inwh] = (IMEDIA_FLOAT)iMedia_cosf_c(fdelta * inwh);
        //fw[inwh] = (IMEDIA_FLOAT)cos(fdelta * inwh);
        fw[inwh + 1] = fw[inwh];
        if (inwh > 2)
        {
            for (j = 2; j < inwh; j += 2)
            {
                fx = (IMEDIA_FLOAT)iMedia_cosf_c(fdelta * j);
                fy = (IMEDIA_FLOAT)iMedia_sinf_c(fdelta * j);
                //fx = (IMEDIA_FLOAT)cos(fdelta * j);
                //fy = (IMEDIA_FLOAT)sin(fdelta * j);
                fw[j] = fx;
                fw[j + 1] = fy;
                fw[inw - j] = fy;
                fw[inw - j + 1] = fx;
            }
            bitrv2(inw, ip + 2, fw);
        }
    }
}

IMEDIA_VOID makect(IMEDIA_INT32 nc, IMEDIA_INT32 *ip, IMEDIA_FLOAT *fc)
{
    IMEDIA_INT32 j, inch;
    IMEDIA_FLOAT fdelta;

    inch = nc;
    ip[1] = inch;
    if (nc > 1)
    {
        inch = nc >> 1;
        fdelta = (IMEDIA_FLOAT)iMedia_atanf_c(1.0f) / inch;
        fc[0] = (IMEDIA_FLOAT)iMedia_cosf_c(fdelta * inch);
        //fdelta = (IMEDIA_FLOAT)atan(1.0f) / inch;
        //fc[0] = (IMEDIA_FLOAT)cos(fdelta * inch);
        fc[inch] = 0.5f * fc[0];
        for (j = 1; j < inch; j++)
        {

            fc[j] = 0.5f * (IMEDIA_FLOAT)iMedia_cosf_c(fdelta * j);
            fc[nc - j] = 0.5f * (IMEDIA_FLOAT)iMedia_sinf_c(fdelta * j);
            //fc[j] = 0.5f * (IMEDIA_FLOAT)cos(fdelta * j);
            //fc[nc - j] = 0.5f * (IMEDIA_FLOAT)sin(fdelta * j);
        }
    }
}

/* -------- �Ӻ��� -------- */
IMEDIA_VOID bitrv2(IMEDIA_INT32 n, IMEDIA_INT32 *ip, IMEDIA_FLOAT *fa)
{
    IMEDIA_INT32 j, j1, ik, ik1, il, im, im2;
    IMEDIA_FLOAT fxr, fxi, fyr, fyi;

    ip[0] = 0;
    il = n;
    im = 1;
    while ((im << 3) < il)
    {
        il >>= 1;
        for (j = 0; j < im; j++)
        {
            ip[im + j] = ip[j] + il;
        }
        im <<= 1;
    }
    im2 = 2 * im;
    if ((im << 3) == il)
    {
        for (ik = 0; ik < im; ik++)
        {
            for (j = 0; j < ik; j++)
            {
                j1 = 2 * j + ip[ik];
                ik1 = 2 * ik + ip[j];
                fxr = fa[j1];
                fxi = fa[j1 + 1];
                fyr = fa[ik1];
                fyi = fa[ik1 + 1];
                fa[j1] = fyr;
                fa[j1 + 1] = fyi;
                fa[ik1] = fxr;
                fa[ik1 + 1] = fxi;
                j1 += im2;
                ik1 += 2 * im2;
                fxr = fa[j1];
                fxi = fa[j1 + 1];
                fyr = fa[ik1];
                fyi = fa[ik1 + 1];
                fa[j1] = fyr;
                fa[j1 + 1] = fyi;
                fa[ik1] = fxr;
                fa[ik1 + 1] = fxi;
                j1 += im2;
                ik1 -= im2;
                fxr = fa[j1];
                fxi = fa[j1 + 1];
                fyr = fa[ik1];
                fyi = fa[ik1 + 1];
                fa[j1] = fyr;
                fa[j1 + 1] = fyi;
                fa[ik1] = fxr;
                fa[ik1 + 1] = fxi;
                j1 += im2;
                ik1 += 2 * im2;
                fxr = fa[j1];
                fxi = fa[j1 + 1];
                fyr = fa[ik1];
                fyi = fa[ik1 + 1];
                fa[j1] = fyr;
                fa[j1 + 1] = fyi;
                fa[ik1] = fxr;
                fa[ik1 + 1] = fxi;
            }
            j1 = 2 * ik + im2 + ip[ik];
            ik1 = j1 + im2;
            fxr = fa[j1];
            fxi = fa[j1 + 1];
            fyr = fa[ik1];
            fyi = fa[ik1 + 1];
            fa[j1] = fyr;
            fa[j1 + 1] = fyi;
            fa[ik1] = fxr;
            fa[ik1 + 1] = fxi;
        }
    }
    else
    {
        for (ik = 1; ik < im; ik++)
        {
            for (j = 0; j < ik; j++)
            {
                j1 = 2 * j + ip[ik];
                ik1 = 2 * ik + ip[j];
                fxr = fa[j1];
                fxi = fa[j1 + 1];
                fyr = fa[ik1];
                fyi = fa[ik1 + 1];
                fa[j1] = fyr;
                fa[j1 + 1] = fyi;
                fa[ik1] = fxr;
                fa[ik1 + 1] = fxi;
                j1 += im2;
                ik1 += im2;
                fxr = fa[j1];
                fxi = fa[j1 + 1];
                fyr = fa[ik1];
                fyi = fa[ik1 + 1];
                fa[j1] = fyr;
                fa[j1 + 1] = fyi;
                fa[ik1] = fxr;
                fa[ik1 + 1] = fxi;
            }
        }
    }
}

IMEDIA_VOID bitrv2conj(IMEDIA_INT32 n, IMEDIA_INT32 *ip, IMEDIA_FLOAT *fa)
{
    IMEDIA_INT32 j, j1, ik, ik1, il, im, im2;
    IMEDIA_FLOAT fxr, fxi, fyr, fyi;

    ip[0] = 0;
    il = n;
    im = 1;
    while ((im << 3) < il)
    {
        il >>= 1;
        for (j = 0; j < im; j++)
        {
            ip[im + j] = ip[j] + il;
        }
        im <<= 1;
    }
    im2 = 2 * im;
    if ((im << 3) == il)
    {
        for (ik = 0; ik < im; ik++)
        {
            for (j = 0; j < ik; j++)
            {
                j1 = 2 * j + ip[ik];
                ik1 = 2 * ik + ip[j];
                fxr = fa[j1];
                fxi = -fa[j1 + 1];
                fyr = fa[ik1];
                fyi = -fa[ik1 + 1];
                fa[j1] = fyr;
                fa[j1 + 1] = fyi;
                fa[ik1] = fxr;
                fa[ik1 + 1] = fxi;
                j1 += im2;
                ik1 += 2 * im2;
                fxr = fa[j1];
                fxi = -fa[j1 + 1];
                fyr = fa[ik1];
                fyi = -fa[ik1 + 1];
                fa[j1] = fyr;
                fa[j1 + 1] = fyi;
                fa[ik1] = fxr;
                fa[ik1 + 1] = fxi;
                j1 += im2;
                ik1 -= im2;
                fxr = fa[j1];
                fxi = -fa[j1 + 1];
                fyr = fa[ik1];
                fyi = -fa[ik1 + 1];
                fa[j1] = fyr;
                fa[j1 + 1] = fyi;
                fa[ik1] = fxr;
                fa[ik1 + 1] = fxi;
                j1 += im2;
                ik1 += 2 * im2;
                fxr = fa[j1];
                fxi = -fa[j1 + 1];
                fyr = fa[ik1];
                fyi = -fa[ik1 + 1];
                fa[j1] = fyr;
                fa[j1 + 1] = fyi;
                fa[ik1] = fxr;
                fa[ik1 + 1] = fxi;
            }
            ik1 = 2 * ik + ip[ik];
            fa[ik1 + 1] = -fa[ik1 + 1];
            j1 = ik1 + im2;
            ik1 = j1 + im2;
            fxr = fa[j1];
            fxi = -fa[j1 + 1];
            fyr = fa[ik1];
            fyi = -fa[ik1 + 1];
            fa[j1] = fyr;
            fa[j1 + 1] = fyi;
            fa[ik1] = fxr;
            fa[ik1 + 1] = fxi;
            ik1 += im2;
            fa[ik1 + 1] = -fa[ik1 + 1];
        }
    }
    else
    {
        fa[1] = -fa[1];
        fa[im2 + 1] = -fa[im2 + 1];
        for (ik = 1; ik < im; ik++)
        {
            for (j = 0; j < ik; j++)
            {
                j1 = 2 * j + ip[ik];
                ik1 = 2 * ik + ip[j];
                fxr = fa[j1];
                fxi = -fa[j1 + 1];
                fyr = fa[ik1];
                fyi = -fa[ik1 + 1];
                fa[j1] = fyr;
                fa[j1 + 1] = fyi;
                fa[ik1] = fxr;
                fa[ik1 + 1] = fxi;
                j1 += im2;
                ik1 += im2;
                fxr = fa[j1];
                fxi = -fa[j1 + 1];
                fyr = fa[ik1];
                fyi = -fa[ik1 + 1];
                fa[j1] = fyr;
                fa[j1 + 1] = fyi;
                fa[ik1] = fxr;
                fa[ik1 + 1] = fxi;
            }
            ik1 = 2 * ik + ip[ik];
            fa[ik1 + 1] = -fa[ik1 + 1];
            fa[ik1 + im2 + 1] = -fa[ik1 + im2 + 1];
        }
    }
}

IMEDIA_VOID cftfsub(IMEDIA_INT32 n, IMEDIA_FLOAT *fa, IMEDIA_FLOAT *fw)
{
    IMEDIA_VOID cft1st(IMEDIA_INT32 n, IMEDIA_FLOAT * fa, IMEDIA_FLOAT * fw);
    IMEDIA_VOID cftmdl(IMEDIA_INT32 n, IMEDIA_INT32 il, IMEDIA_FLOAT * fa, IMEDIA_FLOAT * fw);
    IMEDIA_INT32 j, j1, j2, j3, il;
    IMEDIA_FLOAT fx0r, fx0i, fx1r, fx1i, fx2r, fx2i, fx3r, fx3i;

    il = 2;
    if (n > 8)
    {
        cft1st(n, fa, fw);
        il = 8;
        while ((il << 2) < n)
        {
            cftmdl(n, il, fa, fw);
            il <<= 2;
        }
    }
    if ((il << 2) == n)
    {
        for (j = 0; j < il; j += 2)
        {
            j1 = j + il;
            j2 = j1 + il;
            j3 = j2 + il;
            fx0r = fa[j] + fa[j1];
            fx0i = fa[j + 1] + fa[j1 + 1];
            fx1r = fa[j] - fa[j1];
            fx1i = fa[j + 1] - fa[j1 + 1];
            fx2r = fa[j2] + fa[j3];
            fx2i = fa[j2 + 1] + fa[j3 + 1];
            fx3r = fa[j2] - fa[j3];
            fx3i = fa[j2 + 1] - fa[j3 + 1];
            fa[j] = fx0r + fx2r;
            fa[j + 1] = fx0i + fx2i;
            fa[j2] = fx0r - fx2r;
            fa[j2 + 1] = fx0i - fx2i;
            fa[j1] = fx1r - fx3i;
            fa[j1 + 1] = fx1i + fx3r;
            fa[j3] = fx1r + fx3i;
            fa[j3 + 1] = fx1i - fx3r;
        }
    }
    else
    {
        for (j = 0; j < il; j += 2)
        {
            j1 = j + il;
            fx0r = fa[j] - fa[j1];
            fx0i = fa[j + 1] - fa[j1 + 1];
            fa[j] += fa[j1];
            fa[j + 1] += fa[j1 + 1];
            fa[j1] = fx0r;
            fa[j1 + 1] = fx0i;
        }
    }
}

IMEDIA_VOID cftbsub(IMEDIA_INT32 n, IMEDIA_FLOAT *fa, IMEDIA_FLOAT *fw)
{
    IMEDIA_VOID cft1st(IMEDIA_INT32 n, IMEDIA_FLOAT * fa, IMEDIA_FLOAT * fw);
    IMEDIA_VOID cftmdl(IMEDIA_INT32 n, IMEDIA_INT32 il, IMEDIA_FLOAT * fa, IMEDIA_FLOAT * fw);
    IMEDIA_INT32 j, j1, j2, j3, il;
    IMEDIA_FLOAT fx0r, fx0i, fx1r, fx1i, fx2r, fx2i, fx3r, fx3i;

    il = 2;
    if (n > 8)
    {
        cft1st(n, fa, fw);
        il = 8;
        while ((il << 2) < n)
        {
            cftmdl(n, il, fa, fw);
            il <<= 2;
        }
    }
    if ((il << 2) == n)
    {
        for (j = 0; j < il; j += 2)
        {
            j1 = j + il;
            j2 = j1 + il;
            j3 = j2 + il;
            fx0r = fa[j] + fa[j1];
            fx0i = -fa[j + 1] - fa[j1 + 1];
            fx1r = fa[j] - fa[j1];
            fx1i = -fa[j + 1] + fa[j1 + 1];
            fx2r = fa[j2] + fa[j3];
            fx2i = fa[j2 + 1] + fa[j3 + 1];
            fx3r = fa[j2] - fa[j3];
            fx3i = fa[j2 + 1] - fa[j3 + 1];
            fa[j] = fx0r + fx2r;
            fa[j + 1] = fx0i - fx2i;
            fa[j2] = fx0r - fx2r;
            fa[j2 + 1] = fx0i + fx2i;
            fa[j1] = fx1r - fx3i;
            fa[j1 + 1] = fx1i - fx3r;
            fa[j3] = fx1r + fx3i;
            fa[j3 + 1] = fx1i + fx3r;
        }
    }
    else
    {
        for (j = 0; j < il; j += 2)
        {
            j1 = j + il;
            fx0r = fa[j] - fa[j1];
            fx0i = -fa[j + 1] + fa[j1 + 1];
            fa[j] += fa[j1];
            fa[j + 1] = -fa[j + 1] - fa[j1 + 1];
            fa[j1] = fx0r;
            fa[j1 + 1] = fx0i;
        }
    }
}

IMEDIA_VOID cft1st(IMEDIA_INT32 n, IMEDIA_FLOAT *fa, IMEDIA_FLOAT *fw)
{
    IMEDIA_INT32 j, ik1, ik2;
    IMEDIA_FLOAT fk1r, fk1i, fk2r, fk2i, fk3r, fk3i;
    IMEDIA_FLOAT fx0r, fx0i, fx1r, fx1i, fx2r, fx2i, fx3r, fx3i;

    fx0r = fa[0] + fa[2];
    fx0i = fa[1] + fa[3];
    fx1r = fa[0] - fa[2];
    fx1i = fa[1] - fa[3];
    fx2r = fa[4] + fa[6];
    fx2i = fa[5] + fa[7];
    fx3r = fa[4] - fa[6];
    fx3i = fa[5] - fa[7];
    fa[0] = fx0r + fx2r;
    fa[1] = fx0i + fx2i;
    fa[4] = fx0r - fx2r;
    fa[5] = fx0i - fx2i;
    fa[2] = fx1r - fx3i;
    fa[3] = fx1i + fx3r;
    fa[6] = fx1r + fx3i;
    fa[7] = fx1i - fx3r;
    fk1r = fw[2];
    fx0r = fa[8] + fa[10];
    fx0i = fa[9] + fa[11];
    fx1r = fa[8] - fa[10];
    fx1i = fa[9] - fa[11];
    fx2r = fa[12] + fa[14];
    fx2i = fa[13] + fa[15];
    fx3r = fa[12] - fa[14];
    fx3i = fa[13] - fa[15];
    fa[8] = fx0r + fx2r;
    fa[9] = fx0i + fx2i;
    fa[12] = fx2i - fx0i;
    fa[13] = fx0r - fx2r;
    fx0r = fx1r - fx3i;
    fx0i = fx1i + fx3r;
    fa[10] = fk1r * (fx0r - fx0i);
    fa[11] = fk1r * (fx0r + fx0i);
    fx0r = fx3i + fx1r;
    fx0i = fx3r - fx1i;
    fa[14] = fk1r * (fx0i - fx0r);
    fa[15] = fk1r * (fx0i + fx0r);
    ik1 = 0;
    for (j = 16; j < n; j += 16)
    {
        ik1 += 2;
        ik2 = 2 * ik1;
        fk2r = fw[ik1];
        fk2i = fw[ik1 + 1];
        fk1r = fw[ik2];
        fk1i = fw[ik2 + 1];
        fk3r = fk1r - 2 * fk2i * fk1i;
        fk3i = 2 * fk2i * fk1r - fk1i;
        fx0r = fa[j] + fa[j + 2];
        fx0i = fa[j + 1] + fa[j + 3];
        fx1r = fa[j] - fa[j + 2];
        fx1i = fa[j + 1] - fa[j + 3];
        fx2r = fa[j + 4] + fa[j + 6];
        fx2i = fa[j + 5] + fa[j + 7];
        fx3r = fa[j + 4] - fa[j + 6];
        fx3i = fa[j + 5] - fa[j + 7];
        fa[j] = fx0r + fx2r;
        fa[j + 1] = fx0i + fx2i;
        fx0r -= fx2r;
        fx0i -= fx2i;
        fa[j + 4] = fk2r * fx0r - fk2i * fx0i;
        fa[j + 5] = fk2r * fx0i + fk2i * fx0r;
        fx0r = fx1r - fx3i;
        fx0i = fx1i + fx3r;
        fa[j + 2] = fk1r * fx0r - fk1i * fx0i;
        fa[j + 3] = fk1r * fx0i + fk1i * fx0r;
        fx0r = fx1r + fx3i;
        fx0i = fx1i - fx3r;
        fa[j + 6] = fk3r * fx0r - fk3i * fx0i;
        fa[j + 7] = fk3r * fx0i + fk3i * fx0r;
        fk1r = fw[ik2 + 2];
        fk1i = fw[ik2 + 3];
        fk3r = fk1r - 2 * fk2r * fk1i;
        fk3i = 2 * fk2r * fk1r - fk1i;
        fx0r = fa[j + 8] + fa[j + 10];
        fx0i = fa[j + 9] + fa[j + 11];
        fx1r = fa[j + 8] - fa[j + 10];
        fx1i = fa[j + 9] - fa[j + 11];
        fx2r = fa[j + 12] + fa[j + 14];
        fx2i = fa[j + 13] + fa[j + 15];
        fx3r = fa[j + 12] - fa[j + 14];
        fx3i = fa[j + 13] - fa[j + 15];
        fa[j + 8] = fx0r + fx2r;
        fa[j + 9] = fx0i + fx2i;
        fx0r -= fx2r;
        fx0i -= fx2i;
        fa[j + 12] = -fk2i * fx0r - fk2r * fx0i;
        fa[j + 13] = -fk2i * fx0i + fk2r * fx0r;
        fx0r = fx1r - fx3i;
        fx0i = fx1i + fx3r;
        fa[j + 10] = fk1r * fx0r - fk1i * fx0i;
        fa[j + 11] = fk1r * fx0i + fk1i * fx0r;
        fx0r = fx1r + fx3i;
        fx0i = fx1i - fx3r;
        fa[j + 14] = fk3r * fx0r - fk3i * fx0i;
        fa[j + 15] = fk3r * fx0i + fk3i * fx0r;
    }
}

IMEDIA_VOID cftmdl(IMEDIA_INT32 n, IMEDIA_INT32 il, IMEDIA_FLOAT *fa, IMEDIA_FLOAT *fw)
{
    IMEDIA_INT32 j, j1, j2, j3, ik, ik1, ik2, im, im2;
    IMEDIA_FLOAT fk1r, fk1i, fk2r, fk2i, fk3r, fk3i;
    IMEDIA_FLOAT fx0r, fx0i, fx1r, fx1i, fx2r, fx2i, fx3r, fx3i;

    im = il << 2;
    for (j = 0; j < il; j += 2)
    {
        j1 = j + il;
        j2 = j1 + il;
        j3 = j2 + il;
        fx0r = fa[j] + fa[j1];
        fx0i = fa[j + 1] + fa[j1 + 1];
        fx1r = fa[j] - fa[j1];
        fx1i = fa[j + 1] - fa[j1 + 1];
        fx2r = fa[j2] + fa[j3];
        fx2i = fa[j2 + 1] + fa[j3 + 1];
        fx3r = fa[j2] - fa[j3];
        fx3i = fa[j2 + 1] - fa[j3 + 1];
        fa[j] = fx0r + fx2r;
        fa[j + 1] = fx0i + fx2i;
        fa[j2] = fx0r - fx2r;
        fa[j2 + 1] = fx0i - fx2i;
        fa[j1] = fx1r - fx3i;
        fa[j1 + 1] = fx1i + fx3r;
        fa[j3] = fx1r + fx3i;
        fa[j3 + 1] = fx1i - fx3r;
    }
    fk1r = fw[2];
    for (j = im; j < il + im; j += 2)
    {
        j1 = j + il;
        j2 = j1 + il;
        j3 = j2 + il;
        fx0r = fa[j] + fa[j1];
        fx0i = fa[j + 1] + fa[j1 + 1];
        fx1r = fa[j] - fa[j1];
        fx1i = fa[j + 1] - fa[j1 + 1];
        fx2r = fa[j2] + fa[j3];
        fx2i = fa[j2 + 1] + fa[j3 + 1];
        fx3r = fa[j2] - fa[j3];
        fx3i = fa[j2 + 1] - fa[j3 + 1];
        fa[j] = fx0r + fx2r;
        fa[j + 1] = fx0i + fx2i;
        fa[j2] = fx2i - fx0i;
        fa[j2 + 1] = fx0r - fx2r;
        fx0r = fx1r - fx3i;
        fx0i = fx1i + fx3r;
        fa[j1] = fk1r * (fx0r - fx0i);
        fa[j1 + 1] = fk1r * (fx0r + fx0i);
        fx0r = fx3i + fx1r;
        fx0i = fx3r - fx1i;
        fa[j3] = fk1r * (fx0i - fx0r);
        fa[j3 + 1] = fk1r * (fx0i + fx0r);
    }
    ik1 = 0;
    im2 = 2 * im;
    for (ik = im2; ik < n; ik += im2)
    {
        ik1 += 2;
        ik2 = 2 * ik1;
        fk2r = fw[ik1];
        fk2i = fw[ik1 + 1];
        fk1r = fw[ik2];
        fk1i = fw[ik2 + 1];
        fk3r = fk1r - 2 * fk2i * fk1i;
        fk3i = 2 * fk2i * fk1r - fk1i;
        for (j = ik; j < il + ik; j += 2)
        {
            j1 = j + il;
            j2 = j1 + il;
            j3 = j2 + il;
            fx0r = fa[j] + fa[j1];
            fx0i = fa[j + 1] + fa[j1 + 1];
            fx1r = fa[j] - fa[j1];
            fx1i = fa[j + 1] - fa[j1 + 1];
            fx2r = fa[j2] + fa[j3];
            fx2i = fa[j2 + 1] + fa[j3 + 1];
            fx3r = fa[j2] - fa[j3];
            fx3i = fa[j2 + 1] - fa[j3 + 1];
            fa[j] = fx0r + fx2r;
            fa[j + 1] = fx0i + fx2i;
            fx0r -= fx2r;
            fx0i -= fx2i;
            fa[j2] = fk2r * fx0r - fk2i * fx0i;
            fa[j2 + 1] = fk2r * fx0i + fk2i * fx0r;
            fx0r = fx1r - fx3i;
            fx0i = fx1i + fx3r;
            fa[j1] = fk1r * fx0r - fk1i * fx0i;
            fa[j1 + 1] = fk1r * fx0i + fk1i * fx0r;
            fx0r = fx1r + fx3i;
            fx0i = fx1i - fx3r;
            fa[j3] = fk3r * fx0r - fk3i * fx0i;
            fa[j3 + 1] = fk3r * fx0i + fk3i * fx0r;
        }
        fk1r = fw[ik2 + 2];
        fk1i = fw[ik2 + 3];
        fk3r = fk1r - 2 * fk2r * fk1i;
        fk3i = 2 * fk2r * fk1r - fk1i;
        for (j = ik + im; j < il + (ik + im); j += 2)
        {
            j1 = j + il;
            j2 = j1 + il;
            j3 = j2 + il;
            fx0r = fa[j] + fa[j1];
            fx0i = fa[j + 1] + fa[j1 + 1];
            fx1r = fa[j] - fa[j1];
            fx1i = fa[j + 1] - fa[j1 + 1];
            fx2r = fa[j2] + fa[j3];
            fx2i = fa[j2 + 1] + fa[j3 + 1];
            fx3r = fa[j2] - fa[j3];
            fx3i = fa[j2 + 1] - fa[j3 + 1];
            fa[j] = fx0r + fx2r;
            fa[j + 1] = fx0i + fx2i;
            fx0r -= fx2r;
            fx0i -= fx2i;
            fa[j2] = -fk2i * fx0r - fk2r * fx0i;
            fa[j2 + 1] = -fk2i * fx0i + fk2r * fx0r;
            fx0r = fx1r - fx3i;
            fx0i = fx1i + fx3r;
            fa[j1] = fk1r * fx0r - fk1i * fx0i;
            fa[j1 + 1] = fk1r * fx0i + fk1i * fx0r;
            fx0r = fx1r + fx3i;
            fx0i = fx1i - fx3r;
            fa[j3] = fk3r * fx0r - fk3i * fx0i;
            fa[j3 + 1] = fk3r * fx0i + fk3i * fx0r;
        }
    }
}

IMEDIA_VOID rftfsub(IMEDIA_INT32 n, IMEDIA_FLOAT *fa, IMEDIA_INT32 nc, IMEDIA_FLOAT *fc)
{
    IMEDIA_INT32 j, ik, ikk, iks, im;
    IMEDIA_FLOAT fkr, fki, fxr, fxi, fyr, fyi;

    im = n >> 1;
    iks = 2 * nc / im;
    ikk = 0;
    for (j = 2; j < im; j += 2)
    {
        ik = n - j;
        ikk += iks;
        fkr = 0.5f - fc[nc - ikk];
        fki = fc[ikk];
        fxr = fa[j] - fa[ik];
        fxi = fa[j + 1] + fa[ik + 1];
        fyr = fkr * fxr - fki * fxi;
        fyi = fkr * fxi + fki * fxr;
        fa[j] -= fyr;
        fa[j + 1] -= fyi;
        fa[ik] += fyr;
        fa[ik + 1] -= fyi;
    }
}

IMEDIA_VOID rftbsub(IMEDIA_INT32 n, IMEDIA_FLOAT *fa, IMEDIA_INT32 nc, IMEDIA_FLOAT *fc)
{
    IMEDIA_INT32 j, ik, ikk, iks, im;
    IMEDIA_FLOAT fkr, fki, fxr, fxi, fyr, fyi;

    fa[1] = -fa[1];
    im = n >> 1;
    iks = 2 * nc / im;
    ikk = 0;
    for (j = 2; j < im; j += 2)
    {
        ik = n - j;
        ikk += iks;
        fkr = 0.5f - fc[nc - ikk];
        fki = fc[ikk];
        fxr = fa[j] - fa[ik];
        fxi = fa[j + 1] + fa[ik + 1];
        fyr = fkr * fxr + fki * fxi;
        fyi = fkr * fxi - fki * fxr;
        fa[j] -= fyr;
        fa[j + 1] = fyi - fa[j + 1];
        fa[ik] += fyr;
        fa[ik + 1] = fyi - fa[ik + 1];
    }
    fa[im + 1] = -fa[im + 1];
}

IMEDIA_VOID dctsub(IMEDIA_INT32 n, IMEDIA_FLOAT *fa, IMEDIA_INT32 nc, IMEDIA_FLOAT *fc)
{
    IMEDIA_INT32 j, ik, ikk, iks, im;
    IMEDIA_FLOAT fkr, fki, fxr;

    im = n >> 1;
    if(n != 0) {
        iks = nc / n;
    } else {
        ALG_LOGE("n == 0");
        iks = nc;
    }
    ikk = 0;
    for (j = 1; j < im; j++)
    {
        ik = n - j;
        ikk += iks;
        fkr = fc[ikk] - fc[nc - ikk];
        fki = fc[ikk] + fc[nc - ikk];
        fxr = fki * fa[j] - fkr * fa[ik];
        fa[j] = fkr * fa[j] + fki * fa[ik];
        fa[ik] = fxr;
    }
    fa[im] *= fc[0];
}

IMEDIA_VOID dstsub(IMEDIA_INT32 n, IMEDIA_FLOAT *fa, IMEDIA_INT32 nc, IMEDIA_FLOAT *fc)
{
    IMEDIA_INT32 j, ik, ikk, iks, im;
    IMEDIA_FLOAT fkr, fki, fxr;

    im = n >> 1;
    if(n != 0) {
        iks = nc / n;
    } else {
        ALG_LOGE("n == 0");
        iks = nc;
    }
    ikk = 0;
    for (j = 1; j < im; j++)
    {
        ik = n - j;
        ikk += iks;
        fkr = fc[ikk] - fc[nc - ikk];
        fki = fc[ikk] + fc[nc - ikk];
        fxr = fki * fa[ik] - fkr * fa[j];
        fa[ik] = fkr * fa[ik] + fki * fa[j];
        fa[j] = fxr;
    }
    fa[im] *= fc[0];
}

/*****************************************************************************
 ��������  : iMedia_lma_sre_common_FFT
 ��������  : FFT��������
 �������  : IMEDIA_INT16 sFftOrder
             IMEDIA_FLOAT *fftBuf
 �������  : IMEDIA_FLOAT *fftBuf
             ��512��FFT����������matlab��Ӧ��ϵ���£�
             �����2n���Ӧmatlab��n���ʵ����������ͬ
             ���2n+1�������Ӧmatlab��n����鲿�������෴
             ��0��͵�1����⣬��0����matlab��0��ʵ����Ӧ����1����matlab��257��ʵ����Ӧ
 �� �� ֵ  : ��
*****************************************************************************/
IMEDIA_VOID iMedia_K2NS_common_FFT(IMEDIA_INT16 sFftOrder, IMEDIA_FLOAT *fftBuf)
{
    IMEDIA_INT32 i;
    IMEDIA_INT32 ip[IMEDIA_FFT_LEN_32K];
    IMEDIA_FLOAT wfft[IMEDIA_FFT_LEN_32K];
    for (i = 0; i < sFftOrder; i++) {
        ip[i] = 0;
        wfft[i] = 0.0f;
    }
    rdft(sFftOrder, (IMEDIA_INT32)1, fftBuf, ip, wfft);
}

/*****************************************************************************
 ��������  : iMedia_lma_sre_common_FFT
 ��������  : IFFT��������
 �������  : IMEDIA_INT16 sFftOrder
             IMEDIA_FLOAT *fftBuf��Ƶ��˳���matlab��Ӧ��ϵ�ο�FFT
 �������  : IMEDIA_FLOAT *fftBuf
 �� �� ֵ  : ��
*****************************************************************************/
IMEDIA_VOID iMedia_K2NS_common_IFFT(IMEDIA_INT16 sFftOrder, IMEDIA_FLOAT *fftBuf)
{
    IMEDIA_INT32 i;
    IMEDIA_INT32 ip[IMEDIA_FFT_LEN_32K];
    IMEDIA_FLOAT wfft[IMEDIA_FFT_LEN_32K];
    for (i = 0; i < sFftOrder; i++) {
        ip[i] = 0;
        wfft[i] = 0.0f;
    }
    rdft(sFftOrder, (IMEDIA_INT32) - 1, fftBuf, ip, wfft);
}

}  // namespace kws2k2_faith
