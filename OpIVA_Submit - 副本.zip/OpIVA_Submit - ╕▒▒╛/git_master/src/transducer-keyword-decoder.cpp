#include <algorithm>
#include <cmath>
#include <utility>
#include <vector>
#include "transducer-keyword-decoder.h"
#include "faith_api.h"
#include "alg_log.h"

#define LOG_TAG "kws2k2:trans-keyword-decoder"

namespace kws2k2_faith {

const short DOWNSAMPLING_RATE = 4;
const short ENCODER_PAD = 7;
const float YS_SOCRE_THREAD = 0.01;
const short VOCAB_SIZE = 197;
const short DECODER_INPUTSIZE = 2;
const short DECODER_OUTPUTSIZE = 320;
const short JOINER_INPUTSIZE = 2 * 320;

int32_t TransducerKeywordDecoder::Decode(float *encoder_out, const uint32_t outputSize, ContextGraphPtr contextGraphPrt,
                                         std::vector<TransducerKeywordResult> *result, std::shared_ptr<FaithInference> k2Decoder,
                                         std::shared_ptr<FaithInference> k2Joiner,
                                         int isEchoScene)
{
    ALG_LOGI("Decode start.\n");
    int32_t num_frames = 56;
    int32_t context_size = 2;
    int32_t blank_id = 0;
    std::vector<int32_t> blanks(context_size, -1);
    blanks.back() = 0;  // blank_id is hardcoded to 0

    std::vector<float> decoder_inputData(DECODER_INPUTSIZE, 0);
    float decoder_outputData[DECODER_OUTPUTSIZE] = {1.0};
    std::vector<float> joiner_inputData(JOINER_INPUTSIZE, 0);
    float joiner_outputData[VOCAB_SIZE] = {1.0};
    float p_logit[VOCAB_SIZE * 10] = {0};
    int32_t ret = 0;
    int32_t num_hyps;
    float ys_score = 0;
    float ys_score_thread = 0;
    Hypotheses cur;
    std::vector<Hypothesis> prev;
    const ContextState *context_state;
    context_state = contextGraphPrt->Root();
    Hypothesis hyps = Hypothesis(blanks, 0, contextGraphPrt->Root());  // B = HypothesisList()
    cur.Add(hyps);
    ys_score_thread = YS_SOCRE_THREAD;
    for (int32_t t = 0; t != num_frames; ++t) {
        num_hyps = cur.Size();  // Hypothesis个数
        prev.clear();
        for (auto &h : cur) {
            prev.push_back(std::move(h.second));
        }
        cur.Clear();
        for (int32_t hpy_idx = 0; hpy_idx < num_hyps; hpy_idx++) {
            decoder_inputData[0] = prev[hpy_idx].ys[prev[hpy_idx].ys.size() - 2];
            decoder_inputData[1] = prev[hpy_idx].ys[prev[hpy_idx].ys.size() - 1];
            ret = k2Decoder->Compute(decoder_inputData, DECODER_INPUTSIZE, decoder_outputData,
                                                  DECODER_OUTPUTSIZE);
            if (ret != 0) {
                ALG_LOGE("decoder Compute failed. \n");
                return -1;
            }
            for (int jj = 0; jj < 320; jj++) {
                joiner_inputData[jj] = encoder_out[t * 320 + jj];
                joiner_inputData[320 + jj] = decoder_outputData[jj];
            }
            ret = k2Joiner->Compute(joiner_inputData, JOINER_INPUTSIZE, joiner_outputData,
                                                 VOCAB_SIZE);
            if (ret != 0) {
                ALG_LOGE("joiner Compute failed.\n");
                return -1;
            }
            for (int idx = 0; idx < VOCAB_SIZE; idx++) {
                p_logit[hpy_idx * VOCAB_SIZE + idx] = joiner_outputData[idx];
            }
        }

        LogSoftmax(p_logit, VOCAB_SIZE, num_hyps);  // softmax
        std::vector<float> logprobs(VOCAB_SIZE * num_hyps);
        for (int idx = 0; idx < VOCAB_SIZE * num_hyps; idx++) {
            logprobs[idx] = p_logit[idx];
        }

        float *p_logprob = p_logit;

        for (int32_t i = 0; i != num_hyps; ++i) {  // ys_log_probs
            float log_prob = prev[i].log_prob;
            for (int32_t k = 0; k != VOCAB_SIZE; ++k, ++p_logprob) {     // all vocab, VOCAB_SIZE is the nums of phoneme/subword/word
                *p_logprob += log_prob;  // add log_prob to current log_prob
            }
        }
        p_logprob = p_logit;  // we changed p_logprob in the above for loop, return to begin

        auto topk = TopkIndex(p_logprob, VOCAB_SIZE * num_hyps, max_active_paths_);

        for (auto k : topk) {
            int32_t hyp_index = k / VOCAB_SIZE;
            int32_t new_token = k % VOCAB_SIZE;

            Hypothesis new_hyp = prev[hyp_index];
            float context_score = 0;
            auto context_state = new_hyp.context_state;
            // it treats unk as blank
            ys_score = exp(logprobs[hyp_index * VOCAB_SIZE + new_token]);
            if (new_token != 0 && new_token != unk_id_ && ys_score > ys_score_thread) {
                new_hyp.ys.push_back(new_token);
                new_hyp.timestamps.push_back(t * DOWNSAMPLING_RATE + ENCODER_PAD);
                new_hyp.ys_probs.push_back(ys_score);
                new_hyp.num_tailing_blanks = 0;
                auto context_res = contextGraphPrt->ForwardOneStep(context_state, new_token);
                context_score = std::get<0>(context_res);
                new_hyp.context_state = std::get<1>(context_res);
                // Start matching from the start state, forget the decoder history.
                if (new_hyp.context_state->token == -1) {
                    new_hyp.ys[new_hyp.ys.size() - 2] = -1;
                    new_hyp.ys[new_hyp.ys.size() - 1] = 0;
                    new_hyp.timestamps.clear();
                    new_hyp.ys_probs.clear();
                }
            } else {
                new_hyp.num_tailing_blanks++;
            }
            new_hyp.log_prob = p_logprob[k] + context_score;
            cur.Add(new_hyp);
        }
        auto best_hyp = cur.GetMostProbable(true);
        auto status = contextGraphPrt->IsMatched(best_hyp.context_state);
        bool matched = std::get<0>(status);
        const ContextState *matched_state = std::get<1>(status);
        if (matched) {
            float ys_prob = 0.0;
            for (int32_t i = (best_hyp.ys_probs.size() - matched_state->level); i < best_hyp.ys_probs.size(); i++) {
                ys_prob += best_hyp.ys_probs[i];
            }
            ys_prob /= matched_state->level;  // ac_prob
            if (ys_prob >= matched_state->ac_threshold) {
                ALG_LOGI("matched: phrase: %s ac_threshold:%f best_hyp:%s\n", matched_state->phrase.c_str(), matched_state->ac_threshold, best_hyp.ToString().c_str());
                if (matched_state->pinyin != "") {
                    (*result)[0].tokens = {best_hyp.ys.end() - matched_state->level, best_hyp.ys.end()};
                    (*result)[0].timestamps = {best_hyp.timestamps.end() - matched_state->level, best_hyp.timestamps.end()};
                    (*result)[0].ys_probs = {best_hyp.ys_probs.end() - matched_state->level, best_hyp.ys_probs.end()};
                    (*result)[0].ys_prob = ys_prob;
                    (*result)[0].keyword = matched_state->phrase;
                    (*result)[0].pinyin = matched_state->pinyin;
                    cur.Clear();
                    hyps = Hypothesis(blanks, 0, contextGraphPrt->Root());
                    cur.Add(hyps);
                }
                break;
            }
        }
    }
    
    ALG_LOGI("Decode end.\n");
    return 0;
}
}  // namespace kws2k2_faith
