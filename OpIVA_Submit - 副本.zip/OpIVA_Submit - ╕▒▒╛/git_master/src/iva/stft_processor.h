/**
 * @file stft_processor.h
 * @brief IVA算法的STFT处理器
 */

#ifndef STFT_PROCESSOR_H
#define STFT_PROCESSOR_H

#include <complex>
#include <vector>
#include <memory>
#include <cstdlib>
#include <cstddef>

// 定点量化支持
#if defined(IVA_OPT_C6_STFT_Q15) && IVA_OPT_C6_STFT_Q15
#include "fixedpoint.h"
#endif

namespace kws2k2_faith {

using Complex = std::complex<float>;
using ComplexMatrix = std::vector<std::vector<Complex>>;
using ComplexTensor = std::vector<ComplexMatrix>;

// Aligned allocator for SIMD-friendly buffers 
template<class T, std::size_t Align>
struct AlignedAllocator {
    using value_type = T;
    using pointer = T*;
    using const_pointer = const T*;
    using size_type = std::size_t;
    using difference_type = std::ptrdiff_t;

    template<class U> struct rebind { using other = AlignedAllocator<U, Align>; };

    AlignedAllocator() noexcept {}
    template<class U>
    AlignedAllocator(const AlignedAllocator<U, Align>&) noexcept {}

    pointer allocate(size_type n) {
        if (n == 0) return nullptr;
        void* p = nullptr;
        if (posix_memalign(&p, Align, n * sizeof(T)) != 0) throw std::bad_alloc();
        return static_cast<pointer>(p);
    }
    void deallocate(pointer p, size_type) noexcept { free(p); }

    bool operator==(const AlignedAllocator&) const noexcept { return true; }
    bool operator!=(const AlignedAllocator&) const noexcept { return false; }
};

/**
 * @brief STFT配置参数
 */
struct STFTConfig {
    int fft_size = 1024;        ///< FFT大小
    int hop_size = 256;         ///< 跳跃大小
    int window_size = 1024;     ///< 窗口大小
    enum WindowType {
        HANN,                   ///< 汉宁窗
        HAMMING,                ///< 汉明窗
        BLACKMAN                ///< 布莱克曼窗
    } window_type = HANN;
};

/**
 * @brief 多通道音频的STFT处理器
 */
class STFTProcessor {
public:
    /**
     * @brief 初始化STFT处理器
     * @param config STFT配置参数
     * @return 成功返回0，失败返回负值
     */
    int Initialize(const STFTConfig& config);

    /**
     * @brief 对多通道音频执行正向STFT
     * @param input 时域输入 [通道][采样点]
     * @param output 频域输出 [频率][时间][通道]
     * @return 成功返回0，失败返回负值
     */
    int Forward(const std::vector<std::vector<float>>& input, ComplexTensor& output);

    /**
     * @brief 对多通道音频执行逆向STFT
     * @param input 频域输入 [频率][时间][通道]
     * @param output 时域输出 [通道][采样点]
     * @return 成功返回0，失败返回负值
     */
    int Inverse(const ComplexTensor& input, std::vector<std::vector<float>>& output);

    /**
     * @brief 获取频率箱数量
     */
    int GetFreqBins() const { return freq_bins_; }

    /**
     * @brief 获取给定输入长度的时间帧数
     */
    int GetTimeFrames(int input_length) const;

    /**
     * @brief 清理资源
     */
    void Cleanup();

private:
    STFTConfig config_;                                 ///< STFT配置参数
    bool initialized_ = false;                          ///< 初始化状态标志

    int freq_bins_;                                     ///< 频率箱数量
    std::vector<float> window_;                         ///< 分析窗函数
    std::vector<float> synthesis_window_;               ///< 合成窗函数

#if defined(IVA_OPT_C6_STFT_Q15) && IVA_OPT_C6_STFT_Q15
    std::vector<Q15> window_q15_;                       ///< Q15分析窗函数
    std::vector<Q15> synthesis_window_q15_;             ///< Q15合成窗函数
#endif

    // 工作缓冲区
    std::vector<Complex, AlignedAllocator<Complex, 64>> fft_buffer_;                   ///< FFT缓冲区 (A5 对齐)
    std::vector<float> temp_frame_;                                                    ///< 临时帧缓冲区 (A4 复用)
    std::vector<std::vector<float>> overlap_buffer_;                                   ///< 重叠相加缓冲区

    // 复用的帧级缓冲，去除 per-frame 分配 (A4)
    std::vector<Complex> freq_frame_buffer_;                                           ///< 频域单帧缓冲
    std::vector<Complex, AlignedAllocator<Complex, 64>> fft_output_buffer_;            ///< FFT输出临时缓冲
    std::vector<Complex, AlignedAllocator<Complex, 64>> full_spectrum_buffer_;         ///< IFFT构造的全谱
    std::vector<Complex, AlignedAllocator<Complex, 64>> ifft_output_buffer_;           ///< IFFT输出复数缓冲
    std::vector<float> time_frame_buffer_;                                             ///< IFFT后的时域单帧缓冲

    /**
     * @brief 生成窗函数
     */
    void GenerateWindow();

    /**
     * @brief 使用iMedia FFT执行FFT
     * @param input 时域输入
     * @param output 频域输出
     */
    void PerformFFT(const std::vector<float>& input, std::vector<Complex>& output);

    /**
     * @brief 使用iMedia FFT执行IFFT 
     * @param input 频域输入
     * @param output 时域输出
     */
    void PerformIFFT(const std::vector<Complex>& input, std::vector<float>& output);

    /**
     * @brief 对帧应用窗函数
     */
    void ApplyWindow(std::vector<float>& frame);

    /**
     * @brief 重叠相加合成
     */
    void OverlapAdd(const std::vector<float>& frame, std::vector<float>& output, int frame_start);
};

} // namespace kws2k2_faith

#endif // STFT_PROCESSOR_H
