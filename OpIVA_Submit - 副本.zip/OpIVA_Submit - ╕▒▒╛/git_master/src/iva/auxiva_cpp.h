/**
 * @file auxiva_cpp.h
 * @brief 基于辅助函数的独立向量分析(AuxIVA)的纯C++实现
 *
 * 本文件包含了用于频域盲源分离的完整AuxIVA算法实现。AuxIVA通过利用
 * 源信号在频率箱间的统计独立性，特别适用于分离音频源的卷积混合。
 */

#ifndef AUXIVA_CPP_H
#define AUXIVA_CPP_H

#include <complex>
#include <vector>
#include <memory>

// C6: 定点量化支持
#if defined(IVA_OPT_C6_FIXEDPOINT) && IVA_OPT_C6_FIXEDPOINT
#include "fixedpoint.h"
#endif

namespace kws2k2_faith {

/// @brief AuxIVA实现中使用的复数类型
using Complex = std::complex<float>;

/// @brief 复数的二维矩阵 [行][列]
using ComplexMatrix = std::vector<std::vector<Complex>>;

/// @brief 复数的三维张量 [深度][行][列]
using ComplexTensor = std::vector<ComplexMatrix>;

/**
 * @brief AuxIVA算法的配置参数
 *
 * 该结构包含控制AuxIVA盲源分离算法行为的所有可调参数。
 * 这些参数影响收敛速度、数值稳定性和分离质量。
 */
struct AuxIVAConfig {
    /// @brief AuxIVA算法的最大迭代次数
    /// @details 控制计算预算。更多迭代通常带来更好的分离效果但增加处理时间。典型范围：50-200
    int max_iterations = 100;

    /// @brief 早停的收敛阈值
    /// @details 当解混矩阵的相对变化低于此值时算法停止。更小的值带来更精确的收敛但更长的处理时间
    double convergence_threshold = 1e-6;

    /// @brief 反投影的参考麦克风索引
    /// @details 指定用作幅度参考的麦克风通道。必须在[0, num_channels-1]范围内，通常设为0
    int ref_mic = 0;

    /// @brief 数值稳定性的机器精度
    /// @details 添加的小值以防止除零和数值不稳定。应接近浮点精度极限
    double eps = 2.220446049250313e-16;

    /// @brief 启用解混矩阵归一化
    /// @details 为真时，应用功率归一化以防止尺度模糊。建议在大多数应用中保持为真
    bool normalize_demixing = true;

    /// @brief 启用迭代过程中的收敛检查
    /// @details 为真时，监控收敛并在达到阈值时提前停止。节省计算但增加收敛计算开销
    bool use_convergence_check = false;

    /// @brief 相对对角加载因子
    /// @details 添加到对角线的矩阵迹的分数，用于数值稳定性。有助于病态矩阵。典型范围：1e-4到1e-2
    double diag_load_rel = 1e-3;

    /// @brief 绝对对角加载值
    /// @details 无论迹如何都添加到矩阵对角线的最小值。提供基线数值稳定性。典型范围：1e-10到1e-6
    double diag_load_abs = 1e-8;

    /// @brief 要分离的源信号数量
    /// @details 由于BSS的基本限制，必须≤num_channels。大多数音频应用的典型值：2-8
    int num_sources;

    /// @brief 输入的麦克风通道数
    /// @details 决定可用于分离的空间多样性。更多通道通常能实现更好的分离质量
    int num_channels;

    /// @brief STFT中的频率箱数量
    /// @details 分析的频率分辨率。更高的值提供更好的频率分辨率但增加计算复杂度
    int freq_bins;

    /// @brief 分析窗口中的时间帧数
    /// @details 处理窗口的时间范围。影响内存使用和算法的平稳性假设
    int time_frames;
};

/**
 * @brief 基于辅助函数的独立向量分析主处理器类
 *
 * 该类实现了用于频域盲源分离的完整AuxIVA算法。它维护内部状态包括解混矩阵、
 * 源模型和工作缓冲区，以高效分离混合音频源。
 *
 * 算法工作原理：
 * 1. 使用向量独立性对频率箱间的源依赖性建模
 * 2. 使用辅助函数优化迭代更新解混矩阵
 * 3. 应用反投影以保持相对于参考麦克风的幅度缩放
 */
class AuxIVAProcessor {
public:
    /**
     * @brief 使用给定配置初始化AuxIVA处理器
     *
     * 分配内部缓冲区，验证参数，并将解混矩阵初始化为单位矩阵。
     * 必须在任何处理操作之前调用。
     *
     * @param config 算法配置参数
     * @return 成功初始化返回0，失败返回负值
     */
    int Initialize(const AuxIVAConfig& config);

    /**
     * @brief 处理多通道频域数据以分离源信号
     *
     * 执行完整的AuxIVA算法，包括：
     * - 基于当前分离的源模型估计
     * - 使用辅助函数优化的迭代解混矩阵更新
     * - 用于幅度保持的反投影
     *
     * @param input 输入频域数据 [频率箱][时间帧][通道数]
     * @param output 输出分离的源信号 [频率箱][时间帧][源数量]
     * @return 成功处理返回0，失败返回负值
     */
    int Process(const ComplexTensor& input, ComplexTensor& output);

    /**
     * @brief 获取当前解混矩阵用于分析或外部使用
     *
     * 返回学习到的解混矩阵的只读访问。这些矩阵表示分离混合信号的线性变换。
     *
     * @return 解混矩阵的常量引用 [频率箱][源数量][通道数]
     */
    const ComplexTensor& GetDemixingMatrices() const { return demixing_matrices_; }

    /**
     * @brief 重置算法状态到初始条件
     *
     * 将解混矩阵重新初始化为单位矩阵，同时保留配置和已分配的缓冲区。
     * 适用于处理新的、不相关的音频段。
     */
    void Reset();

    /**
     * @brief 释放所有已分配的资源并重置为未初始化状态
     *
     * 释放所有内部缓冲区并将处理器重置为未初始化状态。
     * 必须再次调用Initialize()才能进一步使用。
     */
    void Cleanup();

private:
    /// @brief 当前算法配置参数
    AuxIVAConfig config_;

    /// @brief 初始化状态标志
    bool initialized_ = false;

    /// @brief 解混矩阵 W[频率箱][源索引][通道索引]
    /// @details AuxIVA算法的核心。这些复值矩阵定义了将混合信号分离为源信号的线性变换
    ComplexTensor demixing_matrices_;

    /// @brief 中间计算的临时矩阵
    /// @details 用于协方差矩阵计算和矩阵操作的可重用缓冲区
    ComplexMatrix temp_matrix_;

    /// @brief 当前帧的源功率估计
    /// @details 模型更新期间每个源功率计算的临时存储
    std::vector<double> source_powers_;

#if defined(IVA_OPT_C6_FIXEDPOINT) && IVA_OPT_C6_FIXEDPOINT
    /// @brief 定点量化相关成员
    BFPManager bfp_manager_;                                      ///< 块浮点指数管理器
    std::vector<std::vector<std::vector<ComplexQ31>>> demixing_matrices_q31_;  ///< Q31解混矩阵 [freq][source][channel]
    std::vector<std::vector<ComplexQ31>> temp_matrix_q31_;        ///< Q31临时矩阵 [channel][channel]
    std::vector<std::vector<ComplexQ31>> input_freq_q31_;         ///< Q31输入频域数据缓存 [time][channel]
    std::vector<std::vector<ComplexQ31>> output_freq_q31_;        ///< Q31输出频域数据缓存 [time][source]
#endif

    /// @brief 源模型(功率谱密度) R[源索引][时间帧]
    /// @details 源活动随时间的统计模型。用作辅助函数优化中的权重
    std::vector<std::vector<double>> source_models_;


#ifdef IVA_OPT_B4
    // Gram 矩阵缓存：[freq][time] -> [ch][ch]
    std::vector<std::vector<ComplexMatrix>> gram_cache_;
    bool gram_cache_valid_ = false;
    int gram_cache_time_frames_ = 0;
    int gram_cache_channels_ = 0;
    void BuildGramCache(const ComplexTensor& input);
#endif

    /**
     * @brief 将解混矩阵初始化为单位变换
     *
     * 通过将所有解混矩阵初始化为单位矩阵来设置迭代优化的初始状态。
     * 这提供了保持原始混合信号的中性起点。
     */
    void InitializeDemixingMatrices();

    /**
     * @brief 基于当前源分离估计更新源模型
     *
     * 通过聚合每个时间帧所有频率箱的功率来计算每个源的功率谱密度模型。
     * 这些模型捕获每个源的时间活动模式，用作辅助函数优化中的权重。
     *
     * @param separated_sources 当前源分离估计 [频率][时间][源]
     */
    void UpdateSourceModels(const ComplexTensor& separated_sources);

    /**
     * @brief 更新单个频率箱的解混矩阵
     * @param freq_bin 频率箱索引
     * @param input_freq 该频率的输入数据 [时间][通道]
     * @param source_models 该频率的源模型 [源][时间]
     */
    void UpdateDemixingMatrix(int freq_bin,
                             const ComplexMatrix& input_freq,
                             const std::vector<std::vector<double>>& source_models);

    /**
     * @brief 将解混矩阵应用于输入
     * @param input 输入数据 [频率][时间][通道]
     * @param output 输出数据 [频率][时间][源]
     */
    void ApplyDemixing(const ComplexTensor& input, ComplexTensor& output);

    /**
     * @brief 应用反投影进行幅度校正
     * @param separated_sources 解混后的分离源
     * @param original_input 原始混合输入
     * @param ref_mic_index 参考麦克风索引(通常为0)
     * @param corrected_output 校正幅度后的输出
     */
    void ApplyBackProjection(const ComplexTensor& separated_sources,
                           const ComplexTensor& original_input,
                           int ref_mic_index,
                           ComplexTensor& corrected_output);

    /**
     * @brief 使用高斯-约旦消元法计算矩阵逆
     * @param matrix 输入/输出矩阵
     * @return 成功返回true，失败返回false
     */
    bool InvertMatrix(ComplexMatrix& matrix);



    /**
     * @brief 计算AuxIVA的协方差矩阵
     * @param freq_bin 频率箱索引
     * @param source_idx 源索引
     * @param input_freq 输入频率数据 [时间][通道]
     * @param source_model 该源的源模型 [时间]
     */
    void ComputeCovarianceMatrix(int freq_bin, int source_idx,
                               const ComplexMatrix& input_freq,
                               const std::vector<double>& source_model);

    /**
     * @brief 使用线性系统求解解混向量
     * @param source_idx 源索引
     * @param demixing_vector 输出解混向量 [通道]
     * @return 成功返回true，失败返回false
     */
    bool SolveDemixingVector(int source_idx, const ComplexMatrix& W_freq, std::vector<Complex>& demixing_vector);

    /**
     * @brief 更新单个频率箱和单个源的解混矩阵
     * @param freq_bin 频率箱索引
     * @param source_idx 源索引
     * @param input_freq 输入频率数据 [时间][通道]
     */
    void UpdateDemixingMatrixFreqSource(int freq_bin, int source_idx, const ComplexMatrix& input_freq);

    /**
     * @brief 归一化解混矩阵
     */
    void NormalizeDemixingMatrices();

    /**
     * @brief 检查算法收敛性
     * @param prev_demixing 前一次迭代的解混矩阵
     * @param threshold 收敛阈值
     * @return 收敛返回true，否则返回false
     */
    bool CheckConvergence(const ComplexTensor& prev_demixing, double threshold);

#if defined(IVA_OPT_C6_FIXEDPOINT) && IVA_OPT_C6_FIXEDPOINT
    /**
     * @brief 定点版本的Process函数
     * @param input 输入频域数据
     * @param output 输出分离源
     * @return 成功返回0，失败返回负值
     */
    int ProcessFixedPoint(const ComplexTensor& input, ComplexTensor& output);

    /**
     * @brief 浮点版本的Process函数（原始实现）
     * @param input 输入频域数据
     * @param output 输出分离源
     * @return 成功返回0，失败返回负值
     */
    int ProcessFloatingPoint(const ComplexTensor& input, ComplexTensor& output);

    /**
     * @brief Q31定点版本的解混应用
     */
    void ApplyDemixingQ31(int freq_bin);

    /**
     * @brief Q31定点版本的协方差矩阵计算
     */
    void ComputeCovarianceMatrixQ31(int freq_bin, int source_idx);
#else
    /**
     * @brief 浮点版本的Process函数（当定点关闭时的默认实现）
     */
    int ProcessFloatingPoint(const ComplexTensor& input, ComplexTensor& output);
#endif
};




} // namespace kws2k2_faith

#endif // AUXIVA_CPP_H
