#ifndef IVA_FFT_ADAPTER_H
#define IVA_FFT_ADAPTER_H

#include <complex>

namespace kws2k2_faith {

/**
 * @brief IVA的FFT适配器接口
 *
 * 提供与AuxIVA期望兼容的FFT/IFFT API，内部使用iMedia_K2NS_common_FFT实现
 */

/**
 * @brief 初始化FFT适配器
 *
 * @param fft_size FFT大小(必须是2的幂)
 * @return 成功返回0，失败返回负值
 */
int iva_fft_init(int fft_size);

/**
 * @brief 执行正向FFT
 *
 * @param time_in 输入时域信号(复数)
 * @param freq_out 输出频域信号(复数)
 * @param fft_size FFT大小
 * @return 成功返回0，失败返回负值
 */
int iva_fft_forward(const std::complex<float>* time_in,
                    std::complex<float>* freq_out,
                    int fft_size);

/**
 * @brief 执行逆向FFT
 *
 * @param freq_in 输入频域信号(复数)
 * @param time_out 输出时域信号(复数)
 * @param fft_size FFT大小
 * @return 成功返回0，失败返回负值
 */
int iva_fft_inverse(const std::complex<float>* freq_in,
                    std::complex<float>* time_out,
                    int fft_size);

/**
 * @brief 销毁FFT适配器并释放资源
 *
 * @return 成功返回0，失败返回负值
 */
int iva_fft_destroy();

/**
 * @brief 实数到复数的高效FFT
 *
 * @param real_in 输入实数信号
 * @param complex_out 输出复数信号(fft_size/2+1个元素)
 * @param fft_size FFT大小
 * @return 成功返回0，失败返回负值
 */

} // namespace kws2k2_faith

#endif // IVA_FFT_ADAPTER_H
