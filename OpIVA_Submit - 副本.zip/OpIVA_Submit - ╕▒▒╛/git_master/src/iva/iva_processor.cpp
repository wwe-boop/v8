/**
 * @file iva_processor.cpp
 * @brief IVA处理器的实现文件
 */

#include "iva_processor.h"
#include "iva_fft_adapter.h"
#include "../alg_log.h"

#include "auxiva_cpp.h"
#include "stft_processor.h"

#include <chrono>
#include <cstring>
#include <cmath>
#include <vector>

#define LOG_TAG "IVA_PROCESSOR"


// Optional NEON (FP64) for double-precision reductions on AArch64
#if defined(IVA_OPT_C2_NEON) && IVA_OPT_C2_NEON && defined(__aarch64__)
  #include <arm_neon.h>
  #define IVA_HAS_NEON_F64 1
#else
  #define IVA_HAS_NEON_F64 0
#endif

#if IVA_HAS_NEON_F64
namespace {
static inline double neon_sum_squares_f64(const double* x, int n) {
    int i = 0;
    float64x2_t vsum = vdupq_n_f64(0.0);
    for (; i + 1 < n; i += 2) {
        float64x2_t vx = vld1q_f64(x + i);
        float64x2_t vxx = vmulq_f64(vx, vx);
        vsum = vaddq_f64(vsum, vxx);
    }
    double sum = vgetq_lane_f64(vsum, 0) + vgetq_lane_f64(vsum, 1);
    for (; i < n; ++i) sum += x[i] * x[i];
    return sum;
}
} // anonymous namespace
#endif

#if IVA_HAS_NEON_F64
static inline void neon_f64_to_f32(const double* src, float* dst, int n) {
    int i = 0;
    for (; i + 1 < n; i += 2) {
        float64x2_t v = vld1q_f64(src + i);
        float32x2_t vf = vcvt_f32_f64(v);
        vst1_f32(dst + i, vf);
    }
    for (; i < n; ++i) dst[i] = static_cast<float>(src[i]);
}

static inline void neon_f32_to_f64(const float* src, double* dst, int n) {
    int i = 0;
    for (; i + 3 < n; i += 4) {
        float32x4_t vf4 = vld1q_f32(src + i);
        float32x2_t lo = vget_low_f32(vf4);
        float32x2_t hi = vget_high_f32(vf4);
        float64x2_t vd0 = vcvt_f64_f32(lo);
        float64x2_t vd1 = vcvt_f64_f32(hi);
        vst1q_f64(dst + i, vd0);
        vst1q_f64(dst + i + 2, vd1);
    }
    for (; i < n; ++i) dst[i] = static_cast<double>(src[i]);
}
#endif


namespace kws2k2_faith {

/**
 * @brief IvaProcessor的私有实现类
 */
class IvaProcessor::Impl {
public:
    Impl() : initialized_(false), config_(), iva_state_initialized_(false),
             fft_size_(1024), shift_size_(256), stats_() {
        // Initialize stats properly (don't use memset on structures with std::vector)
        stats_.last_process_time_ms = 0.0;
        stats_.last_output_rms = 0.0;
        stats_.last_snr_estimate = 0.0;
        // last_source_energies is initialized by default constructor

        // Initialize IVA algorithm components
        auxiva_processor_.reset(new AuxIVAProcessor());
        stft_processor_.reset(new STFTProcessor());
    }

    ~Impl() {
        if (initialized_) {
            Destroy();
        }
    }

    int Init(const IvaConfig& cfg);
    int Process(const double* const* in_channels, int num_channels, int window_samples, double* out_mono);
    int ProcessAllSources(const double* const* in_channels, int num_channels, int window_samples,
                         double* const* out_channels, double* kws_channel);
    int Reset();
    int Destroy();
    int GetStats(double* process_time_ms, double* source_energies, int num_sources, double* output_rms, double* snr_estimate);
    int GetDetailedStats(double* total_ms,
                         double* convert_input_ms,
                         double* stft_forward_ms,
                         double* auxiva_ms,
                         double* stft_inverse_ms,
                         double* copy_outputs_ms,
                         double* preprocess_ms,
                         double* postprocess_ms);


private:
    bool initialized_;
    IvaConfig config_;

    // IVA algorithm components
    std::unique_ptr<AuxIVAProcessor> auxiva_processor_;
    std::unique_ptr<STFTProcessor> stft_processor_;
    bool iva_state_initialized_;

    // STFT parameters
    int fft_size_;
    int shift_size_;

    // Working buffers
    std::vector<std::vector<float>> input_buffers_;
    std::vector<float> output_buffer_;
    ComplexTensor stft_input_;
    ComplexTensor stft_output_;

    // Statistics
    struct {
        double last_process_time_ms;
        std::vector<double> last_source_energies;
        double last_output_rms;
        double last_snr_estimate;
        // Detailed phase timings (ms)
        double last_convert_input_ms = 0.0;
        double last_stft_forward_ms = 0.0;
        double last_auxiva_ms = 0.0;
        double last_stft_inverse_ms = 0.0;
        double last_copy_outputs_ms = 0.0;
        double last_preprocess_ms = 0.0;
        double last_postprocess_ms = 0.0;
    } stats_;

    // Helper methods
    int ConvertToIvaFormat(const double* const* in_channels, int num_channels, int window_samples);
    int ConvertFromIvaFormat(const std::vector<std::vector<float>>& separated_sources, double* out_mono, int window_samples);
    int PerformIvaProcessing(const double* const* in_channels, int num_channels, int window_samples, double* out_mono);
    double ComputeRMS(const double* signal, int length);
    double ComputeEnergy(const double* signal, int length);
};

// IvaProcessor public interface implementation
IvaProcessor::IvaProcessor() : pImpl(new Impl()) {}

IvaProcessor::~IvaProcessor() = default;

int IvaProcessor::Init(const IvaConfig& cfg) {
    return pImpl->Init(cfg);
}

int IvaProcessor::Process(const double* const* in_channels, int num_channels, int window_samples, double* out_mono) {
    return pImpl->Process(in_channels, num_channels, window_samples, out_mono);
}

int IvaProcessor::ProcessAllSources(const double* const* in_channels, int num_channels, int window_samples,
                                   double* const* out_channels, double* kws_channel) {
    return pImpl->ProcessAllSources(in_channels, num_channels, window_samples, out_channels, kws_channel);
}

int IvaProcessor::Reset() {
    return pImpl->Reset();
}

int IvaProcessor::Destroy() {
    return pImpl->Destroy();
}

int IvaProcessor::GetStats(double* process_time_ms, double* source_energies, int num_sources, double* output_rms, double* snr_estimate) {
    return pImpl->GetStats(process_time_ms, source_energies, num_sources, output_rms, snr_estimate);
}

int IvaProcessor::GetDetailedStats(double* total_ms,
                                   double* convert_input_ms,
                                   double* stft_forward_ms,
                                   double* auxiva_ms,
                                   double* stft_inverse_ms,
                                   double* copy_outputs_ms) {
    if (!pImpl) return -1;
    return pImpl->GetDetailedStats(total_ms, convert_input_ms, stft_forward_ms, auxiva_ms, stft_inverse_ms, copy_outputs_ms, nullptr, nullptr);
}

// Implementation details
int IvaProcessor::Impl::Init(const IvaConfig& cfg) {
    if (initialized_) {
        ALG_LOGE("IvaProcessor already initialized");
        return -1;
    }

    // Validate configuration
    if (cfg.num_channels < 2) {
        ALG_LOGE("IVA requires at least 2 channels, got %d", cfg.num_channels);
        return -1;
    }

    if (cfg.window_samples <= 0) {
        ALG_LOGE("Invalid window_samples: %d", cfg.window_samples);
        return -1;
    }

    if (cfg.target_index < 0 || cfg.target_index >= cfg.num_channels) {
        ALG_LOGE("Invalid target_index: %d (must be 0 to %d)", cfg.target_index, cfg.num_channels - 1);
        return -1;
    }

    config_ = cfg;

    // Initialize FFT adapter
    if (iva_fft_init(fft_size_) != 0) {
        ALG_LOGE("Failed to initialize FFT adapter");
        return -1;
    }

    // Initialize STFT processor
    STFTConfig stft_config;
    stft_config.fft_size = fft_size_;
    stft_config.hop_size = shift_size_;
    stft_config.window_size = fft_size_;
    stft_config.window_type = STFTConfig::HAMMING;

    if (stft_processor_->Initialize(stft_config) != 0) {
        ALG_LOGE("Failed to initialize STFT processor");
        return -1;
    }

    // Initialize AuxIVA processor
    AuxIVAConfig auxiva_config;
    auxiva_config.num_sources = cfg.num_channels;  // Separate all sources
    auxiva_config.num_channels = cfg.num_channels;
    auxiva_config.freq_bins = stft_processor_->GetFreqBins();
    auxiva_config.time_frames = std::max(1, stft_processor_->GetTimeFrames(cfg.window_samples));
    auxiva_config.max_iterations=60;  // 最大迭代次数
    auxiva_config.convergence_threshold = 1e-4;
    auxiva_config.eps = 2.220446049250313e-16;


    // 统一eps处理
    if (auxiva_config.eps < 1e-12) {
        auxiva_config.eps = 1e-12;
    }
    auxiva_config.normalize_demixing = true;
    auxiva_config.use_convergence_check = true;  // 启用提前停止以加速

    if (auxiva_processor_->Initialize(auxiva_config) != 0) {
        ALG_LOGE("Failed to initialize AuxIVA processor");
        stft_processor_->Cleanup();
        return -1;
    }

    iva_state_initialized_ = true;

    // Allocate working buffers
    input_buffers_.resize(cfg.num_channels);
    for (auto& buffer : input_buffers_) {
        buffer.resize(cfg.window_samples);
    }
    output_buffer_.resize(cfg.window_samples);

    stats_.last_source_energies.resize(cfg.num_channels);

    initialized_ = true;

    ALG_LOGI("IVA processor initialized: channels=%d, window_samples=%d, target_index=%d",
             cfg.num_channels, cfg.window_samples, cfg.target_index);

    return 0;
}

int IvaProcessor::Impl::Process(const double* const* in_channels, int num_channels, int window_samples, double* out_mono) {
    if (!initialized_) {
        ALG_LOGE("IvaProcessor not initialized");
        return -1;
    }

    // Check for null pointers
    if (!in_channels || !out_mono) {
        ALG_LOGE("Null pointer in Process: in_channels=%p, out_mono=%p", in_channels, out_mono);
        return -1;
    }

    // Check individual channel pointers
    for (int i = 0; i < num_channels; ++i) {
        if (!in_channels[i]) {
            ALG_LOGE("Null pointer for channel %d", i);
            return -1;
        }
    }

    if (num_channels != config_.num_channels || window_samples != config_.window_samples) {
        ALG_LOGE("Input parameters mismatch: expected %d channels, %d samples; got %d channels, %d samples",
                 config_.num_channels, config_.window_samples, num_channels, window_samples);
        return -1;
    }

    auto start_time = std::chrono::high_resolution_clock::now();

    // Note: removed redundant ConvertToIvaFormat here. PerformIvaProcessing will convert preprocessed data once.

    // Perform actual IVA processing (includes all format conversion)
    if (PerformIvaProcessing(in_channels, num_channels, window_samples, out_mono) != 0) {
        ALG_LOGE("IVA processing failed");
        return -1;
    }

    auto end_time = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end_time - start_time);
    stats_.last_process_time_ms = duration.count() / 1000.0;

    // Compute statistics (A3: single-pass reuse for SNR input energy)
    for (int i = 0; i < num_channels; ++i) {
        stats_.last_source_energies[i] = ComputeEnergy(in_channels[i], window_samples);
    }
    stats_.last_output_rms = ComputeRMS(out_mono, window_samples);
    // Reuse precomputed input energy to avoid duplicate computation
    double input_energy_cached =
        (config_.target_index >= 0 && config_.target_index < static_cast<int>(stats_.last_source_energies.size()))
            ? stats_.last_source_energies[config_.target_index]
            : ComputeEnergy(in_channels[config_.target_index], window_samples);
    stats_.last_snr_estimate = 10.0 * log10((stats_.last_output_rms * stats_.last_output_rms) / (input_energy_cached + 1e-10) + 1e-10);

    return 0;
}

int IvaProcessor::Impl::ProcessAllSources(const double* const* in_channels, int num_channels, int window_samples,
                                          double* const* out_channels, double* kws_channel) {
    if (!initialized_) {
        ALG_LOGE("IVA processor not initialized");
        return -1;
    }

    if (!in_channels || !out_channels || !kws_channel) {
        ALG_LOGE("Null pointer in ProcessAllSources");
        return -1;
    }

    if (num_channels != config_.num_channels) {
        ALG_LOGE("Channel count mismatch: expected %d, got %d", config_.num_channels, num_channels);
        return -1;
    }

    if (window_samples != config_.window_samples) {
        ALG_LOGE("Window size mismatch: expected %d, got %d", config_.window_samples, window_samples);
        return -1;
    }

    if (!iva_state_initialized_) {
        ALG_LOGE("IVA state not initialized");
        return -1;
    }

    // Reset phase timings
    stats_.last_convert_input_ms = 0.0;
    stats_.last_stft_forward_ms = 0.0;
    stats_.last_auxiva_ms = 0.0;
    stats_.last_stft_inverse_ms = 0.0;
    stats_.last_copy_outputs_ms = 0.0;

    auto t0 = std::chrono::high_resolution_clock::now();

    // Convert input to IVA format
    auto t_conv_start = std::chrono::high_resolution_clock::now();
    if (ConvertToIvaFormat(in_channels, num_channels, window_samples) != 0) {
        ALG_LOGE("Failed to convert input to IVA format");
        return -1;
    }
    auto t_conv_end = std::chrono::high_resolution_clock::now();
    stats_.last_convert_input_ms = std::chrono::duration_cast<std::chrono::microseconds>(t_conv_end - t_conv_start).count() / 1000.0;

    // Perform forward STFT
    auto t_fwd_start = std::chrono::high_resolution_clock::now();
    if (stft_processor_->Forward(input_buffers_, stft_input_) != 0) {
        ALG_LOGE("STFT forward failed");
        return -1;
    }
    auto t_fwd_end = std::chrono::high_resolution_clock::now();
    stats_.last_stft_forward_ms = std::chrono::duration_cast<std::chrono::microseconds>(t_fwd_end - t_fwd_start).count() / 1000.0;

    // Perform AuxIVA source separation
    auto t_aux_start = std::chrono::high_resolution_clock::now();
    if (auxiva_processor_->Process(stft_input_, stft_output_) != 0) {
        ALG_LOGE("AuxIVA separation failed");
        return -1;
    }
    auto t_aux_end = std::chrono::high_resolution_clock::now();
    stats_.last_auxiva_ms = std::chrono::duration_cast<std::chrono::microseconds>(t_aux_end - t_aux_start).count() / 1000.0;

    // Perform inverse STFT
    auto t_inv_start = std::chrono::high_resolution_clock::now();
    std::vector<std::vector<float>> separated_sources;
    if (stft_processor_->Inverse(stft_output_, separated_sources) != 0) {
        ALG_LOGE("STFT inverse failed");
        return -1;
    }
    auto t_inv_end = std::chrono::high_resolution_clock::now();
    stats_.last_stft_inverse_ms = std::chrono::duration_cast<std::chrono::microseconds>(t_inv_end - t_inv_start).count() / 1000.0;

    // Copy all separated sources to output channels
    auto t_copy_start = std::chrono::high_resolution_clock::now();
    for (int ch = 0; ch < num_channels && ch < static_cast<int>(separated_sources.size()); ++ch) {
        const auto& source = separated_sources[ch];
        int samples_to_copy = std::min(window_samples, static_cast<int>(source.size()));

        for (int i = 0; i < samples_to_copy; i++) {
            out_channels[ch][i] = source[i];
        }

        // Pad with zeros if needed
        for (int i = samples_to_copy; i < window_samples; i++) {
            out_channels[ch][i] = 0.0f;
        }
    }

    // Use configured target_index for KWS channel selection
    int kws_source_index = config_.target_index;
    if (kws_source_index < static_cast<int>(separated_sources.size())) {
        const auto& kws_source = separated_sources[kws_source_index];
        int samples_to_copy = std::min(window_samples, static_cast<int>(kws_source.size()));

        for (int i = 0; i < samples_to_copy; i++) {
            kws_channel[i] = kws_source[i];
        }

        // Pad with zeros if needed
        for (int i = samples_to_copy; i < window_samples; i++) {
            kws_channel[i] = 0.0f;
        }
    } else {
        ALG_LOGE("KWS source index %d not available", kws_source_index);
        // Fill with zeros as fallback
        for (int i = 0; i < window_samples; i++) {
            kws_channel[i] = 0.0f;
        }
    }
    auto t_copy_end = std::chrono::high_resolution_clock::now();
    stats_.last_copy_outputs_ms = std::chrono::duration_cast<std::chrono::microseconds>(t_copy_end - t_copy_start).count() / 1000.0;

    auto t1 = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(t1 - t0);
    stats_.last_process_time_ms = duration.count() / 1000.0;

    ALG_LOGI("[IVA] ProcessAllSources: channels=%d, window_samples=%d", num_channels, window_samples);
    ALG_LOGI("[IVA] process_ms=%.2f, kws_source_index=%d (target_index), total_sources=%d",
             stats_.last_process_time_ms, kws_source_index, num_channels);

    // Compute and log source energies (A3: compute for all channels once)
    for (int i = 0; i < num_channels; ++i) {
        double energy = ComputeEnergy(in_channels[i], window_samples);
        if (i < static_cast<int>(stats_.last_source_energies.size())) stats_.last_source_energies[i] = energy;
        if (i < 2) {
            ALG_LOGI("[IVA] source%d_energy=%.6f", i, energy);
        }
    }

    double kws_rms = ComputeRMS(kws_channel, window_samples);
    stats_.last_output_rms = kws_rms;

    // 估计SNR（基于KWS通道与输入的能量比）
    // Reuse cached energy for SNR to avoid duplicate computation
    int input_idx = (kws_source_index < num_channels ? kws_source_index : 0);
    double input_energy = (input_idx < static_cast<int>(stats_.last_source_energies.size()))
                              ? stats_.last_source_energies[input_idx]
                              : ComputeEnergy(in_channels[input_idx], window_samples);
    stats_.last_snr_estimate = 10.0 * log10((kws_rms * kws_rms) / (input_energy + 1e-10) + 1e-10);

    ALG_LOGI("[IVA] kws_output_rms=%.6f, snr_est=%.2f", kws_rms, stats_.last_snr_estimate);

    return 0;
}

int IvaProcessor::Impl::Reset() {
    if (!initialized_) {
        ALG_LOGE("Cannot reset uninitialized IVA processor");
        return -1;
    }

    if (!iva_state_initialized_) {
        ALG_LOGE("Cannot reset uninitialized IVA state");
        return -1;
    }

    // Reset AuxIVA algorithm state (demixing matrices, etc.)
    if (auxiva_processor_) {
        auxiva_processor_->Reset();
        ALG_LOGI("AuxIVA processor state reset");
    }

    // Reset statistics
    stats_.last_process_time_ms = 0.0;
    stats_.last_output_rms = 0.0;
    stats_.last_snr_estimate = 0.0;
    std::fill(stats_.last_source_energies.begin(), stats_.last_source_energies.end(), 0.0);

    ALG_LOGI("IVA processor state reset for new file processing");
    return 0;
}

int IvaProcessor::Impl::Destroy() {
    if (!initialized_) {
        return 0;
    }

    // Cleanup IVA components
    if (iva_state_initialized_) {
        if (auxiva_processor_) {
            auxiva_processor_->Cleanup();
        }
        if (stft_processor_) {
            stft_processor_->Cleanup();
        }
        iva_state_initialized_ = false;
    }



    // Clear buffers
    input_buffers_.clear();
    output_buffer_.clear();
    stats_.last_source_energies.clear();

    initialized_ = false;

    ALG_LOGI("IVA processor destroyed");
    return 0;
}

int IvaProcessor::Impl::GetStats(double* process_time_ms, double* source_energies, int num_sources, double* output_rms, double* snr_estimate) {
    if (!initialized_) {
        return -1;
    }

    if (process_time_ms) *process_time_ms = stats_.last_process_time_ms;
    if (output_rms) *output_rms = stats_.last_output_rms;
    if (snr_estimate) *snr_estimate = stats_.last_snr_estimate;

    if (source_energies && num_sources > 0) {
        int copy_count = std::min(num_sources, static_cast<int>(stats_.last_source_energies.size()));
        for (int i = 0; i < copy_count; ++i) {
            source_energies[i] = stats_.last_source_energies[i];
        }
    }

    return 0;
}

int IvaProcessor::Impl::GetDetailedStats(double* total_ms,
                                         double* convert_input_ms,
                                         double* stft_forward_ms,
                                         double* auxiva_ms,
                                         double* stft_inverse_ms,
                                         double* copy_outputs_ms,
                                         double* preprocess_ms,
                                         double* postprocess_ms) {
    if (!initialized_) return -1;
    if (total_ms) *total_ms = stats_.last_process_time_ms;
    if (convert_input_ms) *convert_input_ms = stats_.last_convert_input_ms;
    if (stft_forward_ms) *stft_forward_ms = stats_.last_stft_forward_ms;
    if (auxiva_ms) *auxiva_ms = stats_.last_auxiva_ms;
    if (stft_inverse_ms) *stft_inverse_ms = stats_.last_stft_inverse_ms;
    if (copy_outputs_ms) *copy_outputs_ms = stats_.last_copy_outputs_ms;
    if (preprocess_ms) *preprocess_ms = stats_.last_preprocess_ms;
    if (postprocess_ms) *postprocess_ms = stats_.last_postprocess_ms;
    return 0;
}



double IvaProcessor::Impl::ComputeRMS(const double* signal, int length) {
    if (!signal || length <= 0) return 0.0;

    double sum_squares = 0.0;
#if IVA_HAS_NEON_F64
    sum_squares = neon_sum_squares_f64(signal, length);
#else
    for (int i = 0; i < length; ++i) {
        sum_squares += signal[i] * signal[i];
    }
#endif
    return std::sqrt(sum_squares / length);
}

double IvaProcessor::Impl::ComputeEnergy(const double* signal, int length) {
    if (!signal || length <= 0) return 0.0;

#if IVA_HAS_NEON_F64
    return neon_sum_squares_f64(signal, length);
#else
    double energy = 0.0;
    for (int i = 0; i < length; ++i) {
        energy += signal[i] * signal[i];
    }
    return energy;
#endif
}

int IvaProcessor::Impl::PerformIvaProcessing(const double* const* in_channels, int num_channels, int window_samples, double* out_mono) {
    if (!iva_state_initialized_) {
        ALG_LOGE("IVA state not initialized");
        return -1;
    }

    // Validate target index
    if (config_.target_index < 0 || config_.target_index >= num_channels) {
        ALG_LOGE("Invalid target index %d for %d channels", config_.target_index, num_channels);
        return -1;
    }

    // Reset phase timings
    stats_.last_preprocess_ms = 0.0;
    stats_.last_convert_input_ms = 0.0;
    stats_.last_stft_forward_ms = 0.0;
    stats_.last_auxiva_ms = 0.0;
    stats_.last_stft_inverse_ms = 0.0;
    stats_.last_copy_outputs_ms = 0.0;
    stats_.last_postprocess_ms = 0.0;

    auto t0 = std::chrono::high_resolution_clock::now();

    // 步骤1: 预处理
    auto t_pre_start = std::chrono::high_resolution_clock::now();
    std::vector<std::vector<double>> audio_data(num_channels, std::vector<double>(window_samples));
    for (int ch = 0; ch < num_channels; ch++) {
        for (int i = 0; i < window_samples; i++) {
            audio_data[ch][i] = in_channels[ch][i];
        }
    }

    AudioPreprocessing preprocessing;
    if (ApplyPreprocessing(audio_data, num_channels, window_samples, preprocessing, 200) != 0) {
        ALG_LOGE("Failed to apply preprocessing");
        return -1;
    }
    auto t_pre_end = std::chrono::high_resolution_clock::now();
    stats_.last_preprocess_ms = std::chrono::duration_cast<std::chrono::microseconds>(t_pre_end - t_pre_start).count() / 1000.0;

    // Convert preprocessed data to IVA format
    auto t_conv_start = std::chrono::high_resolution_clock::now();
    std::vector<const double*> preprocessed_ptrs(num_channels);
    for (int ch = 0; ch < num_channels; ch++) {
        preprocessed_ptrs[ch] = audio_data[ch].data();
    }

    if (ConvertToIvaFormat(preprocessed_ptrs.data(), num_channels, window_samples) != 0) {
        ALG_LOGE("Failed to convert input to IVA format");
        return -1;
    }
    auto t_conv_end = std::chrono::high_resolution_clock::now();
    stats_.last_convert_input_ms = std::chrono::duration_cast<std::chrono::microseconds>(t_conv_end - t_conv_start).count() / 1000.0;

    // Perform STFT
    auto t_fwd_start = std::chrono::high_resolution_clock::now();
    if (stft_processor_->Forward(input_buffers_, stft_input_) != 0) {
        ALG_LOGE("STFT forward failed");
        return -1;
    }
    auto t_fwd_end = std::chrono::high_resolution_clock::now();
    stats_.last_stft_forward_ms = std::chrono::duration_cast<std::chrono::microseconds>(t_fwd_end - t_fwd_start).count() / 1000.0;

    // Perform AuxIVA source separation
    auto t_aux_start = std::chrono::high_resolution_clock::now();
    if (auxiva_processor_->Process(stft_input_, stft_output_) != 0) {
        ALG_LOGE("AuxIVA separation failed");
        return -1;
    }
    auto t_aux_end = std::chrono::high_resolution_clock::now();
    stats_.last_auxiva_ms = std::chrono::duration_cast<std::chrono::microseconds>(t_aux_end - t_aux_start).count() / 1000.0;

    // Perform inverse STFT
    auto t_inv_start = std::chrono::high_resolution_clock::now();
    std::vector<std::vector<float>> separated_sources;
    if (stft_processor_->Inverse(stft_output_, separated_sources) != 0) {
        ALG_LOGE("STFT inverse failed");
        return -1;
    }
    auto t_inv_end = std::chrono::high_resolution_clock::now();
    stats_.last_stft_inverse_ms = std::chrono::duration_cast<std::chrono::microseconds>(t_inv_end - t_inv_start).count() / 1000.0;

    // 步骤2: 直接对 float 缓冲应用后处理，避免 float<->double 往返
    auto t_copy_start = std::chrono::high_resolution_clock::now();

    // 应用后处理恢复前导200点
    auto t_post_start = std::chrono::high_resolution_clock::now();
    if (ApplyPostprocessing(separated_sources, static_cast<int>(separated_sources.size()), window_samples, preprocessing) != 0) {
        ALG_LOGE("Failed to apply postprocessing");
        return -1;
    }
    auto t_post_end = std::chrono::high_resolution_clock::now();
    stats_.last_postprocess_ms = std::chrono::duration_cast<std::chrono::microseconds>(t_post_end - t_post_start).count() / 1000.0;

    // Extract target source and convert to output format
    if (config_.target_index < static_cast<int>(separated_sources.size())) {
        for (int i = 0; i < window_samples; i++) {
            out_mono[i] = separated_sources[config_.target_index][i];
        }
    } else {
        ALG_LOGE("Invalid target index %d for %zu separated sources", config_.target_index, separated_sources.size());
        return -1;
    }
    auto t_copy_end = std::chrono::high_resolution_clock::now();
    stats_.last_copy_outputs_ms = std::chrono::duration_cast<std::chrono::microseconds>(t_copy_end - t_copy_start).count() / 1000.0;

    auto t1 = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(t1 - t0);
    stats_.last_process_time_ms = duration.count() / 1000.0;

    ALG_LOGI("[IVA] enabled=true, num_channels=%d, window_samples=%d", num_channels, window_samples);
    ALG_LOGI("[IVA] process_ms=%.2f, selected_source_index=%d (zero_based), total_sources=%d",
             stats_.last_process_time_ms, config_.target_index, num_channels);

    // Compute and log source energies (A3: compute once and reuse later)
    for (int i = 0; i < num_channels; ++i) {
        double energy = ComputeEnergy(in_channels[i], window_samples);
        if (i < 2) {
            ALG_LOGI("[IVA] source%d_energy=%.6f", i, energy);
        }
    }

    double output_rms = ComputeRMS(out_mono, window_samples);
    stats_.last_output_rms = output_rms;

    // 估计SNR（基于输出与输入的能量比）
    // Reuse cached energy for SNR to avoid duplicate computation
    double input_energy = (config_.target_index >= 0 && config_.target_index < static_cast<int>(stats_.last_source_energies.size()))
                              ? stats_.last_source_energies[config_.target_index]
                              : ComputeEnergy(in_channels[config_.target_index], window_samples);
    stats_.last_snr_estimate = 10.0 * log10((output_rms * output_rms) / (input_energy + 1e-10) + 1e-10);

    ALG_LOGI("[IVA] output_rms=%.6f, snr_est=%.2f", output_rms, stats_.last_snr_estimate);

    return 0;
}

int IvaProcessor::Impl::ConvertToIvaFormat(const double* const* in_channels, int num_channels, int window_samples) {
    // Resize channel container only when needed
    if (static_cast<int>(input_buffers_.size()) != num_channels) {
        input_buffers_.resize(num_channels);
    }
    for (int ch = 0; ch < num_channels; ch++) {
        // Avoid redundant resize when size already matches
        if (static_cast<int>(input_buffers_[ch].size()) != window_samples) {
            input_buffers_[ch].resize(window_samples);
        }
        // Copy/convert input data (double -> float)
#if IVA_HAS_NEON_F64
        neon_f64_to_f32(in_channels[ch], input_buffers_[ch].data(), window_samples);
#else
        for (int i = 0; i < window_samples; i++) {
            input_buffers_[ch][i] = static_cast<float>(in_channels[ch][i]);
        }
#endif
    }
    return 0;
}

int IvaProcessor::Impl::ConvertFromIvaFormat(const std::vector<std::vector<float>>& separated_sources, double* out_mono, int window_samples) {
    if (separated_sources.empty() || config_.target_index >= static_cast<int>(separated_sources.size())) {
        ALG_LOGE("Invalid separated sources or target index");
        return -1;
    }

    const auto& target_source = separated_sources[config_.target_index];
    int samples_to_copy = std::min(window_samples, static_cast<int>(target_source.size()));

    // Copy target source to output (convert float to double)
    for (int i = 0; i < samples_to_copy; i++) {
        out_mono[i] = static_cast<double>(target_source[i]);
    }

    // Zero-pad if needed
    for (int i = samples_to_copy; i < window_samples; i++) {
        out_mono[i] = 0.0f;
    }

    return 0;
}

// Static methods for preprocessing and postprocessing
int IvaProcessor::ApplyPreprocessing(std::vector<std::vector<double>>& audio_data,
                                    int num_channels, int num_samples,
                                    AudioPreprocessing& preprocessing,
                                    int header_samples) {
    if (audio_data.empty() || num_channels <= 0 || num_samples <= 0) {
        ALG_LOGE("Invalid audio data for preprocessing");
        return -1;
    }

    if (header_samples <= 0 || header_samples >= num_samples) {
        ALG_LOGE("Invalid header_samples: %d (must be 0 < header_samples < %d)", header_samples, num_samples);
        return -1;
    }

    // 1. 保存前N个采样点 (original_first_200 = mixture(1:200, :))
    preprocessing.header_samples = header_samples;
    preprocessing.original_header.resize(header_samples * num_channels);

    for (int ch = 0; ch < num_channels; ch++) {
        for (int i = 0; i < header_samples; i++) {
            preprocessing.original_header[ch * header_samples + i] = audio_data[ch][i];
        }
    }

    // 2. 清零前N个采样点 (mixture(1:200, :) = 0)
    for (int ch = 0; ch < num_channels; ch++) {
        for (int i = 0; i < header_samples; i++) {
            audio_data[ch][i] = 0.0;  // 双精度
        }
    }

    // 3. 计算归一化因子 (max(abs(mixture(:))))

    double max_abs = 0.0;  // 双精度
    for (int i = 0; i < num_samples * num_channels; i++) {
        int sample_idx = i / num_channels;  // 样本索引
        int channel_idx = i % num_channels; // 通道索引

        if (sample_idx < num_samples && channel_idx < num_channels) {
            double abs_val = std::abs(audio_data[channel_idx][sample_idx]);  // 双精度
            if (abs_val > max_abs) {
                max_abs = abs_val;
            }
        }
    }

    preprocessing.normalization_factor = max_abs;

    // 4. 归一化 (mixture = mixture / max(abs(mixture(:))))
    if (max_abs > 1e-15) {  // 避免除零，双精度阈值
        for (int ch = 0; ch < num_channels; ch++) {
            for (int i = 0; i < num_samples; i++) {
                audio_data[ch][i] /= max_abs;
            }
        }
    }

    preprocessing.initialized = true;

    ALG_LOGI("Audio preprocessing applied:");
    ALG_LOGI("  Header samples: %d", header_samples);
    ALG_LOGI("  Normalization factor: %.6f", preprocessing.normalization_factor);
    ALG_LOGI("  Max value after normalization: %.6f", 1.0f);

    return 0;
}

int IvaProcessor::ApplyPostprocessing(std::vector<std::vector<double>>& audio_data,  // 改为双精度
                                     int num_channels, int num_samples,
                                     const AudioPreprocessing& preprocessing) {
    if (!preprocessing.initialized) {
        ALG_LOGE("Preprocessing not initialized");
        return -1;
    }

    if (audio_data.empty() || num_channels <= 0 || num_samples <= 0) {
        ALG_LOGE("Invalid audio data for postprocessing");
        return -1;
    }

    if (preprocessing.header_samples <= 0 || preprocessing.header_samples >= num_samples) {
        ALG_LOGE("Invalid header_samples in preprocessing: %d", preprocessing.header_samples);
        return -1;
    }

    // 恢复前N个采样点
    for (int ch = 0; ch < num_channels; ch++) {
        for (int i = 0; i < preprocessing.header_samples; i++) {
            audio_data[ch][i] = preprocessing.original_header[ch * preprocessing.header_samples + i];
        }
    }

    ALG_LOGI("Audio postprocessing applied:");
    ALG_LOGI("  Restored %d header samples", preprocessing.header_samples);
    ALG_LOGI("  No denormalization (matching MATLAB behavior)");

    return 0;
}

int IvaProcessor::ApplyPostprocessing(std::vector<std::vector<float>>& audio_data,
                                     int num_channels, int num_samples,
                                     const AudioPreprocessing& preprocessing) {
    if (!preprocessing.initialized) {
        ALG_LOGE("Preprocessing not initialized");
        return -1;
    }

    if (audio_data.empty() || num_channels <= 0 || num_samples <= 0) {
        ALG_LOGE("Invalid audio data for postprocessing");
        return -1;
    }

    if (preprocessing.header_samples <= 0 || preprocessing.header_samples >= num_samples) {
        ALG_LOGE("Invalid header_samples in preprocessing: %d", preprocessing.header_samples);
        return -1;
    }

    // 恢复前N个采样点
    for (int ch = 0; ch < num_channels; ch++) {
        for (int i = 0; i < preprocessing.header_samples; i++) {
            audio_data[ch][i] = static_cast<float>(preprocessing.original_header[ch * preprocessing.header_samples + i]);
        }
    }

    ALG_LOGI("Audio postprocessing applied (float):");
    ALG_LOGI("  Restored %d header samples", preprocessing.header_samples);
    ALG_LOGI("  No denormalization (matching MATLAB behavior)");

    return 0;
}

} // namespace kws2k2_faith
