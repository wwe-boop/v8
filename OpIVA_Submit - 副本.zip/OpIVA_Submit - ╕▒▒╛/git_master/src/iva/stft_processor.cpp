/**
 * @file stft_processor.cpp
 * @brief STFT处理器的实现，提供多通道音频的时频变换功能
 */

#include "stft_processor.h"
#include "iva_fft_adapter.h"
#include "../imedia_common_basic_op.h"
#include "../alg_log.h"
#include <cmath>
#include <algorithm>

//  Optional NEON acceleration
#if defined(IVA_OPT_C2_NEON) && IVA_OPT_C2_NEON && (defined(__ARM_NEON) || defined(__aarch64__))
  #include <arm_neon.h>
  #define IVA_HAS_NEON 1
#else
  #define IVA_HAS_NEON 0
#endif

#if IVA_HAS_NEON
namespace {
static inline void neon_mul_window(const float* in, const float* win, float* out, int len) {
    int i = 0;
    for (; i + 3 < len; i += 4) {
        float32x4_t v_in = vld1q_f32(in + i);
        float32x4_t v_w  = vld1q_f32(win + i);
        float32x4_t v_m  = vmulq_f32(v_in, v_w);
        vst1q_f32(out + i, v_m);
    }
    for (; i < len; ++i) {
        out[i] = in[i] * win[i];
    }
}

static inline void neon_mul_inplace(float* data, const float* win, int len) {
    int i = 0;
    for (; i + 3 < len; i += 4) {
        float32x4_t v_d = vld1q_f32(data + i);
        float32x4_t v_w = vld1q_f32(win + i);
        float32x4_t v_m = vmulq_f32(v_d, v_w);
        vst1q_f32(data + i, v_m);
    }
    for (; i < len; ++i) {
        data[i] *= win[i];
    }
}

static inline void neon_overlap_add(float* out, const float* in, int len) {
    int i = 0;
    for (; i + 3 < len; i += 4) {
        float32x4_t v_o = vld1q_f32(out + i);
        float32x4_t v_i = vld1q_f32(in + i);
        float32x4_t v_s = vaddq_f32(v_o, v_i);
        vst1q_f32(out + i, v_s);
    }
    for (; i < len; ++i) {
        out[i] += in[i];
    }
}

#if defined(IVA_OPT_C6_STFT_Q15) && IVA_OPT_C6_STFT_Q15
// Q15版本的NEON函数
static inline void neon_mul_window_q15(const int16_t* in, const int16_t* win, float* out, int len) {
    int i = 0;
    for (; i + 7 < len; i += 8) {
        int16x8_t v_in = vld1q_s16(in + i);
        int16x8_t v_win = vld1q_s16(win + i);

        // Q15 * Q15 = Q30，需要右移15位回到Q15，然后转换为float
        int32x4_t mul_lo = vmull_s16(vget_low_s16(v_in), vget_low_s16(v_win));
        int32x4_t mul_hi = vmull_s16(vget_high_s16(v_in), vget_high_s16(v_win));

        // 右移15位得到Q15结果
        int16x4_t result_lo = vshrn_n_s32(mul_lo, 15);
        int16x4_t result_hi = vshrn_n_s32(mul_hi, 15);

        // 转换为float
        int32x4_t ext_lo = vmovl_s16(result_lo);
        int32x4_t ext_hi = vmovl_s16(result_hi);
        float32x4_t f_lo = vcvtq_f32_s32(ext_lo);
        float32x4_t f_hi = vcvtq_f32_s32(ext_hi);

        // 除以32768.0 (2^15) 转换为浮点
        float32x4_t scale = vdupq_n_f32(1.0f / 32768.0f);
        f_lo = vmulq_f32(f_lo, scale);
        f_hi = vmulq_f32(f_hi, scale);

        vst1q_f32(out + i, f_lo);
        vst1q_f32(out + i + 4, f_hi);
    }

    // 处理剩余元素
    for (; i < len; ++i) {
        int32_t result = (static_cast<int32_t>(in[i]) * static_cast<int32_t>(win[i])) >> 15;
        out[i] = static_cast<float>(result) / 32768.0f;
    }
}

static inline void neon_mul_inplace_q15(float* data, const int16_t* win, int len) {
    int i = 0;
    for (; i + 7 < len; i += 8) {
        // 加载浮点数据并转换为Q15
        float32x4_t f_lo = vld1q_f32(data + i);
        float32x4_t f_hi = vld1q_f32(data + i + 4);

        // 转换为Q15 (乘以32768并饱和到int16)
        float32x4_t scale = vdupq_n_f32(32768.0f);
        int32x4_t i32_lo = vcvtq_s32_f32(vmulq_f32(f_lo, scale));
        int32x4_t i32_hi = vcvtq_s32_f32(vmulq_f32(f_hi, scale));
        int16x4_t i16_lo = vqmovn_s32(i32_lo);
        int16x4_t i16_hi = vqmovn_s32(i32_hi);

        // 加载窗函数
        int16x8_t v_win = vld1q_s16(win + i);
        int16x4_t win_lo = vget_low_s16(v_win);
        int16x4_t win_hi = vget_high_s16(v_win);

        // Q15乘法
        int32x4_t mul_lo = vmull_s16(i16_lo, win_lo);
        int32x4_t mul_hi = vmull_s16(i16_hi, win_hi);

        // 右移15位并转换回float
        int16x4_t result_lo = vshrn_n_s32(mul_lo, 15);
        int16x4_t result_hi = vshrn_n_s32(mul_hi, 15);

        int32x4_t ext_lo = vmovl_s16(result_lo);
        int32x4_t ext_hi = vmovl_s16(result_hi);
        f_lo = vcvtq_f32_s32(ext_lo);
        f_hi = vcvtq_f32_s32(ext_hi);

        float32x4_t inv_scale = vdupq_n_f32(1.0f / 32768.0f);
        f_lo = vmulq_f32(f_lo, inv_scale);
        f_hi = vmulq_f32(f_hi, inv_scale);

        vst1q_f32(data + i, f_lo);
        vst1q_f32(data + i + 4, f_hi);
    }

    // 处理剩余元素
    for (; i < len; ++i) {
        int16_t data_q15 = static_cast<int16_t>(data[i] * 32768.0f);
        int32_t result = (static_cast<int32_t>(data_q15) * static_cast<int32_t>(win[i])) >> 15;
        data[i] = static_cast<float>(result) / 32768.0f;
    }
}
#endif

} // anonymous namespace
#endif

namespace kws2k2_faith {

int STFTProcessor::Initialize(const STFTConfig& config) {
    config_ = config;
    
    // Validate configuration
    if (config_.fft_size <= 0 || config_.hop_size <= 0 || config_.window_size <= 0) {
        ALG_LOGE("Invalid STFT configuration");
        return -1;
    }
    
    if (config_.hop_size > config_.fft_size) {
        ALG_LOGE("Hop size (%d) cannot be larger than FFT size (%d)", 
                 config_.hop_size, config_.fft_size);
        return -1;
    }
    
    // Initialize FFT
    if (iva_fft_init(config_.fft_size) != 0) {
        ALG_LOGE("Failed to initialize FFT");
        return -1;
    }
    
    freq_bins_ = config_.fft_size / 2 + 1;
    
    // Generate window
    GenerateWindow();
    
    // Allocate working buffers
    fft_buffer_.resize(config_.fft_size);
    temp_frame_.resize(config_.fft_size);
    freq_frame_buffer_.resize(freq_bins_);
    fft_output_buffer_.resize(config_.fft_size);
    full_spectrum_buffer_.resize(config_.fft_size);
    ifft_output_buffer_.resize(config_.fft_size);
    time_frame_buffer_.resize(config_.fft_size);

    initialized_ = true;
    ALG_LOGI("STFT processor initialized: FFT size=%d, hop size=%d, freq bins=%d",
             config_.fft_size, config_.hop_size, freq_bins_);

    return 0;
}

void STFTProcessor::GenerateWindow() {
    window_.resize(config_.window_size);
    synthesis_window_.resize(config_.window_size);

#if defined(IVA_OPT_C6_STFT_Q15) && IVA_OPT_C6_STFT_Q15
    window_q15_.resize(config_.window_size);
    synthesis_window_q15_.resize(config_.window_size);
#endif
    
    for (int i = 0; i < config_.window_size; i++) {
        float w = 0.0f;
        float n = static_cast<float>(i);
        float N = static_cast<float>(config_.window_size - 1);
        
        switch (config_.window_type) {
            case STFTConfig::HANN:
                w = 0.5f * (1.0f - std::cos(2.0f * M_PI * n / N));
                break;
            case STFTConfig::HAMMING:
                w = 0.54f - 0.46f * std::cos(2.0f * M_PI * n / N);
                break;
            case STFTConfig::BLACKMAN:
                w = 0.42f - 0.5f * std::cos(2.0f * M_PI * n / N) + 
                    0.08f * std::cos(4.0f * M_PI * n / N);
                break;
        }
        
        window_[i] = w;
        synthesis_window_[i] = w;

#if defined(IVA_OPT_C6_STFT_Q15) && IVA_OPT_C6_STFT_Q15
        // 同时生成Q15版本的窗函数
        window_q15_[i] = FloatToQ15(w);
        synthesis_window_q15_[i] = FloatToQ15(w);
#endif
    }
    
    // Normalize synthesis window for perfect reconstruction
    float window_sum = 0.0f;
    for (int i = 0; i < config_.window_size; i++) {
        window_sum += synthesis_window_[i] * synthesis_window_[i];
    }
    
    if (window_sum > 0.0f) {
        float norm_factor = static_cast<float>(config_.hop_size) / window_sum;
        for (int i = 0; i < config_.window_size; i++) {
            synthesis_window_[i] *= norm_factor;
        }
    }
}

int STFTProcessor::GetTimeFrames(int input_length) const {
    if (input_length < config_.fft_size) {
        return 0;
    }
    return (input_length - config_.fft_size) / config_.hop_size + 1;
}

int STFTProcessor::Forward(const std::vector<std::vector<float>>& input, ComplexTensor& output) {
    if (!initialized_) {
        ALG_LOGE("STFT processor not initialized");
        return -1;
    }
    
    if (input.empty() || input[0].empty()) {
        ALG_LOGE("Empty input");
        return -1;
    }
    
    int num_channels = input.size();
    int input_length = input[0].size();
    int time_frames = GetTimeFrames(input_length);
    
    if (time_frames <= 0) {
        ALG_LOGE("Input too short for STFT");
        return -1;
    }
    
    // Resize output [freq][time][channel]
    output.resize(freq_bins_);
    for (int f = 0; f < freq_bins_; f++) {
        output[f].resize(time_frames);
        for (int t = 0; t < time_frames; t++) {
            output[f][t].resize(num_channels);
        }
    }
    
    // Process each channel
    for (int ch = 0; ch < num_channels; ch++) {
        for (int frame = 0; frame < time_frames; frame++) {
            int frame_start = frame * config_.hop_size;
            
            // Extract and window frame
            std::fill(temp_frame_.begin(), temp_frame_.end(), 0.0f);
            {
                int len = std::min(config_.window_size, input_length - frame_start);
            #if defined(IVA_OPT_C6_STFT_Q15) && IVA_OPT_C6_STFT_Q15 && IVA_HAS_NEON
                // Q15定点窗函数乘法（NEON优化）
                if (len > 0) {
                    // 需要将float输入转换为Q15进行处理
                    std::vector<int16_t> input_q15(len);
                    for (int i = 0; i < len; ++i) {
                        input_q15[i] = FloatToQ15(input[ch][frame_start + i]);
                    }
                    neon_mul_window_q15(input_q15.data(), window_q15_.data(), temp_frame_.data(), len);
                }
            #elif IVA_HAS_NEON
                // 浮点窗函数乘法（NEON优化）
                if (len > 0) {
                    neon_mul_window(input[ch].data() + frame_start, window_.data(), temp_frame_.data(), len);
                }
            #elif defined(IVA_OPT_C6_STFT_Q15) && IVA_OPT_C6_STFT_Q15
                // Q15定点窗函数乘法（标量）
                for (int i = 0; i < len; ++i) {
                    Q15 input_q15 = FloatToQ15(input[ch][frame_start + i]);
                    Q15 result_q15 = MulQ15(input_q15, window_q15_[i]);
                    temp_frame_[i] = Q15ToFloat(result_q15);
                }
            #else
                // 浮点窗函数乘法（标量）
                for (int i = 0; i < len; ++i) {
                    temp_frame_[i] = input[ch][frame_start + i] * window_[i];
                }
            #endif
            }
            
            // Perform FFT
            std::vector<Complex> freq_frame(freq_bins_);
            PerformFFT(temp_frame_, freq_frame);
            
            // Store in output tensor
            for (int f = 0; f < freq_bins_; f++) {
                output[f][frame][ch] = freq_frame[f];
            }
        }
    }
    
    return 0;
}

int STFTProcessor::Inverse(const ComplexTensor& input, std::vector<std::vector<float>>& output) {
    if (!initialized_) {
        ALG_LOGE("STFT processor not initialized");
        return -1;
    }
    
    if (input.empty() || input[0].empty() || input[0][0].empty()) {
        ALG_LOGE("Empty input");
        return -1;
    }
    
    int freq_bins = input.size();
    int time_frames = input[0].size();
    int num_channels = input[0][0].size();
    
    if (freq_bins != freq_bins_) {
        ALG_LOGE("Frequency bins mismatch: expected %d, got %d", freq_bins_, freq_bins);
        return -1;
    }
    
    // Calculate output length
    int output_length = (time_frames - 1) * config_.hop_size + config_.fft_size;

    // Resize output and overlap buffers
    output.resize(num_channels);
    overlap_buffer_.resize(num_channels);
    for (int ch = 0; ch < num_channels; ch++) {
        output[ch].resize(output_length, 0.0f);
        overlap_buffer_[ch].resize(output_length, 0.0f);
    }
    
    // Process each channel
    for (int ch = 0; ch < num_channels; ch++) {
        for (int frame = 0; frame < time_frames; frame++) {
            // Extract frequency frame
            std::vector<Complex> freq_frame(freq_bins_);
            for (int f = 0; f < freq_bins_; f++) {
                freq_frame[f] = input[f][frame][ch];
            }
            
            // Perform IFFT
            std::vector<float> time_frame(config_.fft_size);
            PerformIFFT(freq_frame, time_frame);
            
            // Apply synthesis window and overlap-add
            {
                int len = config_.window_size;
            #if defined(IVA_OPT_C6_STFT_Q15) && IVA_OPT_C6_STFT_Q15 && IVA_HAS_NEON
                // Q15定点合成窗函数（NEON优化）
                neon_mul_inplace_q15(time_frame.data(), synthesis_window_q15_.data(), len);
            #elif IVA_HAS_NEON
                // 浮点合成窗函数（NEON优化）
                neon_mul_inplace(time_frame.data(), synthesis_window_.data(), len);
            #elif defined(IVA_OPT_C6_STFT_Q15) && IVA_OPT_C6_STFT_Q15
                // Q15定点合成窗函数（标量）
                for (int i = 0; i < len; ++i) {
                    Q15 data_q15 = FloatToQ15(time_frame[i]);
                    Q15 result_q15 = MulQ15(data_q15, synthesis_window_q15_[i]);
                    time_frame[i] = Q15ToFloat(result_q15);
                }
            #else
                // 浮点合成窗函数（标量）
                for (int i = 0; i < len; ++i) {
                    time_frame[i] *= synthesis_window_[i];
                }
            #endif
            }

            int frame_start = frame * config_.hop_size;
            {
                int len = std::min((int)time_frame.size(), (int)output[ch].size() - frame_start);
            #if IVA_HAS_NEON
                if (len > 0) neon_overlap_add(output[ch].data() + frame_start, time_frame.data(), len);
            #else
                for (int i = 0; i < len; ++i) {
                    output[ch][frame_start + i] += time_frame[i];
                }
            #endif
            }
        }
    }

    return 0;
}

void STFTProcessor::PerformFFT(const std::vector<float>& input, std::vector<Complex>& output) {
    // Convert to complex
    for (int i = 0; i < config_.fft_size; i++) {
        if (i < static_cast<int>(input.size())) {
            fft_buffer_[i] = Complex(input[i], 0.0f);
        } else {
            fft_buffer_[i] = Complex(0.0f, 0.0f);
        }
    }

    // Perform FFT using iMedia FFT adapter
    std::vector<Complex> fft_output(config_.fft_size);
    iva_fft_forward(fft_buffer_.data(), fft_output.data(), config_.fft_size);

    // Extract positive frequencies only
    output.resize(freq_bins_);
    for (int i = 0; i < freq_bins_; i++) {
        output[i] = fft_output[i];
    }
}

void STFTProcessor::PerformIFFT(const std::vector<Complex>& input, std::vector<float>& output) {
    // Reconstruct full spectrum (conjugate symmetry)
    std::vector<Complex> full_spectrum(config_.fft_size);

    for (int i = 0; i < freq_bins_; i++) {
        full_spectrum[i] = input[i];
    }

    for (int i = freq_bins_; i < config_.fft_size; i++) {
        int mirror_idx = config_.fft_size - i;
        if (mirror_idx > 0 && mirror_idx < freq_bins_) {
            full_spectrum[i] = std::conj(input[mirror_idx]);
        } else {
            full_spectrum[i] = Complex(0.0f, 0.0f);
        }
    }

    // Perform IFFT
    std::vector<Complex> ifft_output(config_.fft_size);
    iva_fft_inverse(full_spectrum.data(), ifft_output.data(), config_.fft_size);

    // Extract real part (scaling already applied in FFT adapter)
    output.resize(config_.fft_size);
    for (int i = 0; i < config_.fft_size; i++) {
        output[i] = ifft_output[i].real(); 
    }
}

void STFTProcessor::OverlapAdd(const std::vector<float>& frame, std::vector<float>& output, int frame_start) {
    for (int i = 0; i < static_cast<int>(frame.size()) && (frame_start + i) < static_cast<int>(output.size()); i++) {
        output[frame_start + i] += frame[i];
    }
}

void STFTProcessor::Cleanup() {
    if (initialized_) {
        iva_fft_destroy();
        window_.clear();
        synthesis_window_.clear();
        fft_buffer_.clear();
        temp_frame_.clear();
        overlap_buffer_.clear();
        initialized_ = false;
    }
}

} // namespace kws2k2_faith
