/**
 * @file fixedpoint.h
 * @brief 定点算术工具库，支持Q31/Q15格式和块浮点(BFP)管理
 *
 * 本文件提供IVA定点量化所需的基础算子，包括：
 * - Q31/Q15定点算术运算（加法、乘法、复数运算）
 * - 饱和与舍入原语
 * - 块浮点(BFP)指数管理
 * - 溢出检测与统计
 */

#ifndef FIXEDPOINT_H
#define FIXEDPOINT_H

#include <cstdint>
#include <complex>
#include <vector>

namespace kws2k2_faith {

// ============================================================================
// 基础定点类型定义
// ============================================================================

/// @brief Q31定点数：32位有符号整数，31位小数
using Q31 = int32_t;

/// @brief Q15定点数：16位有符号整数，15位小数  
using Q15 = int16_t;

/// @brief Q31复数
struct ComplexQ31 {
    Q31 real;
    Q31 imag;
    
    ComplexQ31() : real(0), imag(0) {}
    ComplexQ31(Q31 r, Q31 i) : real(r), imag(i) {}
};

/// @brief Q15复数
struct ComplexQ15 {
    Q15 real;
    Q15 imag;
    
    ComplexQ15() : real(0), imag(0) {}
    ComplexQ15(Q15 r, Q15 i) : real(r), imag(i) {}
};

// ============================================================================
// 基础算术原语
// ============================================================================

/**
 * @brief 64位到32位的饱和转换
 * @param x 64位输入值
 * @return 饱和后的32位值
 */
inline Q31 Saturate64To32(int64_t x) {
    if (x > INT32_MAX) return INT32_MAX;
    if (x < INT32_MIN) return INT32_MIN;
    return static_cast<Q31>(x);
}

/**
 * @brief 32位到16位的饱和转换
 * @param x 32位输入值
 * @return 饱和后的16位值
 */
inline Q15 Saturate32To16(int32_t x) {
    if (x > INT16_MAX) return INT16_MAX;
    if (x < INT16_MIN) return INT16_MIN;
    return static_cast<Q15>(x);
}

/**
 * @brief 带舍入的右移
 * @param x 输入值
 * @param bits 右移位数
 * @return 舍入后的结果
 */
inline Q31 RoundingShiftRight(int64_t x, int bits) {
    if (bits <= 0) return Saturate64To32(x);
    const int64_t bias = static_cast<int64_t>(1) << (bits - 1);
    return Saturate64To32((x + bias) >> bits);
}

/**
 * @brief Q31乘法（结果右移31位）
 * @param a Q31输入
 * @param b Q31输入  
 * @return Q31结果
 */
inline Q31 MulQ31(Q31 a, Q31 b) {
    int64_t result = static_cast<int64_t>(a) * static_cast<int64_t>(b);
    return RoundingShiftRight(result, 31);
}

/**
 * @brief Q15乘法（结果右移15位）
 * @param a Q15输入
 * @param b Q15输入
 * @return Q15结果
 */
inline Q15 MulQ15(Q15 a, Q15 b) {
    int32_t result = static_cast<int32_t>(a) * static_cast<int32_t>(b);
    return Saturate32To16((result + (1 << 14)) >> 15);  // 舍入
}

// ============================================================================
// 复数运算
// ============================================================================

/**
 * @brief Q31复数乘法：(a+bi) * (c+di) = (ac-bd) + (ad+bc)i
 * @param a 第一个复数
 * @param b 第二个复数
 * @return 乘法结果
 */
inline ComplexQ31 MulComplexQ31(const ComplexQ31& a, const ComplexQ31& b) {
    // 使用64位中间结果避免溢出
    int64_t ac = static_cast<int64_t>(a.real) * static_cast<int64_t>(b.real);
    int64_t bd = static_cast<int64_t>(a.imag) * static_cast<int64_t>(b.imag);
    int64_t ad = static_cast<int64_t>(a.real) * static_cast<int64_t>(b.imag);
    int64_t bc = static_cast<int64_t>(a.imag) * static_cast<int64_t>(b.real);
    
    return ComplexQ31(
        RoundingShiftRight(ac - bd, 31),
        RoundingShiftRight(ad + bc, 31)
    );
}

/**
 * @brief Q31复数乘累加：acc += a * b
 * @param a 第一个复数
 * @param b 第二个复数
 * @param acc_real 实部累加器（64位）
 * @param acc_imag 虚部累加器（64位）
 */
inline void MulAccComplexQ31(const ComplexQ31& a, const ComplexQ31& b, 
                            int64_t& acc_real, int64_t& acc_imag) {
    int64_t ac = static_cast<int64_t>(a.real) * static_cast<int64_t>(b.real);
    int64_t bd = static_cast<int64_t>(a.imag) * static_cast<int64_t>(b.imag);
    int64_t ad = static_cast<int64_t>(a.real) * static_cast<int64_t>(b.imag);
    int64_t bc = static_cast<int64_t>(a.imag) * static_cast<int64_t>(b.real);
    
    acc_real += (ac - bd);  // Q62格式
    acc_imag += (ad + bc);  // Q62格式
}

/**
 * @brief Q31复数共轭
 * @param a 输入复数
 * @return 共轭复数
 */
inline ComplexQ31 ConjComplexQ31(const ComplexQ31& a) {
    return ComplexQ31(a.real, -a.imag);
}

// ============================================================================
// 浮点与定点转换
// ============================================================================

/**
 * @brief 浮点转Q31
 * @param f 浮点输入
 * @param exponent 指数（用于BFP）
 * @return Q31结果
 */
inline Q31 FloatToQ31(float f, int exponent = 0) {
    double scaled = static_cast<double>(f) * (static_cast<double>(1LL << (31 - exponent)));
    if (scaled > INT32_MAX) return INT32_MAX;
    if (scaled < INT32_MIN) return INT32_MIN;
    return static_cast<Q31>(scaled);
}

/**
 * @brief Q31转浮点
 * @param q Q31输入
 * @param exponent 指数（用于BFP）
 * @return 浮点结果
 */
inline float Q31ToFloat(Q31 q, int exponent = 0) {
    return static_cast<float>(q) / static_cast<float>(1LL << (31 - exponent));
}

/**
 * @brief 浮点转Q15
 * @param f 浮点输入
 * @return Q15结果
 */
inline Q15 FloatToQ15(float f) {
    double scaled = static_cast<double>(f) * 32768.0;  // 2^15
    if (scaled > INT16_MAX) return INT16_MAX;
    if (scaled < INT16_MIN) return INT16_MIN;
    return static_cast<Q15>(scaled);
}

/**
 * @brief Q15转浮点
 * @param q Q15输入
 * @return 浮点结果
 */
inline float Q15ToFloat(Q15 q) {
    return static_cast<float>(q) / 32768.0f;  // 2^15
}

/**
 * @brief 复数浮点转Q31
 * @param c 浮点复数
 * @param exponent 指数
 * @return Q31复数
 */
inline ComplexQ31 ComplexFloatToQ31(const std::complex<float>& c, int exponent = 0) {
    return ComplexQ31(
        FloatToQ31(c.real(), exponent),
        FloatToQ31(c.imag(), exponent)
    );
}

/**
 * @brief Q31复数转浮点
 * @param c Q31复数
 * @param exponent 指数
 * @return 浮点复数
 */
inline std::complex<float> ComplexQ31ToFloat(const ComplexQ31& c, int exponent = 0) {
    return std::complex<float>(
        Q31ToFloat(c.real, exponent),
        Q31ToFloat(c.imag, exponent)
    );
}

// ============================================================================
// 块浮点(BFP)指数管理
// ============================================================================

/**
 * @brief BFP指数管理器
 */
class BFPManager {
public:
    /**
     * @brief 初始化BFP管理器
     * @param freq_bins 频率箱数量
     * @param headroom_db 预留余量（dB）
     */
    void Initialize(int freq_bins, double headroom_db = 12.0);
    
    /**
     * @brief 获取频点的当前指数
     * @param freq_bin 频率箱索引
     * @return 指数值
     */
    int GetExponent(int freq_bin) const;
    
    /**
     * @brief 更新频点指数
     * @param freq_bin 频率箱索引
     * @param new_exponent 新指数
     */
    void SetExponent(int freq_bin, int new_exponent);
    
    /**
     * @brief 根据信号幅值自动调整指数
     * @param freq_bin 频率箱索引
     * @param max_magnitude 最大幅值
     */
    void AutoAdjustExponent(int freq_bin, float max_magnitude);
    
    /**
     * @brief 重置所有指数
     */
    void Reset();

private:
    std::vector<int> exponents_;
    double headroom_db_;
    int default_exponent_;
};

// ============================================================================
// 溢出统计
// ============================================================================

/**
 * @brief 溢出统计器
 */
class OverflowCounter {
public:
    static OverflowCounter& Instance();
    
    void IncrementSaturation() { saturation_count_++; }
    void IncrementOverflow() { overflow_count_++; }
    
    uint64_t GetSaturationCount() const { return saturation_count_; }
    uint64_t GetOverflowCount() const { return overflow_count_; }
    
    void Reset() { saturation_count_ = 0; overflow_count_ = 0; }

private:
    uint64_t saturation_count_ = 0;
    uint64_t overflow_count_ = 0;
};

} // namespace kws2k2_faith

#endif // FIXEDPOINT_H
