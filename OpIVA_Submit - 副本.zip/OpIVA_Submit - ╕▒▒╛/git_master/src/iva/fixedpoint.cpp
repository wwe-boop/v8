/**
 * @file fixedpoint.cpp
 * @brief 定点算术工具库的实现
 */

#include "fixedpoint.h"
#include "../alg_log.h"
#include <cmath>
#include <algorithm>

namespace kws2k2_faith {

// ============================================================================
// BFP指数管理器实现
// ============================================================================

void BFPManager::Initialize(int freq_bins, double headroom_db) {
    exponents_.resize(freq_bins);
    headroom_db_ = headroom_db;
    
    // 计算默认指数：为headroom_db预留空间
    // headroom_db = 20*log10(2^bits) => bits = headroom_db / (20*log10(2))
    double headroom_bits = headroom_db / (20.0 * std::log10(2.0));
    default_exponent_ = static_cast<int>(std::ceil(headroom_bits));
    
    // 确保默认指数在合理范围内
    default_exponent_ = std::max(0, std::min(default_exponent_, 20));
    
    Reset();
    
    ALG_LOGI("BFP Manager initialized: freq_bins=%d, headroom=%.1fdB, default_exp=%d", 
             freq_bins, headroom_db, default_exponent_);
}

int BFPManager::GetExponent(int freq_bin) const {
    if (freq_bin < 0 || freq_bin >= static_cast<int>(exponents_.size())) {
        return default_exponent_;
    }
    return exponents_[freq_bin];
}

void BFPManager::SetExponent(int freq_bin, int new_exponent) {
    if (freq_bin >= 0 && freq_bin < static_cast<int>(exponents_.size())) {
        exponents_[freq_bin] = std::max(0, std::min(new_exponent, 30));
    }
}

void BFPManager::AutoAdjustExponent(int freq_bin, float max_magnitude) {
    if (freq_bin < 0 || freq_bin >= static_cast<int>(exponents_.size())) {
        return;
    }
    
    if (max_magnitude <= 0.0f) {
        return;  // 保持当前指数
    }
    
    // 计算需要的指数以容纳max_magnitude + headroom
    double magnitude_db = 20.0 * std::log10(static_cast<double>(max_magnitude));
    double required_db = magnitude_db + headroom_db_;
    double required_bits = required_db / (20.0 * std::log10(2.0));
    
    int new_exponent = static_cast<int>(std::ceil(required_bits));
    new_exponent = std::max(0, std::min(new_exponent, 30));
    
    // 只在需要更大指数时更新（避免频繁缩放）
    if (new_exponent > exponents_[freq_bin]) {
        exponents_[freq_bin] = new_exponent;
    }
}

void BFPManager::Reset() {
    std::fill(exponents_.begin(), exponents_.end(), default_exponent_);
}

// ============================================================================
// 溢出统计器实现
// ============================================================================

OverflowCounter& OverflowCounter::Instance() {
    static OverflowCounter instance;
    return instance;
}

// ============================================================================
// 高级定点运算函数
// ============================================================================

/**
 * @brief 计算Q31复数的模长平方
 * @param c Q31复数
 * @return 模长平方（Q31格式）
 */
Q31 MagnitudeSquaredQ31(const ComplexQ31& c) {
    // |c|^2 = real^2 + imag^2
    int64_t real_sq = static_cast<int64_t>(c.real) * static_cast<int64_t>(c.real);
    int64_t imag_sq = static_cast<int64_t>(c.imag) * static_cast<int64_t>(c.imag);
    
    // 结果是Q62，右移31位得到Q31
    return RoundingShiftRight(real_sq + imag_sq, 31);
}

/**
 * @brief Q31除法近似（使用牛顿迭代）
 * @param numerator 分子
 * @param denominator 分母
 * @param iterations 迭代次数（默认2次）
 * @return 除法结果
 */
Q31 DivQ31Approx(Q31 numerator, Q31 denominator, int iterations = 2) {
    if (denominator == 0) {
        OverflowCounter::Instance().IncrementOverflow();
        return (numerator >= 0) ? INT32_MAX : INT32_MIN;
    }
    
    // 简单情况：如果分母接近1.0（Q31格式下接近2^31）
    if (std::abs(denominator - (1LL << 30)) < (1LL << 28)) {
        // denominator ≈ 0.5，所以 1/denominator ≈ 2
        return Saturate64To32(static_cast<int64_t>(numerator) * 2);
    }
    
    // 对于一般情况，使用浮点除法（在定点优化的早期阶段）
    // TODO: 后续可以实现纯定点的牛顿迭代除法
    float num_f = Q31ToFloat(numerator);
    float den_f = Q31ToFloat(denominator);
    float result_f = num_f / den_f;
    
    return FloatToQ31(result_f);
}

/**
 * @brief 向量的Q31点积
 * @param a 第一个向量
 * @param b 第二个向量
 * @return 点积结果
 */
ComplexQ31 DotProductQ31(const std::vector<ComplexQ31>& a, const std::vector<ComplexQ31>& b) {
    if (a.size() != b.size()) {
        return ComplexQ31(0, 0);
    }
    
    int64_t acc_real = 0;
    int64_t acc_imag = 0;
    
    for (size_t i = 0; i < a.size(); ++i) {
        // a[i] * conj(b[i])
        ComplexQ31 b_conj = ConjComplexQ31(b[i]);
        MulAccComplexQ31(a[i], b_conj, acc_real, acc_imag);
    }
    
    return ComplexQ31(
        RoundingShiftRight(acc_real, 31),
        RoundingShiftRight(acc_imag, 31)
    );
}

/**
 * @brief 2x2复数矩阵乘法（Q31）
 * @param A 第一个矩阵 [2][2]
 * @param B 第二个矩阵 [2][2]  
 * @param C 结果矩阵 [2][2]
 */
void MatMul2x2Q31(const ComplexQ31 A[2][2], const ComplexQ31 B[2][2], ComplexQ31 C[2][2]) {
    for (int i = 0; i < 2; ++i) {
        for (int j = 0; j < 2; ++j) {
            int64_t acc_real = 0;
            int64_t acc_imag = 0;
            
            for (int k = 0; k < 2; ++k) {
                MulAccComplexQ31(A[i][k], B[k][j], acc_real, acc_imag);
            }
            
            C[i][j] = ComplexQ31(
                RoundingShiftRight(acc_real, 31),
                RoundingShiftRight(acc_imag, 31)
            );
        }
    }
}

/**
 * @brief 检查Q31值是否接近饱和
 * @param value Q31值
 * @param threshold 阈值（默认90%）
 * @return 是否接近饱和
 */
bool IsNearSaturationQ31(Q31 value, float threshold = 0.9f) {
    Q31 abs_value = (value >= 0) ? value : -value;
    // Use double precision to avoid float rounding of INT32_MAX to 2,147,483,648
    int64_t limit64 = static_cast<int64_t>(std::llround(static_cast<double>(INT32_MAX) * static_cast<double>(threshold)));
    if (limit64 > INT32_MAX) limit64 = INT32_MAX;
    Q31 limit = static_cast<Q31>(limit64);
    return abs_value > limit;
}

/**
 * @brief 批量转换浮点复数数组到Q31
 * @param input 浮点复数数组
 * @param output Q31复数数组
 * @param size 数组大小
 * @param exponent BFP指数
 */
void ConvertArrayFloatToQ31(const std::complex<float>* input, ComplexQ31* output, 
                           int size, int exponent) {
    for (int i = 0; i < size; ++i) {
        output[i] = ComplexFloatToQ31(input[i], exponent);
    }
}

/**
 * @brief 批量转换Q31复数数组到浮点
 * @param input Q31复数数组
 * @param output 浮点复数数组
 * @param size 数组大小
 * @param exponent BFP指数
 */
void ConvertArrayQ31ToFloat(const ComplexQ31* input, std::complex<float>* output,
                           int size, int exponent) {
    for (int i = 0; i < size; ++i) {
        output[i] = ComplexQ31ToFloat(input[i], exponent);
    }
}

} // namespace kws2k2_faith
