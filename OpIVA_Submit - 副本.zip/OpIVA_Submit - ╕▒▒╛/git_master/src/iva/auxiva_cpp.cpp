
#include "auxiva_cpp.h"
#include "../imedia_common_basic_op.h"
#include "../alg_log.h"
#include <cmath>
#include <algorithm>
#include <random>


// NEON acceleration for complex arithmetic (optional)
#if defined(IVA_OPT_C2_NEON) && IVA_OPT_C2_NEON && defined(__aarch64__)
  #include <arm_neon.h>
  #define AUXIVA_HAS_NEON 1
#else
  #define AUXIVA_HAS_NEON 0
#endif

namespace kws2k2_faith {

// Logging suppression controls 
#ifndef IVA_LOG_SUPPRESS_NOISY
#define IVA_LOG_SUPPRESS_NOISY 1
#endif
#ifndef IVA_LOG_SUPPRESS_NEAR_SINGULAR_INVERSE
#define IVA_LOG_SUPPRESS_NEAR_SINGULAR_INVERSE IVA_LOG_SUPPRESS_NOISY
#endif

/**
 * @brief 初始化AuxIVA处理器
 *
 * 验证配置参数，分配内存缓冲区，初始化解混矩阵为单位矩阵
 */
int AuxIVAProcessor::Initialize(const AuxIVAConfig& config) {
    config_ = config;

    // 验证配置参数
    if (config_.num_sources <= 0 || config_.num_channels <= 0 ||
        config_.freq_bins <= 0) {
        ALG_LOGE("Invalid AuxIVA configuration: sources=%d, channels=%d, freq_bins=%d",
                 config_.num_sources, config_.num_channels, config_.freq_bins);
        return -1;
    }

    // 允许初始化时时间帧为零(将在处理过程中设置)
    if (config_.time_frames < 0) {
        ALG_LOGE("Invalid time frames: %d", config_.time_frames);
        return -1;
    }

    if (config_.num_sources > config_.num_channels) {
        ALG_LOGE("Number of sources (%d) cannot exceed number of channels (%d)",
                 config_.num_sources, config_.num_channels);
        return -1;
    }

    // 分配解混矩阵 [频率][源][通道]
    demixing_matrices_.resize(config_.freq_bins);
    for (int f = 0; f < config_.freq_bins; f++) {
        demixing_matrices_[f].resize(config_.num_sources);
        for (int s = 0; s < config_.num_sources; s++) {
            demixing_matrices_[f][s].resize(config_.num_channels);
        }
    }

    // 分配工作缓冲区
    temp_matrix_.resize(config_.num_channels);
    for (int i = 0; i < config_.num_channels; i++) {
        temp_matrix_[i].resize(config_.num_channels);
    }

    source_powers_.resize(config_.num_sources);
    source_models_.resize(config_.num_sources);
    for (int s = 0; s < config_.num_sources; s++) {
        source_models_[s].resize(config_.time_frames);
    }

#if defined(IVA_OPT_C6_FIXEDPOINT) && IVA_OPT_C6_FIXEDPOINT
    // 初始化定点量化相关缓冲区
    bfp_manager_.Initialize(config_.freq_bins, 12.0);  // 12dB headroom

    // 分配Q31解混矩阵
    demixing_matrices_q31_.resize(config_.freq_bins);
    for (int f = 0; f < config_.freq_bins; f++) {
        demixing_matrices_q31_[f].resize(config_.num_sources);
        for (int s = 0; s < config_.num_sources; s++) {
            demixing_matrices_q31_[f][s].resize(config_.num_channels);
        }
    }

    // 分配Q31工作缓冲区
    temp_matrix_q31_.resize(config_.num_channels);
    for (int i = 0; i < config_.num_channels; i++) {
        temp_matrix_q31_[i].resize(config_.num_channels);
    }

    input_freq_q31_.resize(config_.time_frames);
    for (int t = 0; t < config_.time_frames; t++) {
        input_freq_q31_[t].resize(config_.num_channels);
    }

    output_freq_q31_.resize(config_.time_frames);
    for (int t = 0; t < config_.time_frames; t++) {
        output_freq_q31_[t].resize(config_.num_sources);
    }

    ALG_LOGI("AuxIVA Q31 fixedpoint mode enabled");
#endif

    InitializeDemixingMatrices();

    initialized_ = true;
    ALG_LOGI("AuxIVA processor initialized: %d sources, %d channels, %d freq bins",
             config_.num_sources, config_.num_channels, config_.freq_bins);

    return 0;
}

/**
 * @brief 初始化解混矩阵为单位矩阵
 *
 * 将所有频率箱的解混矩阵初始化为单位矩阵，提供算法迭代的中性起点
 */
void AuxIVAProcessor::InitializeDemixingMatrices() {
    // 将解混矩阵W初始化为单位矩阵
    for (int i = 0; i < config_.freq_bins; i++) {
        for (int n = 0; n < config_.num_sources; n++) {
            for (int m = 0; m < config_.num_channels; m++) {
                Complex val = (n == m) ? Complex(1.0f, 0.0f) : Complex(0.0f, 0.0f);
                demixing_matrices_[i][n][m] = val;

#if defined(IVA_OPT_C6_FIXEDPOINT) && IVA_OPT_C6_FIXEDPOINT
                // 同时初始化Q31解混矩阵
                int exp = bfp_manager_.GetExponent(i);
                ComplexQ31 val_q31 = (n == m) ?
                    ComplexQ31(FloatToQ31(1.0f, exp), 0) : ComplexQ31(0, 0);
                demixing_matrices_q31_[i][n][m] = val_q31;
#endif
            }
        }
    }
}

/**
 * @brief 执行AuxIVA盲源分离处理
 *
 * 对输入的频域多通道信号执行完整的AuxIVA算法，包括迭代更新解混矩阵、
 * 源模型估计、归一化处理和反投影校正
 */
int AuxIVAProcessor::Process(const ComplexTensor& input, ComplexTensor& output) {
    if (!initialized_) {
        ALG_LOGE("AuxIVA processor not initialized");
        return -1;
    }

    // 验证输入维度
    if (input.size() != static_cast<size_t>(config_.freq_bins) ||
        input[0].size() != static_cast<size_t>(config_.time_frames) ||
        input[0][0].size() != static_cast<size_t>(config_.num_channels)) {
        ALG_LOGE("Invalid input dimensions");
        return -1;
    }

    // 调整输出大小
    output.resize(config_.freq_bins);
    for (int f = 0; f < config_.freq_bins; f++) {
        output[f].resize(config_.time_frames);
        for (int t = 0; t < config_.time_frames; t++) {
            output[f][t].resize(config_.num_sources);
        }
    }

#if defined(IVA_OPT_C6_FIXEDPOINT) && IVA_OPT_C6_FIXEDPOINT
    // 定点路径：使用Q31算法
    return ProcessFixedPoint(input, output);
#else
    // 浮点路径：使用原始算法
    return ProcessFloatingPoint(input, output);
#endif
}

/**
 * @brief 浮点版本的Process（原始实现）
 */
int AuxIVAProcessor::ProcessFloatingPoint(const ComplexTensor& input, ComplexTensor& output) {

#ifdef IVA_OPT_B4
    // 构建Gram缓存（每次Process开始只构建一次）
    if (!gram_cache_valid_ ||
        gram_cache_time_frames_ != config_.time_frames ||
        gram_cache_channels_ != config_.num_channels) {
        BuildGramCache(input);
    }
#endif

    // 初始化：计算初始分离源和源模型
    ApplyDemixing(input, output);
    UpdateSourceModels(output);

    // 保存前一次迭代的解混矩阵用于收敛检查
    ComplexTensor prev_demixing_matrices;

    // 主迭代循环
    for (int iter = 0; iter < config_.max_iterations; iter++) {
        // 保存当前解混矩阵用于收敛检查
        if (iter > 0) {  // 从第二次迭代开始检查收敛
            prev_demixing_matrices = demixing_matrices_;
        }

        // 步骤1: 更新源模型 R
        UpdateSourceModels(output);

        // 步骤2: 按频率bin更新解混矩阵
        for (int f = 0; f < config_.freq_bins; f++) {
            for (int s = 0; s < config_.num_sources; s++) {
                // 为每个频率和源更新解混向量
                UpdateDemixingMatrixFreqSource(f, s, input[f]);
            }
        }

        // 步骤3: 应用解混矩阵得到新的分离源
        ApplyDemixing(input, output);

        // 步骤4: 归一化处理
        if (config_.normalize_demixing) {
            NormalizeDemixingMatrices();
            // 归一化后重新计算分离源
            ApplyDemixing(input, output);
        }

        // 步骤5: 收敛性检查
        if (config_.use_convergence_check && iter > 0 && CheckConvergence(prev_demixing_matrices, config_.convergence_threshold)) {
            ALG_LOGI("AuxIVA converged after %d iterations", iter + 1);
            break;
        }
    }

    // Apply demixing to get separated sources
    ComplexTensor temp_separated;
    temp_separated.resize(config_.freq_bins);
    for (int f = 0; f < config_.freq_bins; f++) {
        temp_separated[f].resize(config_.time_frames);
        for (int t = 0; t < config_.time_frames; t++) {
            temp_separated[f][t].resize(config_.num_sources);
        }
    }

    ApplyDemixing(input, temp_separated);

    // Apply back projection for amplitude correction
    ApplyBackProjection(temp_separated, input, 0, output);

    return 0;
}

#if defined(IVA_OPT_C6_FIXEDPOINT) && IVA_OPT_C6_FIXEDPOINT
/**
 * @brief 定点版本的Process函数 - 核心矩阵运算定点化
 */
int AuxIVAProcessor::ProcessFixedPoint(const ComplexTensor& input, ComplexTensor& output) {
    ALG_LOGI("AuxIVA Q31 fixedpoint mode: implementing core matrix operations");

    // 使用浮点版本的主要算法流程，但在关键矩阵运算处使用定点
    ComplexTensor prev_demixing = demixing_matrices_;

    // 初始化：计算初始分离源和源模型（沿用浮点路径的统计）
    ApplyDemixing(input, output);
    UpdateSourceModels(output);

    for (int iter = 0; iter < config_.max_iterations; iter++) {
        // 与浮点路径保持一致：每次迭代基于上一次分离结果更新源模型
        UpdateSourceModels(output);
        for (int f = 0; f < config_.freq_bins; f++) {
            // 转换当前频率的数据到Q31进行矩阵运算
            int exp = bfp_manager_.GetExponent(f);

            // 转换输入数据到Q31
            for (int t = 0; t < config_.time_frames; t++) {
                for (int c = 0; c < config_.num_channels; c++) {
                    input_freq_q31_[t][c] = ComplexFloatToQ31(input[f][t][c], exp);
                }
            }

            // 转换解混矩阵到Q31
            for (int s = 0; s < config_.num_sources; s++) {
                for (int c = 0; c < config_.num_channels; c++) {
                    demixing_matrices_q31_[f][s][c] = ComplexFloatToQ31(demixing_matrices_[f][s][c], exp);
                }
            }

            // 使用Q31定点进行解混矩阵应用
            ApplyDemixingQ31(f);

            // 对每个源更新解混向量（使用定点协方差计算）
            for (int s = 0; s < config_.num_sources; s++) {
                ComputeCovarianceMatrixQ31(f, s);

                // 将Q31协方差矩阵转换到浮点 temp_matrix_，供现有求解器使用
                int shift_bits = 0; int frames_tmp = config_.time_frames; while (frames_tmp > 1) { frames_tmp >>= 1; shift_bits++; }
                float scale_correction = static_cast<float>(1u << shift_bits) / static_cast<float>(config_.time_frames);
                for (int i = 0; i < config_.num_channels; i++) {
                    for (int j = 0; j < config_.num_channels; j++) {
                        float r = Q31ToFloat(temp_matrix_q31_[i][j].real, 2 * exp);
                        float im = Q31ToFloat(temp_matrix_q31_[i][j].imag, 2 * exp);
                        temp_matrix_[i][j] = Complex(r * scale_correction, im * scale_correction);
                    }
                }
                // 基于当前频点的解混矩阵，调用现有浮点求解器
                {
                    ComplexMatrix W_freq(config_.num_sources, std::vector<Complex>(config_.num_channels));
                    for (int ss = 0; ss < config_.num_sources; ss++) {
                        for (int cc = 0; cc < config_.num_channels; cc++) {
                            W_freq[ss][cc] = demixing_matrices_[f][ss][cc];
                        }
                    }
                    std::vector<Complex> new_demixing_vector(config_.num_channels);
                    if (SolveDemixingVector(s, W_freq, new_demixing_vector)) {
                        for (int m = 0; m < config_.num_channels; m++) {
                            demixing_matrices_[f][s][m] = std::conj(new_demixing_vector[m]);
                        }
                    }
                }
            }

            // 此处不计算输出，避免在频点循环内重复全频计算
        }

       //归一化解混矩阵，与浮点路径保持一致
        if (config_.normalize_demixing) {
            NormalizeDemixingMatrices();
        }

        // 统一在每次迭代末计算新的分离源，供下一轮迭代的源模型更新
        ApplyDemixing(input, output);

        // 收敛检查
        if (CheckConvergence(prev_demixing, config_.convergence_threshold)) {
            ALG_LOGI("AuxIVA Q31 converged after %d iterations", iter + 1);
            break;
        }
        prev_demixing = demixing_matrices_;
    }

    // 应用反投影
    ComplexTensor temp_separated = output;
    ApplyBackProjection(temp_separated, input, 0, output);

    return 0;
}

/**
 * @brief Q31定点版本的解混应用
 */
void AuxIVAProcessor::ApplyDemixingQ31(int freq_bin) {
    for (int t = 0; t < config_.time_frames; t++) {
        for (int s = 0; s < config_.num_sources; s++) {
            int64_t acc_real = 0;
            int64_t acc_imag = 0;

            // y_s = sum_c W_s,c * x_c
            for (int c = 0; c < config_.num_channels; c++) {
                const ComplexQ31& w = demixing_matrices_q31_[freq_bin][s][c];
                const ComplexQ31& x = input_freq_q31_[t][c];
                MulAccComplexQ31(w, x, acc_real, acc_imag);
            }

            output_freq_q31_[t][s] = ComplexQ31(
                RoundingShiftRight(acc_real, 31),
                RoundingShiftRight(acc_imag, 31)
            );
        }
    }
}

/**
 * @brief Q31定点版本的协方差矩阵计算
 */
void AuxIVAProcessor::ComputeCovarianceMatrixQ31(int freq_bin, int source_idx) {
    // 使用Q31路径计算：D = (1/J) * sum_t ( (x_t x_t^H) * (1/r_t) )
    // 其中 1/r_t 先用浮点求逆再量化到Q31（阶段1简化方案）

    // 准备累加器（Q62累计）
    const int C = config_.num_channels;
    static thread_local std::vector<std::vector<int64_t>> acc_re, acc_im;
    if (acc_re.size() != static_cast<size_t>(C)) {
        acc_re.assign(C, std::vector<int64_t>(C, 0));
        acc_im.assign(C, std::vector<int64_t>(C, 0));
    } else {
        for (int i = 0; i < C; ++i) {
            std::fill(acc_re[i].begin(), acc_re[i].end(), 0);
            std::fill(acc_im[i].begin(), acc_im[i].end(), 0);
        }
    }

    // 计算近似的 log2(J) 以便后续右移近似除法，再用浮点微调
    int shift_bits = 0; int frames_tmp = config_.time_frames; while (frames_tmp > 1) { frames_tmp >>= 1; shift_bits++; }

    for (int t = 0; t < config_.time_frames; ++t) {
        // r_t 读取并做最小值保护
        double r_val = source_models_[source_idx][t];
        if (r_val < config_.eps) r_val = config_.eps;
        float inv_r_f = static_cast<float>(1.0 / r_val);
        Q31 inv_r_q31 = FloatToQ31(inv_r_f); // Q31

        for (int i = 0; i < C; ++i) {
            const ComplexQ31 x_i = input_freq_q31_[t][i];
            for (int j = 0; j < C; ++j) {
                const ComplexQ31 x_j_conj = ConjComplexQ31(input_freq_q31_[t][j]);
                // 先计算复数乘法到Q31
                const ComplexQ31 p_q31 = MulComplexQ31(x_i, x_j_conj); // Q31
                // 乘以 inv_r_q31 → Q62，并累加
                acc_re[i][j] += static_cast<int64_t>(p_q31.real) * static_cast<int64_t>(inv_r_q31);
                acc_im[i][j] += static_cast<int64_t>(p_q31.imag) * static_cast<int64_t>(inv_r_q31);
            }
        }
    }

    // 将累计值缩放回Q31，并做按 J 的近似归一（右移 shift_bits）
    for (int i = 0; i < C; ++i) {
        for (int j = 0; j < C; ++j) {
            // 先从Q62回到Q31
            Q31 re = RoundingShiftRight(acc_re[i][j], 31 + shift_bits);
            Q31 im = RoundingShiftRight(acc_im[i][j], 31 + shift_bits);
            temp_matrix_q31_[i][j].real = re;
            temp_matrix_q31_[i][j].imag = im;
        }
    }
}
#endif

/**
 * @brief 应用解混矩阵进行源分离（优化版本）
 *
 * 将学习到的解混矩阵应用于输入信号，计算分离后的源信号
 * y_s(f,t) = sum_c W_s,c(f) * x_c(f,t)
 */
void AuxIVAProcessor::ApplyDemixing(const ComplexTensor& input, ComplexTensor& output) {
    // 循环重排 f->s->t，预加载解混系数
    for (int f = 0; f < config_.freq_bins; f++) {
        for (int s = 0; s < config_.num_sources; s++) {
            if (config_.num_channels == 2) {
                // 预加载解混系数，避免在时间循环中重复访问
                const Complex w0 = demixing_matrices_[f][s][0];
                const Complex w1 = demixing_matrices_[f][s][1];

            #if AUXIVA_HAS_NEON
                // 多时间帧向量化处理
                const float w0_re = w0.real(), w0_im = w0.imag();
                const float w1_re = w1.real(), w1_im = w1.imag();

                // 预打包解混系数到NEON寄存器
                float32x4_t w01 = {w0_re, w0_im, w1_re, w1_im};
                float32x2_t w_lo = vget_low_f32(w01);   // [w0.re, w0.im]
                float32x2_t w_hi = vget_high_f32(w01);  // [w1.re, w1.im]

                // 批量处理时间帧
                int t = 0;
                const int time_batch = 4;
                const int time_batches = config_.time_frames / time_batch;

                // 处理完整的4时间帧批次
                for (int tb = 0; tb < time_batches; tb++, t += time_batch) {
                    // 加载4个时间帧的输入数据
                    float x0_re[4], x0_im[4], x1_re[4], x1_im[4];
                    for (int i = 0; i < time_batch; i++) {
                        x0_re[i] = input[f][t + i][0].real();
                        x0_im[i] = input[f][t + i][0].imag();
                        x1_re[i] = input[f][t + i][1].real();
                        x1_im[i] = input[f][t + i][1].imag();
                    }

                    // 向量化计算4个时间帧
                    float32x4_t x0_re_v = vld1q_f32(x0_re);
                    float32x4_t x0_im_v = vld1q_f32(x0_im);
                    float32x4_t x1_re_v = vld1q_f32(x1_re);
                    float32x4_t x1_im_v = vld1q_f32(x1_im);

                    // 复数乘法: (w0_re + j*w0_im) * (x0_re + j*x0_im)
                    // 实部: w0_re*x0_re - w0_im*x0_im
                    float32x4_t w0x0_real = vmlsq_n_f32(vmulq_n_f32(x0_re_v, w0_re), x0_im_v, w0_im);
                    // 虚部: w0_re*x0_im + w0_im*x0_re
                    float32x4_t w0x0_imag = vmlaq_n_f32(vmulq_n_f32(x0_im_v, w0_re), x0_re_v, w0_im);

                    // 复数乘法: (w1_re + j*w1_im) * (x1_re + j*x1_im)
                    float32x4_t w1x1_real = vmlsq_n_f32(vmulq_n_f32(x1_re_v, w1_re), x1_im_v, w1_im);
                    float32x4_t w1x1_imag = vmlaq_n_f32(vmulq_n_f32(x1_im_v, w1_re), x1_re_v, w1_im);

                    // 累加: y = w0*x0 + w1*x1
                    float32x4_t y_real = vaddq_f32(w0x0_real, w1x1_real);
                    float32x4_t y_imag = vaddq_f32(w0x0_imag, w1x1_imag);

                    // 存储结果
                    float y_re_arr[4], y_im_arr[4];
                    vst1q_f32(y_re_arr, y_real);
                    vst1q_f32(y_im_arr, y_imag);

                    for (int i = 0; i < time_batch; i++) {
                        output[f][t + i][s] = Complex(y_re_arr[i], y_im_arr[i]);
                    }
                }

                // 处理剩余的时间帧（标量方式）
                for (; t < config_.time_frames; t++) {
                    const Complex x0 = input[f][t][0];
                    const Complex x1 = input[f][t][1];
                    output[f][t][s] = w0 * x0 + w1 * x1;
                }

            #else
                // 标量版本：循环重排优化
                for (int t = 0; t < config_.time_frames; t++) {
                    const Complex x0 = input[f][t][0];
                    const Complex x1 = input[f][t][1];
                    output[f][t][s] = w0 * x0 + w1 * x1;
                }
            #endif
            } else {
                // 通用多通道情况：循环重排优化
                for (int t = 0; t < config_.time_frames; t++) {
                    output[f][t][s] = Complex(0.0f, 0.0f);
                    // y_s(f,t) = sum_c W_s,c(f) * x_c(f,t)
                    for (int c = 0; c < config_.num_channels; c++) {
                        output[f][t][s] += demixing_matrices_[f][s][c] * input[f][t][c];
                    }
                }
            }
        }
    }
}

void AuxIVAProcessor::ApplyBackProjection(const ComplexTensor& separated_sources,
                                        const ComplexTensor& original_input,
                                        int ref_mic_index,
                                        ComplexTensor& corrected_output) {

    // 参数有效性检查
    if (ref_mic_index < 0 || ref_mic_index >= config_.num_channels) {
        ALG_LOGE("Invalid reference microphone index: %d", ref_mic_index);
        // 回退到简单复制
        for (int f = 0; f < config_.freq_bins; f++) {
            for (int t = 0; t < config_.time_frames; t++) {
                for (int s = 0; s < config_.num_sources; s++) {
                    corrected_output[f][t][s] = separated_sources[f][t][s];
                }
            }
        }
        return;
    }

    // 对每个频率bin进行反向投影
    for (int f = 0; f < config_.freq_bins; f++) {
        // 步骤1: 计算 Yi*Yi' (M x M 矩阵)
        std::vector<std::vector<Complex>> YiYi(config_.num_sources,
                                              std::vector<Complex>(config_.num_sources));

        if (config_.num_sources == 2) {
            Complex s00(0.0f, 0.0f), s01(0.0f, 0.0f), s11(0.0f, 0.0f);
            for (int t = 0; t < config_.time_frames; t++) {
                const Complex y0 = separated_sources[f][t][0];
                const Complex y1 = separated_sources[f][t][1];
            #if AUXIVA_HAS_NEON
                float32x4_t y01 = {y0.real(), y0.imag(), y1.real(), y1.imag()};
                float32x4_t cy01 = {y0.real(), -y0.imag(), y1.real(), -y1.imag()};
                float32x2_t y0v = vget_low_f32(y01);
                float32x2_t y1v = vget_high_f32(y01);
                float32x2_t cy0v = vget_low_f32(cy01);
                float32x2_t cy1v = vget_high_f32(cy01);
                // y0*conj(y0)
                float32x2_t acbd0 = vmul_f32(y0v, cy0v);
                float r00 = vget_lane_f32(acbd0, 0) - vget_lane_f32(acbd0, 1);
                float32x2_t cy0_sw = vrev64_f32(cy0v);
                float32x2_t adbc0 = vmul_f32(y0v, cy0_sw);
                float i00 = vget_lane_f32(adbc0, 0) + vget_lane_f32(adbc0, 1);
                s00 += Complex(r00, i00);
                // y0*conj(y1)
                float32x2_t acbd1 = vmul_f32(y0v, cy1v);
                float r01 = vget_lane_f32(acbd1, 0) - vget_lane_f32(acbd1, 1);
                float32x2_t cy1_sw = vrev64_f32(cy1v);
                float32x2_t adbc1 = vmul_f32(y0v, cy1_sw);
                float i01 = vget_lane_f32(adbc1, 0) + vget_lane_f32(adbc1, 1);
                s01 += Complex(r01, i01);
                // y1*conj(y1)
                float32x2_t acbd3 = vmul_f32(y1v, cy1v);
                float r11 = vget_lane_f32(acbd3, 0) - vget_lane_f32(acbd3, 1);
                float32x2_t adbc3 = vmul_f32(y1v, cy1_sw);
                float i11 = vget_lane_f32(adbc3, 0) + vget_lane_f32(adbc3, 1);
                s11 += Complex(r11, i11);
            #else
                s00 += y0 * std::conj(y0);
                s01 += y0 * std::conj(y1);
                s11 += y1 * std::conj(y1);
            #endif
            }
            YiYi[0][0] = s00;
            YiYi[0][1] = s01;
            YiYi[1][0] = std::conj(s01);
            YiYi[1][1] = s11;
        } else {
            for (int m = 0; m < config_.num_sources; m++) {
                for (int n = 0; n < config_.num_sources; n++) {
                    Complex sum(0.0f, 0.0f);
                    for (int t = 0; t < config_.time_frames; t++) {
                        Complex y_m = separated_sources[f][t][m];
                        Complex y_n = separated_sources[f][t][n];
                        sum += y_m * std::conj(y_n);
                    }
                    YiYi[m][n] = sum;
                }
            }
        }

        // 步骤2: 计算 X(f,:,ref_mic)*Yi' (1 x M 向量)
        std::vector<Complex> XYi(config_.num_sources);
        if (config_.num_sources == 2) {
            Complex s0(0.0f, 0.0f), s1(0.0f, 0.0f);
            for (int t = 0; t < config_.time_frames; t++) {
                const Complex x_ref = original_input[f][t][ref_mic_index];
                const Complex y0 = separated_sources[f][t][0];
                const Complex y1 = separated_sources[f][t][1];
            #if AUXIVA_HAS_NEON
                float32x4_t xy = {x_ref.real(), x_ref.imag(), y0.real(), y0.imag()};
                float32x2_t x = vget_low_f32(xy);
                float32x2_t y0v = vget_high_f32(xy);
                float32x2_t cy0v = {vget_lane_f32(y0v,0), -vget_lane_f32(y0v,1)};
                float32x2_t adbc0 = vmul_f32(x, vrev64_f32(cy0v));
                float32x2_t acbd0 = vmul_f32(x, cy0v);
                float r0 = vget_lane_f32(acbd0,0) - vget_lane_f32(acbd0,1);
                float i0 = vget_lane_f32(adbc0,0) + vget_lane_f32(adbc0,1);
                s0 += Complex(r0, i0);
                float32x2_t y1v = {y1.real(), y1.imag()};
                float32x2_t cy1v = {y1.real(), -y1.imag()};
                float32x2_t adbc1 = vmul_f32(x, vrev64_f32(cy1v));
                float32x2_t acbd1 = vmul_f32(x, cy1v);
                float r1 = vget_lane_f32(acbd1,0) - vget_lane_f32(acbd1,1);
                float i1 = vget_lane_f32(adbc1,0) + vget_lane_f32(adbc1,1);
                s1 += Complex(r1, i1);
            #else
                s0 += x_ref * std::conj(y0);
                s1 += x_ref * std::conj(y1);
            #endif
            }
            XYi[0] = s0;
            XYi[1] = s1;
        } else {
            for (int m = 0; m < config_.num_sources; m++) {
                Complex sum(0.0f, 0.0f);
                for (int t = 0; t < config_.time_frames; t++) {
                    Complex x_ref = original_input[f][t][ref_mic_index];
                    Complex y_m = separated_sources[f][t][m];
                    sum += x_ref * std::conj(y_m);
                }
                XYi[m] = sum;
            }
        }

        // 步骤3: 求解 A = XYi / YiYi
        std::vector<Complex> A(config_.num_sources);
        for (int m = 0; m < config_.num_sources; m++) {
            double denominator = std::real(YiYi[m][m]);  // 双精度
            if (denominator > config_.eps) {
                A[m] = XYi[m] / static_cast<float>(denominator);  
            } else {
                A[m] = Complex(1.0, 0.0);  // 回退值，双精度
            }
        }

        // 步骤4: 应用缩放 Z(f,:,m) = A(m)*Y(f,:,m)
        if (config_.num_sources == 2) {
            for (int t = 0; t < config_.time_frames; t++) {
            #if AUXIVA_HAS_NEON
                const Complex a0 = A[0];
                const Complex a1 = A[1];
                const Complex y0 = separated_sources[f][t][0];
                const Complex y1 = separated_sources[f][t][1];
                // Pack [a0.re, a0.im, a1.re, a1.im] and [y0.re, y0.im, y1.re, y1.im]
                float32x4_t a01 = {a0.real(), a0.imag(), a1.real(), a1.imag()};
                float32x4_t y01 = {y0.real(), y0.imag(), y1.real(), y1.imag()};
                // Per-pair complex multiply
                float32x2_t a_lo = vget_low_f32(a01);
                float32x2_t a_hi = vget_high_f32(a01);
                float32x2_t y_lo = vget_low_f32(y01);
                float32x2_t y_hi = vget_high_f32(y01);
                float32x2_t acbd_lo = vmul_f32(a_lo, y_lo);
                float32x2_t acbd_hi = vmul_f32(a_hi, y_hi);
                float real0 = vget_lane_f32(acbd_lo, 0) - vget_lane_f32(acbd_lo, 1);
                float real1 = vget_lane_f32(acbd_hi, 0) - vget_lane_f32(acbd_hi, 1);
                float32x2_t y_lo_sw = vrev64_f32(y_lo);
                float32x2_t y_hi_sw = vrev64_f32(y_hi);
                float32x2_t adbc_lo = vmul_f32(a_lo, y_lo_sw);
                float32x2_t adbc_hi = vmul_f32(a_hi, y_hi_sw);
                float imag0 = vget_lane_f32(adbc_lo, 0) + vget_lane_f32(adbc_lo, 1);
                float imag1 = vget_lane_f32(adbc_hi, 0) + vget_lane_f32(adbc_hi, 1);
                corrected_output[f][t][0] = Complex(real0, imag0);
                corrected_output[f][t][1] = Complex(real1, imag1);
            #else
                for (int m = 0; m < 2; m++) {
                    Complex y_val = separated_sources[f][t][m];
                    corrected_output[f][t][m] = A[m] * y_val;
                }
            #endif
            }
        } else {
            for (int t = 0; t < config_.time_frames; t++) {
                for (int m = 0; m < config_.num_sources; m++) {
                    Complex y_val = separated_sources[f][t][m];
                    corrected_output[f][t][m] = A[m] * y_val;
                }
            }
        }
    }

    ALG_LOGI("Applied back projection with reference mic %d", ref_mic_index);
}



/**
 * @brief 更新源模型(功率谱密度)
 *
 * 基于当前分离的源信号计算每个源在每个时间帧的功率，
 * 用作辅助函数优化中的权重。r_{j,n} = sum_i |y_{i,j,n}|^2
 */
void AuxIVAProcessor::UpdateSourceModels(const ComplexTensor& separated_sources) {
    // r_{j,n} = sum_i |y_{i,j,n}|^2 (无平方根！)
    for (int s = 0; s < config_.num_sources; s++) {
        for (int t = 0; t < config_.time_frames; t++) {
            double power = 0.0;  // 双精度累加

            // 计算所有频率的功率: sum_i |y_{i,j,n}|^2
            for (int f = 0; f < config_.freq_bins; f++) {
                Complex y = separated_sources[f][t][s];
                power += y.real() * y.real() + y.imag() * y.imag();  // 双精度计算
            }

            // 应用最小值限制
            if (power < config_.eps) {
                power = config_.eps;
            }

            // 存储功率
            source_models_[s][t] = power;
        }
    }
}

void AuxIVAProcessor::UpdateDemixingMatrix(int freq_bin,
                                          const ComplexMatrix& input_freq,
                                          const std::vector<std::vector<double>>& source_models) {

    // 提取当前频点的解混矩阵 W_freq
    ComplexMatrix W_freq(config_.num_sources, std::vector<Complex>(config_.num_channels));
    for (int s = 0; s < config_.num_sources; s++) {
        for (int m = 0; m < config_.num_channels; m++) {
            W_freq[s][m] = demixing_matrices_[freq_bin][s][m];
        }
    }

    for (int source_idx = 0; source_idx < config_.num_sources; source_idx++) {
        // 步骤1: 计算协方差矩阵 D = (1/J) * sum_j (x_j * x_j^H / r_j)
        ComputeCovarianceMatrix(freq_bin, source_idx, input_freq, source_models[source_idx]);

        // 步骤2: 求解线性方程
        std::vector<Complex> new_demixing_vector(config_.num_channels);
        if (SolveDemixingVector(source_idx, W_freq, new_demixing_vector)) {
            // 步骤3: 更新解混矩阵 W[source_idx, :, freq_bin] = w_vector^H
            for (int m = 0; m < config_.num_channels; m++) {
                // 存储共轭转置
                demixing_matrices_[freq_bin][source_idx][m] = std::conj(new_demixing_vector[m]);
            }
        }
    }
}

void AuxIVAProcessor::ComputeCovarianceMatrix(int freq_bin, int source_idx,
                                            const ComplexMatrix& input_freq,
                                            const std::vector<double>& source_model) {

    // 初始化协方差矩阵为零
    for (int i = 0; i < config_.num_channels; i++) {
        for (int j = 0; j < config_.num_channels; j++) {
            temp_matrix_[i][j] = Complex(0.0, 0.0);  // 双精度初始化
        }
    }

    // D = (1/J) * sum_j (x_j * x_j^H / r_j)
    for (int t = 0; t < config_.time_frames; t++) {
        double r_val = source_model[t];
        if (r_val < config_.eps) r_val = config_.eps;

#ifdef IVA_OPT_B4
        // 使用Gram缓存
        const ComplexMatrix& G = gram_cache_[freq_bin][t];
        if (config_.num_channels == 2) {
            float inv_r = static_cast<float>(1.0 / r_val);
        #if AUXIVA_HAS_NEON
            float32x4_t scale = vdupq_n_f32(inv_r);
            float32x4_t g01 = {G[0][0].real(), G[0][0].imag(), G[0][1].real(), G[0][1].imag()};
            float32x4_t g10_11 = {G[1][0].real(), G[1][0].imag(), G[1][1].real(), G[1][1].imag()};
            g01 = vmulq_f32(g01, scale);
            g10_11 = vmulq_f32(g10_11, scale);
            temp_matrix_[0][0] += Complex(vgetq_lane_f32(g01, 0), vgetq_lane_f32(g01, 1));
            temp_matrix_[0][1] += Complex(vgetq_lane_f32(g01, 2), vgetq_lane_f32(g01, 3));
            temp_matrix_[1][0] += Complex(vgetq_lane_f32(g10_11, 0), vgetq_lane_f32(g10_11, 1));
            temp_matrix_[1][1] += Complex(vgetq_lane_f32(g10_11, 2), vgetq_lane_f32(g10_11, 3));
        #else
            temp_matrix_[0][0] += G[0][0] * inv_r;
            temp_matrix_[0][1] += G[0][1] * inv_r;
            temp_matrix_[1][0] += G[1][0] * inv_r;
            temp_matrix_[1][1] += G[1][1] * inv_r;
        #endif
        } else {
            for (int m1 = 0; m1 < config_.num_channels; m1++) {
                for (int m2 = 0; m2 < config_.num_channels; m2++) {
                    temp_matrix_[m1][m2] += G[m1][m2] / static_cast<float>(r_val);
                }
            }
        }
#else
        // 直接按帧计算外积
        for (int m1 = 0; m1 < config_.num_channels; m1++) {
            for (int m2 = 0; m2 < config_.num_channels; m2++) {
                Complex x_m1 = input_freq[t][m1];
                Complex x_m2_conj = std::conj(input_freq[t][m2]);
                Complex contrib = (x_m1 * x_m2_conj) / static_cast<float>(r_val);
                temp_matrix_[m1][m2] += contrib;
            }
        }
#endif
    }

    // 除以时间帧数 J
    double scale = 1.0 / config_.time_frames;  // 双精度缩放
    for (int m1 = 0; m1 < config_.num_channels; m1++) {
        for (int m2 = 0; m2 < config_.num_channels; m2++) {
            temp_matrix_[m1][m2] *= scale;
        }
    }
}

bool AuxIVAProcessor::SolveDemixingVector(int source_idx, const ComplexMatrix& W_freq, std::vector<Complex>& demixing_vector) {
    // w = (W * D)^{-1} * e_n，然后归一化 w = w / sqrt(w^H * D * w)

    // 步骤1: 计算 WD = W_freq * D
    ComplexMatrix WD(config_.num_channels, std::vector<Complex>(config_.num_channels));
    if (config_.num_channels == 2) {
        // 2x2 专门化
        const Complex &w00 = W_freq[0][0], &w01 = W_freq[0][1];
        const Complex &w10 = W_freq[1][0], &w11 = W_freq[1][1];
        const Complex &d00 = temp_matrix_[0][0], &d01 = temp_matrix_[0][1];
        const Complex &d10 = temp_matrix_[1][0], &d11 = temp_matrix_[1][1];
    #if AUXIVA_HAS_NEON
        // Row0: [w00 w01] * [ [d00 d01]; [d10 d11] ]
        float32x4_t w0 = {w00.real(), w00.imag(), w01.real(), w01.imag()};
        float32x4_t d0 = {d00.real(), d00.imag(), d01.real(), d01.imag()};
        float32x4_t d1 = {d10.real(), d10.imag(), d11.real(), d11.imag()};
        float32x2_t w00v = vget_low_f32(w0);
        float32x2_t w01v = vget_high_f32(w0);
        float32x2_t d00v = vget_low_f32(d0);
        float32x2_t d01v = vget_high_f32(d0);
        float32x2_t d10v = vget_low_f32(d1);
        float32x2_t d11v = vget_high_f32(d1);
        // real: (w00*d00 + w01*d10).re = (a*c - b*d) + (e*g - f*h)
        float32x2_t acbd0 = vmul_f32(w00v, d00v);
        float32x2_t acbd1 = vmul_f32(w01v, d10v);
        float r00 = (vget_lane_f32(acbd0,0) - vget_lane_f32(acbd0,1)) + (vget_lane_f32(acbd1,0) - vget_lane_f32(acbd1,1));
        // imag: (a*d + b*c) + (e*h + f*g)
        float32x2_t d00v_sw = vrev64_f32(d00v);
        float32x2_t d10v_sw = vrev64_f32(d10v);
        float32x2_t adbc0 = vmul_f32(w00v, d00v_sw);
        float32x2_t adbc1 = vmul_f32(w01v, d10v_sw);
        float i00 = (vget_lane_f32(adbc0,0) + vget_lane_f32(adbc0,1)) + (vget_lane_f32(adbc1,0) + vget_lane_f32(adbc1,1));
        // Row0 col1: w00*d01 + w01*d11
        float32x2_t acbd2 = vmul_f32(w00v, d01v);
        float32x2_t acbd3 = vmul_f32(w01v, d11v);
        float r01 = (vget_lane_f32(acbd2,0) - vget_lane_f32(acbd2,1)) + (vget_lane_f32(acbd3,0) - vget_lane_f32(acbd3,1));
        float32x2_t d01v_sw = vrev64_f32(d01v);
        float32x2_t d11v_sw = vrev64_f32(d11v);
        float32x2_t adbc2 = vmul_f32(w00v, d01v_sw);
        float32x2_t adbc3 = vmul_f32(w01v, d11v_sw);
        float i01 = (vget_lane_f32(adbc2,0) + vget_lane_f32(adbc2,1)) + (vget_lane_f32(adbc3,0) + vget_lane_f32(adbc3,1));
        WD[0][0] = Complex(r00, i00);
        WD[0][1] = Complex(r01, i01);
        // Row1: [w10 w11] * D
        float32x4_t w1 = {w10.real(), w10.imag(), w11.real(), w11.imag()};
        float32x2_t w10v = vget_low_f32(w1);
        float32x2_t w11v = vget_high_f32(w1);
        float32x2_t acbd4 = vmul_f32(w10v, d00v);
        float32x2_t acbd5 = vmul_f32(w11v, d10v);
        float r10 = (vget_lane_f32(acbd4,0) - vget_lane_f32(acbd4,1)) + (vget_lane_f32(acbd5,0) - vget_lane_f32(acbd5,1));
        float32x2_t adbc4 = vmul_f32(w10v, d00v_sw);
        float32x2_t adbc5 = vmul_f32(w11v, d10v_sw);
        float i10 = (vget_lane_f32(adbc4,0) + vget_lane_f32(adbc4,1)) + (vget_lane_f32(adbc5,0) + vget_lane_f32(adbc5,1));
        float32x2_t acbd6 = vmul_f32(w10v, d01v);
        float32x2_t acbd7 = vmul_f32(w11v, d11v);
        float r11 = (vget_lane_f32(acbd6,0) - vget_lane_f32(acbd6,1)) + (vget_lane_f32(acbd7,0) - vget_lane_f32(acbd7,1));
        float32x2_t adbc6 = vmul_f32(w10v, d01v_sw);
        float32x2_t adbc7 = vmul_f32(w11v, d11v_sw);
        float i11 = (vget_lane_f32(adbc6,0) + vget_lane_f32(adbc6,1)) + (vget_lane_f32(adbc7,0) + vget_lane_f32(adbc7,1));
        WD[1][0] = Complex(r10, i10);
        WD[1][1] = Complex(r11, i11);
    #else
        WD[0][0] = w00 * d00 + w01 * d10;
        WD[0][1] = w00 * d01 + w01 * d11;
        WD[1][0] = w10 * d00 + w11 * d10;
        WD[1][1] = w10 * d01 + w11 * d11;
    #endif
    } else {
        for (int i = 0; i < config_.num_channels; i++) {
            for (int j = 0; j < config_.num_channels; j++) {
                WD[i][j] = Complex(0.0f, 0.0f);
                for (int k = 0; k < config_.num_channels; k++) {
                    WD[i][j] += W_freq[i][k] * temp_matrix_[k][j];
                }
            }
        }
    }

    // 步骤2: 求逆 WD_inv = (W * D)^{-1}
    ComplexMatrix WD_inv = WD;  // 复制用于求逆
    if (!InvertMatrix(WD_inv)) {
        ALG_LOGE("Failed to invert WD matrix in SolveDemixingVector");
        return false;
    }

    // 步骤3/4: 直接取列向量 w = WD_inv[:, source_idx]
    demixing_vector.resize(config_.num_channels);
    for (int i = 0; i < config_.num_channels; i++) {
        demixing_vector[i] = WD_inv[i][source_idx];
    }

    // 步骤5: 归一化处理
    // 计算 D * w
    std::vector<Complex> Dw(config_.num_channels);
    if (config_.num_channels == 2) {
    #if AUXIVA_HAS_NEON
        const Complex &d00 = temp_matrix_[0][0], &d01 = temp_matrix_[0][1];
        const Complex &d10 = temp_matrix_[1][0], &d11 = temp_matrix_[1][1];
        const Complex &w0 = demixing_vector[0], &w1 = demixing_vector[1];
        // Compute [Dw0, Dw1] = [ [d00 d01]; [d10 d11] ] * [w0; w1]
        float32x4_t d0 = {d00.real(), d00.imag(), d01.real(), d01.imag()};
        float32x4_t d1 = {d10.real(), d10.imag(), d11.real(), d11.imag()};
        float32x4_t w01 = {w0.real(), w0.imag(), w1.real(), w1.imag()};
        // Row0: d00*w0 + d01*w1
        float32x2_t d00v = vget_low_f32(d0);
        float32x2_t d01v = vget_high_f32(d0);
        float32x2_t w0v  = vget_low_f32(w01);
        float32x2_t w1v  = vget_high_f32(w01);
        float32x2_t acbd0 = vmul_f32(d00v, w0v);
        float32x2_t acbd1 = vmul_f32(d01v, w1v);
        float r0 = (vget_lane_f32(acbd0,0) - vget_lane_f32(acbd0,1)) + (vget_lane_f32(acbd1,0) - vget_lane_f32(acbd1,1));
        float32x2_t w0v_sw = vrev64_f32(w0v);
        float32x2_t w1v_sw = vrev64_f32(w1v);
        float32x2_t adbc0 = vmul_f32(d00v, w0v_sw);
        float32x2_t adbc1 = vmul_f32(d01v, w1v_sw);
        float i0 = (vget_lane_f32(adbc0,0) + vget_lane_f32(adbc0,1)) + (vget_lane_f32(adbc1,0) + vget_lane_f32(adbc1,1));
        // Row1: d10*w0 + d11*w1
        float32x2_t d10v = vget_low_f32(d1);
        float32x2_t d11v = vget_high_f32(d1);
        float32x2_t acbd2 = vmul_f32(d10v, w0v);
        float32x2_t acbd3 = vmul_f32(d11v, w1v);
        float r1 = (vget_lane_f32(acbd2,0) - vget_lane_f32(acbd2,1)) + (vget_lane_f32(acbd3,0) - vget_lane_f32(acbd3,1));
        float32x2_t adbc2 = vmul_f32(d10v, w0v_sw);
        float32x2_t adbc3 = vmul_f32(d11v, w1v_sw);
        float i1 = (vget_lane_f32(adbc2,0) + vget_lane_f32(adbc2,1)) + (vget_lane_f32(adbc3,0) + vget_lane_f32(adbc3,1));
        Dw[0] = Complex(r0, i0);
        Dw[1] = Complex(r1, i1);
    #else
        const Complex &d00 = temp_matrix_[0][0], &d01 = temp_matrix_[0][1];
        const Complex &d10 = temp_matrix_[1][0], &d11 = temp_matrix_[1][1];
        const Complex &w0 = demixing_vector[0], &w1 = demixing_vector[1];
        Dw[0] = d00 * w0 + d01 * w1;
        Dw[1] = d10 * w0 + d11 * w1;
    #endif
    } else {
        for (int i = 0; i < config_.num_channels; i++) {
            Dw[i] = Complex(0.0f, 0.0f);
            for (int j = 0; j < config_.num_channels; j++) {
                Dw[i] += temp_matrix_[i][j] * demixing_vector[j];
            }
        }
    }

    // 计算 w^H * D * w
    Complex wHDw(0.0f, 0.0f);
    if (config_.num_channels == 2) {
        wHDw = std::conj(demixing_vector[0]) * Dw[0] + std::conj(demixing_vector[1]) * Dw[1];
    } else {
        for (int i = 0; i < config_.num_channels; i++) {
            wHDw += std::conj(demixing_vector[i]) * Dw[i];
        }
    }

    // 归一化: w = w / sqrt(w^H * D * w)
    // w^H * D * w 对于 Hermitian D 应该是实数，取实部并开方
    float wHDw_real = std::real(wHDw);
    float norm_factor = std::sqrt(wHDw_real);
    if (norm_factor > static_cast<float>(config_.eps)) {
        for (int i = 0; i < config_.num_channels; i++) {
            demixing_vector[i] /= norm_factor;
        }
    }

    return true;
}

bool AuxIVAProcessor::InvertMatrix(ComplexMatrix& matrix) {
    int n = matrix.size();
    if (n == 0 || matrix[0].size() != static_cast<size_t>(n)) {
        return false;
    }

    // 计算矩阵迹用于相对对角加载
    double matrix_trace = 0.0;  // 双精度
    for (int i = 0; i < n; i++) {
        matrix_trace += std::real(matrix[i][i]);
    }

    // 计算对角加载值
    double diag_load = std::max(config_.diag_load_abs,
                               config_.diag_load_rel * matrix_trace / n);  // 双精度计算


    if (n == 2) {
        // Form A with diagonal loading: A = matrix + diag(diag_load)
        Complex a11 = matrix[0][0] + Complex(static_cast<float>(diag_load), 0.0f);
        Complex a12 = matrix[0][1];
        Complex a21 = matrix[1][0];
        Complex a22 = matrix[1][1] + Complex(static_cast<float>(diag_load), 0.0f);
        Complex det = a11 * a22 - a12 * a21;
        double det_abs = std::abs(det);
        double threshold = std::max(config_.eps, 1e-12);
        if (det_abs >= threshold) {
            Complex inv_det = Complex(1.0f, 0.0f) / det;
            Complex i11 =  a22 * inv_det;
            Complex i12 = -a12 * inv_det;
            Complex i21 = -a21 * inv_det;
            Complex i22 =  a11 * inv_det;
            matrix[0][0] = i11;
            matrix[0][1] = i12;
            matrix[1][0] = i21;
            matrix[1][1] = i22;
            return true;
        } else {
            #if !IVA_LOG_SUPPRESS_NEAR_SINGULAR_INVERSE
            ALG_LOGE("Matrix near-singular in 2x2 InvertMatrix: |det|=%.2e, thr=%.2e", det_abs, threshold);
            #endif
            // Fall through to Gauss-Jordan fallback below
        }
    }

    // Create augmented matrix [A|I] with diagonal loading
    std::vector<std::vector<Complex>> aug(n, std::vector<Complex>(2 * n));

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            aug[i][j] = matrix[i][j];
            if (i == j) {
                aug[i][j] += Complex(diag_load, 0.0f);  // 添加对角加载
            }
            aug[i][j + n] = (i == j) ? Complex(1.0f, 0.0f) : Complex(0.0f, 0.0f);
        }
    }

    // Gauss-Jordan elimination
    for (int i = 0; i < n; i++) {
        // Find pivot
        int pivot = i;
        double max_abs = std::abs(aug[i][i]);
        for (int k = i + 1; k < n; k++) {
            double abs_val = std::abs(aug[k][i]);
            if (abs_val > max_abs) {
                max_abs = abs_val;
                pivot = k;
            }
        }

        double threshold = std::max(config_.eps, 1e-12);  // 双精度阈值
        if (max_abs < threshold) {
            ALG_LOGE("Matrix singular in InvertMatrix: max_abs=%.2e, threshold=%.2e", max_abs, threshold);
            return false;  // Singular matrix
        }

        // Swap rows
        if (pivot != i) {
            std::swap(aug[i], aug[pivot]);
        }

        // Scale pivot row
        Complex pivot_val = aug[i][i];
        for (int j = 0; j < 2 * n; j++) {
            aug[i][j] /= pivot_val;
        }

        // Eliminate column
        for (int k = 0; k < n; k++) {
            if (k != i) {
                Complex factor = aug[k][i];
                for (int j = 0; j < 2 * n; j++) {
                    aug[k][j] -= factor * aug[i][j];
                }
            }
        }
    }

    // Extract inverse matrix
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            matrix[i][j] = aug[i][j + n];
        }
    }

    return true;
}

void AuxIVAProcessor::UpdateDemixingMatrixFreqSource(int freq_bin, int source_idx, const ComplexMatrix& input_freq) {


    // 步骤1: 计算协方差矩阵 D
    ComputeCovarianceMatrix(freq_bin, source_idx, input_freq, source_models_[source_idx]);

    // 步骤2: 提取当前频点的解混矩阵 W_freq
    ComplexMatrix W_freq(config_.num_sources, std::vector<Complex>(config_.num_channels));
    for (int s = 0; s < config_.num_sources; s++) {
        for (int m = 0; m < config_.num_channels; m++) {
            W_freq[s][m] = demixing_matrices_[freq_bin][s][m];
        }
    }

    // 步骤3: 求解解混向量 iva: w = (W * D)^{-1} * e_n
    std::vector<Complex> new_demixing_vector(config_.num_channels);
    if (SolveDemixingVector(source_idx, W_freq, new_demixing_vector)) {
        // 步骤4: 更新解混矩阵 W[source_idx, :, freq_bin] = w_vector^H
        for (int m = 0; m < config_.num_channels; m++) {
            // 存储共轭转置
            demixing_matrices_[freq_bin][source_idx][m] = std::conj(new_demixing_vector[m]);
        }
    }
}

void AuxIVAProcessor::NormalizeDemixingMatrices() {
    // lambda[n] = sqrt(sum_{i,j} P[i,j,n] / (I*J))

    std::vector<double> lambda(config_.num_sources);

    // 步骤1: 计算每个源的归一化因子 lambda[n]
    for (int n = 0; n < config_.num_sources; n++) {
        double total_power = 0.0;

        // source_models_[n][j] 已经是对所有频率求和的结果
        // 所以这里只需要对时间求和
        for (int j = 0; j < config_.time_frames; j++) {
            total_power += source_models_[n][j];
        }

        // lambda[n] = sqrt(total_power / (I * J))
        // 由于source_models_已经对频率求和
        lambda[n] = std::sqrt(total_power / (config_.freq_bins * config_.time_frames));

        // 避免除零
        if (lambda[n] < config_.eps) {
            lambda[n] = 1.0;
        }
    }

    // 步骤2: 归一化解混矩阵 W[n,:,:] = W[n,:,:] / lambda[n]
    for (int n = 0; n < config_.num_sources; n++) {
        for (int m = 0; m < config_.num_channels; m++) {
            for (int i = 0; i < config_.freq_bins; i++) {
                demixing_matrices_[i][n][m] /= static_cast<float>(lambda[n]);
            }
        }
    }

    // 步骤3: 归一化源模型 P[:,:,n] = P[:,:,n] / lambda[n]^2
    for (int n = 0; n < config_.num_sources; n++) {
        double lambda_sq = lambda[n] * lambda[n];
        for (int j = 0; j < config_.time_frames; j++) {
            source_models_[n][j] /= lambda_sq;
        }
    }
}

bool AuxIVAProcessor::CheckConvergence(const ComplexTensor& prev_demixing, double threshold) {
    // 计算解混矩阵的相对变化量

    double total_diff = 0.0;
    double total_norm = 0.0;

    for (int f = 0; f < config_.freq_bins; f++) {
        for (int s = 0; s < config_.num_sources; s++) {
            for (int c = 0; c < config_.num_channels; c++) {
                Complex curr = demixing_matrices_[f][s][c];
                Complex prev = prev_demixing[f][s][c];
                Complex diff = curr - prev;

                // 累计差异的平方和
                total_diff += std::norm(diff);
                // 累计当前值的平方和
                total_norm += std::norm(curr);
            }
        }
    }

    // 避免除零
    if (total_norm < config_.eps) {
        return true;  // 如果矩阵接近零，认为已收敛
    }

    // 计算相对变化量
    double relative_change = std::sqrt(total_diff / total_norm);

    ALG_LOGI("Convergence check: relative_change=%.2e, threshold=%.2e",
             relative_change, threshold);

    return relative_change < threshold;
}



void AuxIVAProcessor::Reset() {
    if (initialized_) {
        InitializeDemixingMatrices();
#ifdef IVA_OPT_B4
        gram_cache_valid_ = false;
        gram_cache_.clear();
        gram_cache_time_frames_ = 0;
        gram_cache_channels_ = 0;
#endif
    }
}

#ifdef IVA_OPT_B4
void AuxIVAProcessor::BuildGramCache(const ComplexTensor& input) {
    gram_cache_.clear();
    gram_cache_.resize(config_.freq_bins);
    for (int f = 0; f < config_.freq_bins; ++f) {
        gram_cache_[f].resize(config_.time_frames);
        for (int t = 0; t < config_.time_frames; ++t) {
            ComplexMatrix G(config_.num_channels, std::vector<Complex>(config_.num_channels));
            if (config_.num_channels == 2) {
            #if AUXIVA_HAS_NEON
                const Complex x0 = input[f][t][0];
                const Complex x1 = input[f][t][1];
                // G = x x^H =>
                // G00 = x0*conj(x0), G01 = x0*conj(x1), G10 = x1*conj(x0), G11 = x1*conj(x1)
                float32x4_t x01 = {x0.real(), x0.imag(), x1.real(), x1.imag()};
                float32x4_t conj_x01 = {x0.real(), -x0.imag(), x1.real(), -x1.imag()};
                // Pairwise complex multiply
                float32x2_t x0v = vget_low_f32(x01);
                float32x2_t x1v = vget_high_f32(x01);
                float32x2_t cx0v = vget_low_f32(conj_x01);
                float32x2_t cx1v = vget_high_f32(conj_x01);
                // x0*conj(x0)
                float32x2_t acbd0 = vmul_f32(x0v, cx0v);
                float g00_r = vget_lane_f32(acbd0, 0) - vget_lane_f32(acbd0, 1);
                float32x2_t cx0v_sw = vrev64_f32(cx0v);
                float32x2_t adbc0 = vmul_f32(x0v, cx0v_sw);
                float g00_i = vget_lane_f32(adbc0, 0) + vget_lane_f32(adbc0, 1);
                // x0*conj(x1)
                float32x2_t acbd1 = vmul_f32(x0v, cx1v);
                float g01_r = vget_lane_f32(acbd1, 0) - vget_lane_f32(acbd1, 1);
                float32x2_t cx1v_sw = vrev64_f32(cx1v);
                float32x2_t adbc1 = vmul_f32(x0v, cx1v_sw);
                float g01_i = vget_lane_f32(adbc1, 0) + vget_lane_f32(adbc1, 1);
                // x1*conj(x0)
                float32x2_t acbd2 = vmul_f32(x1v, cx0v);
                float g10_r = vget_lane_f32(acbd2, 0) - vget_lane_f32(acbd2, 1);
                float32x2_t adbc2 = vmul_f32(x1v, cx0v_sw);
                float g10_i = vget_lane_f32(adbc2, 0) + vget_lane_f32(adbc2, 1);
                // x1*conj(x1)
                float32x2_t acbd3 = vmul_f32(x1v, cx1v);
                float g11_r = vget_lane_f32(acbd3, 0) - vget_lane_f32(acbd3, 1);
                float32x2_t cx1v_sw2 = vrev64_f32(cx1v);
                float32x2_t adbc3 = vmul_f32(x1v, cx1v_sw2);
                float g11_i = vget_lane_f32(adbc3, 0) + vget_lane_f32(adbc3, 1);
                G[0][0] = Complex(g00_r, g00_i);
                G[0][1] = Complex(g01_r, g01_i);
                G[1][0] = Complex(g10_r, g10_i);
                G[1][1] = Complex(g11_r, g11_i);
            #else
                for (int i = 0; i < 2; ++i) {
                    for (int j = 0; j < 2; ++j) {
                        G[i][j] = input[f][t][i] * std::conj(input[f][t][j]);
                    }
                }
            #endif
            } else {
                for (int i = 0; i < config_.num_channels; ++i) {
                    for (int j = 0; j < config_.num_channels; ++j) {
                        G[i][j] = input[f][t][i] * std::conj(input[f][t][j]);
                    }
                }
            }
            gram_cache_[f][t] = std::move(G);
        }
    }
    gram_cache_valid_ = true;
    gram_cache_time_frames_ = config_.time_frames;
    gram_cache_channels_ = config_.num_channels;
}
#endif

void AuxIVAProcessor::Cleanup() {
    demixing_matrices_.clear();
    temp_matrix_.clear();
    source_powers_.clear();
    source_models_.clear();
#ifdef IVA_OPT_B4
    gram_cache_.clear();
    gram_cache_valid_ = false;
    gram_cache_time_frames_ = 0;
    gram_cache_channels_ = 0;
#endif
    initialized_ = false;
}

} // namespace kws2k2_faith
