#ifndef IVA_PROCESSOR_H
#define IVA_PROCESSOR_H

#include <memory>
#include <vector>

namespace kws2k2_faith {

/**
 * @brief IVA配置结构体
 *
 * 包含配置IVA处理器所需的所有参数
 */
struct IvaConfig {
    int sample_rate;       ///< 采样率 (16000)
    int num_channels;      ///< 输入通道数 (>= 2)
    int window_samples;    ///< 处理窗口大小 (32000)
    int target_index;      ///< 目标源索引 (默认1，从零开始)
    const char* profile;   ///< 算法参数预设名称

    IvaConfig()
        : sample_rate(16000)
        , num_channels(2)
        , window_samples(32000)
        , target_index(1)
        , profile("default")
    {}
};

/**
 * @brief 音频预处理数据
 */
struct AudioPreprocessing {
    std::vector<double> original_header;  // 保存的前N个采样点（双精度）
    int header_samples;                   // 头部采样点数量
    double normalization_factor;         // 归一化因子（双精度）
    bool initialized;

    AudioPreprocessing() : header_samples(0), normalization_factor(1.0f), initialized(false) {}
};

/**
 * @brief IVA处理器类
 *
 * AuxIVA核心功能的C++封装，为多通道音频源分离提供初始化/处理/销毁接口
 */
class IvaProcessor {
public:
    IvaProcessor();
    ~IvaProcessor();
    
    /**
     * @brief 初始化IVA处理器
     *
     * @param cfg IVA配置参数
     * @return 成功返回0，失败返回负值
     */
    int Init(const IvaConfig& cfg);

    /**
     * @brief 处理多通道音频输入
     *
     * @param in_channels 输入通道，每个通道包含window_samples长度的数据
     * @param num_channels 输入通道数
     * @param window_samples 每通道的采样点数
     * @param out_mono 输出单通道，长度为window_samples
     * @return 成功返回0，失败返回负值
     */
    int Process(const double* const* in_channels,
                int num_channels,
                int window_samples,
                double* out_mono);

    /**
     * @brief 处理多通道音频输入并输出所有分离的源
     *
     * @param in_channels 输入通道，每个通道包含window_samples长度的数据
     * @param num_channels 输入通道数
     * @param window_samples 每通道的采样点数
     * @param out_channels 所有分离源的输出通道
     * @param kws_channel KWS的输出通道0(固定为源0，第一个分离源)
     * @return 成功返回0，失败返回负值
     */
    int ProcessAllSources(const double* const* in_channels,
                         int num_channels,
                         int window_samples,
                         double* const* out_channels,
                         double* kws_channel);

    /**
     * @brief 重置IVA处理器算法状态
     *
     * 重置内部算法状态(如解混矩阵)，同时保持处理器已初始化状态。
     * 在处理新文件时使用，避免前一文件的状态污染。
     *
     * @return 成功返回0，失败返回负值
     */
    int Reset();

    /**
     * @brief 销毁IVA处理器并释放资源
     *
     * @return 成功返回0，失败返回负值
     */
    int Destroy();

    /**
     * @brief 获取处理统计信息（总耗时、能量、RMS、SNR）
     */
    int GetStats(double* process_time_ms,
                 double* source_energies,
                 int num_sources,
                 double* output_rms,
                 double* snr_estimate);

    /**
     * @brief 获取IVA分阶段耗时统计（毫秒）
     *
     * 提供尽可能细粒度的阶段：
     * - convert_input_ms: 输入数据拷贝/格式转换
     * - stft_forward_ms: 正向STFT
     * - auxiva_ms: AuxIVA迭代分离
     * - stft_inverse_ms: 逆向STFT
     * - copy_outputs_ms: 输出拷贝/目标源生成
     *
     * @return 成功返回0，失败返回负值
     */
    int GetDetailedStats(double* total_ms,
                         double* convert_input_ms,
                         double* stft_forward_ms,
                         double* auxiva_ms,
                         double* stft_inverse_ms,
                         double* copy_outputs_ms);

    /**
     * @brief 应用音频预处理
     *
     * @param audio_data 输入/输出音频数据 [通道][采样点]
     * @param num_channels 通道数
     * @param num_samples 每通道的采样点数
     * @param preprocessing 预处理状态
     * @param header_samples 要保存的头部采样点数(200)
     * @return 成功返回0，失败返回负值
     */
    static int ApplyPreprocessing(std::vector<std::vector<double>>& audio_data,
                                 int num_channels, int num_samples,
                                 AudioPreprocessing& preprocessing,
                                 int header_samples = 200);

    /**
     * @brief 应用音频后处理
     *
     * @param audio_data 输入/输出音频数据 [通道][采样点]
     * @param num_channels 通道数
     * @param num_samples 每通道的采样点数
     * @param preprocessing 预处理状态
     * @return 成功返回0，失败返回负值
     */
    static int ApplyPostprocessing(std::vector<std::vector<double>>& audio_data,
                                  int num_channels, int num_samples,
                                  const AudioPreprocessing& preprocessing);

    static int ApplyPostprocessing(std::vector<std::vector<float>>& audio_data,
                                  int num_channels, int num_samples,
                                  const AudioPreprocessing& preprocessing);

private:
    class Impl;
    std::unique_ptr<Impl> pImpl;
};

} // namespace kws2k2_faith

#endif // IVA_PROCESSOR_H
