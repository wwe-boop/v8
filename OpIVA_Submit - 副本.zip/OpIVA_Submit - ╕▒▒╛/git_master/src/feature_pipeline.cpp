#include "feature_pipeline.h"

#include <algorithm>
#include <utility>

namespace kws2k2_faith {

FeaturePipeline::FeaturePipeline(const FeaturePipelineConfig& config)
    : config_(config),
      feature_dim_(config.num_bins),
      fbank_(config.num_bins, config.sample_rate, config.frame_length,
             config.frame_shift),
      num_frames_(0){}

std::vector<std::vector<float>> FeaturePipeline::AcceptWaveform(const std::vector<float>& wav) 
{
  std::vector<std::vector<float>> feats;
  std::vector<float> waves;
  waves.insert(waves.end(), wav.begin(), wav.end());
  int num_frames = fbank_.Compute(waves, &feats);
  
  return feats;
}
}  // namespace kws2k2_faith
