#ifndef KWS2K2_FAITH_CSRC_FFTSG_H_
#define KWS2K2_FAITH_CSRC_FFTSG_H_

#ifdef __cplusplus
extern "C" {
#endif

namespace kws2k2_faith {
void rdft(int n, int isgn, double *a, int *ip, double *w);
}
#ifdef __cplusplus
}
#endif

#endif  // KWS2K2_FAITH_CSRC_RFFT_H_
