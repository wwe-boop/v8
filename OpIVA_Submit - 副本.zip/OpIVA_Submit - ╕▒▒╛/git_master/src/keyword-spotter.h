#ifndef KEY_SPOTTER_H
#define KEY_SPOTTER_H

#include <string>
#include <memory>
#include "iva/iva_processor.h"

namespace kws2k2_faith {

/**
 * @struct KeywordSpotterConfig
 * @brief 关键词唤醒检测器的配置参数结构体
 * 
 * 包含了关键词检测所需的所有配置参数，包括解码参数、阈值设置、模型路径以及IVA多通道处理相关配置。
 * 提供了灵活的参数调节接口，支持不同应用场景的需求。
 */
struct KeywordSpotterConfig {
    /** @brief 解码过程中允许的最大活跃路径数，影响解码精度和性能 */
    int max_active_paths = 10;
    
    /** @brief 关键词结束后的静音帧数，用于确认关键词检测结果 */
    int num_tailing_blanks = 8;
    
    /** @brief 关键词得分的加权系数，用于调节关键词检测的敏感度 */
    float keywords_score = 1.0;
    
    /** @brief 关键词检测的阈值，低于此值的检测结果将被过滤 */
    float keywords_threshold = 0.1;

    /** @brief 词典和模型文件的根目录路径 */
    std::string lexiconPath;

    /** @brief 是否启用IVA多通道处理功能 */
    bool enable_iva = false;
    
    /** @brief IVA处理的音频通道数，通常为2（立体声）或更多 */
    int iva_num_channels = 1;
    
    /** @brief IVA处理的音频采样率，默认16kHz */
    int iva_sample_rate = 16000;
    
    /** @brief IVA处理的窗口大小（样本数），影响处理延迟和效果 */
    int iva_window_samples = 32000;
    
    /** @brief IVA目标源的索引，指定使用哪个分离出的音频源 */
    int iva_target_index = 0; 
    
    /** @brief IVA处理配置文件名称，影响分离算法的行为 */
    std::string iva_profile = "default";

    /** @brief 当前处理音频文件的文件名，用于生成输出目录 */
    std::string current_audio_filename;

    /** @brief 默认构造函数 */
    KeywordSpotterConfig() = default;

    /**
     * @brief 参数化构造函数
     * @param max_active_paths 最大活跃路径数
     * @param num_tailing_blanks 尾部静音帧数
     * @param keywords_score 关键词得分系数
     * @param keywords_threshold 关键词检测阈值
     * @param lexiconPath 词典路径
     */
    KeywordSpotterConfig(int32_t max_active_paths, int32_t num_tailing_blanks, float keywords_score,
                         float keywords_threshold, const std::string &lexiconPath)
        : max_active_paths(max_active_paths),
          num_tailing_blanks(num_tailing_blanks),
          keywords_score(keywords_score),
          keywords_threshold(keywords_threshold),
          lexiconPath(lexiconPath)
    {}

    /**
     * @brief 将配置转换为字符串表示
     * @return 包含所有配置参数的格式化字符串
     */
    std::string ToString() const;
};

/**
 * @struct KeywordResult
 * @brief 关键词检测结果结构体
 *
 * 存储关键词检测的完整结果信息，包括解码的token序列、检测到的关键词文本、
 * 时间戳信息以及置信度得分。为上层应用提供详细的检测结果分析数据。
 * 支持双阶段KWS处理的结果记录。
 */
struct KeywordResult {
    /** @brief 解码得到的token ID序列，对应关键词的编码表示 */
    std::vector<int32_t> tokens;

    /** @brief 检测到的关键词文本，如"你好悠悠" */
    std::string keyword;

    /** @brief 已解码的尾部静音帧数量，用于判断关键词结束 */
    int32_t num_tailing_blanks = 0;

    /** @brief 时间戳数组，timestamps[i]记录tokens[i]被解码时的输出帧索引 */
    std::vector<int32_t> timestamps;

    /** @brief KWS模型的原始置信度得分 */
    float ys_prob = 0;

    /** @brief E2E模型的置信度得分 */
    float e2e_score = 0;

    /** @brief 每个token对应的置信度得分序列 */
    std::vector<float> ys_probs;

    // 双阶段KWS处理结果字段
    /** @brief 第一次KWS识别到的关键词 */
    std::string kws_keyword_first;

    /** @brief 第一次KWS的置信度得分（单通道处理） */
    float kws_score_first = -1.0f;

    /** @brief 第一次E2E得分 */
    float e2e_score_first = -1.0f;

    /** @brief 第一次融合判定结果（0=未唤醒，1=唤醒） */
    int final_decision_first = -1;

    /** @brief 第二次KWS识别到的关键词 */
    std::string kws_keyword_second;

    /** @brief 第二次KWS的置信度得分（IVA处理后），-1表示未执行 */
    float kws_score_second = -1.0f;

    /** @brief 第二次E2E得分（通常复用第一次的值） */
    float e2e_score_second = -1.0f;

    /** @brief 第二次融合判定结果（0=未唤醒，1=唤醒），-1表示未执行 */
    int final_decision_second = -1;

    // 管线与时间统计字段
    /** @brief 管线标识符 */
    std::string pipeline_id = "kws_e2e_iva";

    /** @brief 管线规格描述 */
    std::string pipeline_spec = "single_ch_first_then_iva_fallback";

    /** @brief 模块标志位 */
    std::string module_flags = "NR+ECHO+KWS+E2E+IVA";

    /** @brief 模块参数JSON */
    std::string module_params_json = "{}";

    /** @brief 第一阶段处理时间（毫秒） */
    double stage1_time_ms = -1.0;

    /** @brief 第二阶段处理时间（毫秒），-1表示未执行 */
    double stage2_time_ms = -1.0;
};

/**
 * @struct DspInfo
 * @brief DSP处理信息结构体
 * 
 * 包含来自前端DSP处理器的详细信息，用于音频处理和唤醒检测的上下文数据。
 * 该结构体通常嵌入在音频数据的头部，提供音频分段、回声检测、版本校验等关键信息。
 */
struct DspInfo {
    /** @brief 语句开始帧位置，用于音频分段处理 */
    short sentenceBegin { 0 };
    
    /** @brief 语句结束帧位置，用于音频分段处理 */
    short sentenceEnd { 0 };
    
    /** @brief 目标ID，标识处理目标 */
    short tgtid { 0 };
    
    /** @brief 数据最大值信息 */
    short dataMax { 0 };
    
    /** @brief DSP处理类型标识 */
    short dspType { 0 };
    
    /** @brief 日志索引，用于调试和追踪 */
    short logIndex { 0 };
    
    /** @brief 保留字段，用于未来扩展 */
    short reserve[2] { 0 };
    
    /** @brief 读取延迟信息 */
    short read_delay;
    
    /** @brief 尾部静音长度 */
    short tail_sil_len;
    
    /** @brief 语句长度 */
    short sentence_length;
    
    /** @brief 总帧数 */
    short tot_frame;
    
    /** @brief 语句置信度 */
    int sentence_confi;
    
    /** @brief WAV文件帧数 */
    int wav_frame_num;
    
    /** @brief 解码延迟 */
    int decode_delay;
    
    /** @brief 标签信息 */
    int tag;
    
    /** @brief 不透明数据类型 */
    unsigned short opaqueDataType { 0 };
    
    /** @brief KWS1掩码，用于版本校验 */
    int kws1Mask;
    
    /** @brief 版本号，用于兼容性检查 */
    short version;
    
    /** @brief 回声场景标识，0:非回声, 1-2:回声场景 */
    short isEchoScene;
    
    /** @brief 解码日志信息，存储调试和分析数据 */
    char decode_log[280];
};

/** @brief Faith推理引擎前向声明 */
class FaithInference;

/**
 * @class KeywordSpotter
 * @brief 关键词唤醒检测器核心类
 * 
 * 这是关键词唤醒系统的主要处理类，集成了完整的音频处理管道：
 * - 噪声抑制和信号预处理
 * - 特征提取（FBANK特征）
 * - 神经网络推理（编码器、解码器、连接器）
 * - 端到端模型处理
 * - IVA多通道音频分离
 * - 关键词检测和后处理
 * 
 * 支持单通道和多通道音频输入，提供灵活的配置选项以适应不同的应用场景。
 */
class KeywordSpotter {
public:
    /**
     * @brief 默认构造函数
     * 
     * 初始化关键词检测器实例，所有推理引擎指针设为nullptr，
     * IVA处理器指针设为nullptr，需要调用KwsInit进行完整初始化。
     */
    KeywordSpotter() : iva_processor_(nullptr) {};
    
    /**
     * @brief 析构函数
     * 
     * 清理资源，但建议在析构前显式调用KwsDestory释放模型资源。
     */
    ~KeywordSpotter() {};
    
    /**
     * @brief 获取系统版本信息
     * 
     * 打印当前唤醒系统的版本号，用于调试和兼容性检查。
     */
    void GetVersion();
    
    /**
     * @brief 初始化关键词检测器
     * 
     * 加载所有必需的模型文件，包括编码器、解码器、连接器、噪声抑制模型和端到端模型。
     * 初始化IVA多通道处理器。验证模型文件的存在性和加载成功性。
     * 
     * @param config 包含模型路径和其他配置参数的配置结构体
     * @return 0表示成功，-1表示失败
     * @note 必须在使用任何处理函数前调用此函数
     */
    int KwsInit(const KeywordSpotterConfig &config);
    
    /**
     * @brief 处理单通道音频数据进行关键词检测
     * 
     * 对输入的单通道音频数据执行完整的关键词检测流程：
     * 1. 回声场景检测和噪声抑制
     * 2. 音频分段和特征提取
     * 3. 神经网络推理和解码
     * 4. 端到端模型验证
     * 5. 最终结果融合和输出
     * 
     * @param samples 输入音频数据指针（16位有符号整数）
     * @param samples_size 音频数据长度，必须等于32000（2秒@16kHz）
     * @param config 处理配置参数
     * @param results 输出的检测结果向量
     * @return 0表示成功，-1表示失败
     */
    int Process(const short *samples, int samples_size, const KeywordSpotterConfig &config,
                std::vector<KeywordResult> *results);

    /**
     * @brief 处理多通道音频数据进行关键词检测
     * 
     * 支持多通道音频输入的关键词检测，可选择性启用IVA多通道处理：
     * 1. 当启用IVA时：执行多通道音频分离，提取目标语音源
     * 2. 对目标源应用噪声抑制和关键词检测
     * 3. 可保存IVA处理产物用于分析和调试
     * 4. 当未启用IVA时：使用第一通道进行单通道处理
     * 
     * @param samples_by_channel 多通道音频数据指针数组
     * @param num_channels 音频通道数
     * @param samples_per_channel 每通道的样本数
     * @param config 处理配置参数，包含IVA相关设置
     * @param results 输出的检测结果向量
     * @return 0表示成功，-1表示失败
     */
    int ProcessMultiChannel(const short* const* samples_by_channel,
                           int num_channels,
                           int samples_per_channel,
                           const KeywordSpotterConfig& config,
                           std::vector<KeywordResult>* results);

    /**
     * @brief 销毁关键词检测器并释放资源
     *
     * 释放所有加载的模型资源，清理IVA处理器，确保内存正确释放。
     * 建议在应用退出前或不再需要关键词检测功能时调用。
     *
     * @return 0表示成功，-1表示失败
     */
    int KwsDestory();

    /**
     * @brief 获取IVA处理器的统计信息（总耗时）
     */
    int GetIvaStats(double* process_time_ms);

    /**
     * @brief 获取IVA分阶段耗时统计
     */
    int GetIvaDetailedStats(double* total_ms,
                            double* convert_input_ms,
                            double* stft_forward_ms,
                            double* auxiva_ms,
                            double* stft_inverse_ms,
                            double* copy_outputs_ms);

private:
    /** @brief K2编码器推理引擎 */
    std::shared_ptr<FaithInference> faith_inference_encoder;
    
    /** @brief 端到端编码器推理引擎 */
    std::shared_ptr<FaithInference> faith_inference_e2e_encoder;
    
    /** @brief 噪声抑制推理引擎 */
    std::shared_ptr<FaithInference> faith_inference_ns;
    
    /** @brief TSE降噪推理引擎 */
    std::shared_ptr<FaithInference> faith_inference_tse;
    
    /** @brief K2解码器推理引擎 */
    std::shared_ptr<FaithInference> faith_inference_decoder;
    
    /** @brief K2连接器推理引擎 */
    std::shared_ptr<FaithInference> faith_inference_joiner;

    /** @brief IVA多通道处理器指针 */
    class IvaProcessor* iva_processor_;

    /**
     * @brief IVA配置缓存结构体
     * 
     * 用于避免不必要的IVA重新初始化，提高多次处理的效率
     */
    struct IvaConfigCache {
        /** @brief 是否已初始化 */
        bool initialized;
        
        /** @brief 采样率 */
        int sample_rate;
        
        /** @brief 通道数 */
        int num_channels;
        
        /** @brief 窗口样本数 */
        int window_samples;
        
        /** @brief 目标索引 */
        int target_index;
        
        /** @brief 配置文件名 */
        std::string profile;

        /** @brief 默认构造函数 */
        IvaConfigCache() : initialized(false), sample_rate(0), num_channels(0),
                          window_samples(0), target_index(0) {}

        /**
         * @brief 检查配置是否匹配
         * @param config 待比较的IVA配置
         * @return 配置匹配返回true
         */
        bool matches(const struct IvaConfig& config) const {
            return initialized &&
                   sample_rate == config.sample_rate &&
                   num_channels == config.num_channels &&
                   window_samples == config.window_samples &&
                   target_index == config.target_index &&
                   profile == std::string(config.profile);
        }

        /**
         * @brief 更新缓存配置
         * @param config 新的IVA配置
         */
        void update(const struct IvaConfig& config) {
            initialized = true;
            sample_rate = config.sample_rate;
            num_channels = config.num_channels;
            window_samples = config.window_samples;
            target_index = config.target_index;
            profile = std::string(config.profile);
        }
    } iva_config_cache_;

    /**
     * @brief 内部处理函数
     * @param samples 音频样本数据
     * @param samples_size 样本数量
     * @param config 配置参数
     * @param results 检测结果
     * @param from_iva 是否来自IVA处理
     * @return 处理成功返回0
     */
    int ProcessInternal_(const short* samples, int samples_size, const KeywordSpotterConfig& config,
                         std::vector<KeywordResult>* results, bool from_iva);
    
    /**
     * @brief 输入数据预处理
     * @param samples 原始音频数据
     * @param samples_size 样本数量
     * @param cut_samples 预处理后的数据
     * @param config 配置参数
     * @param from_iva 是否来自IVA处理
     * @return 处理成功返回0
     */
    int PrepareInput_(const short* samples, int samples_size, float* cut_samples,
                     const KeywordSpotterConfig& config, bool from_iva = false);

    /**
     * @brief 运行E2E模型获取得分
     * @param samples 原始音频数据（16位有符号整数）
     * @param samples_size 样本数量
     * @return E2E得分，失败时返回0.0f
     */
    float RunE2EScore(const short* samples, int samples_size);
};

/**
 * @brief 保存IVA分离后的多通道音频文件
 * @param separated_sources 分离后的音频源数据
 * @param samples_per_channel 每通道样本数
 * @param sample_rate 采样率
 * @param output_dir 输出目录
 */
void SaveIvaSeparatedMergedWav(const std::vector<std::vector<float>>& separated_sources,
                              int samples_per_channel, int sample_rate, const std::string& output_dir);

/**
 * @brief 保存KWS输入的单通道音频文件
 * @param kws_channel KWS输入数据
 * @param samples_per_channel 样本数
 * @param sample_rate 采样率
 * @param output_dir 输出目录
 */
void SaveIvaKwsInputWav(const std::vector<float>& kws_channel,
                       int samples_per_channel, int sample_rate, const std::string& output_dir);

/**
 * @brief 保存IVA处理的原始文件
 * @param original_channels 原始通道数据
 * @param num_channels 通道数
 * @param samples_per_channel 每通道样本数
 * @param separated_sources 分离后的数据
 * @param output_dir 输出目录
 */
void SaveIvaRawFiles(const short* const* original_channels, int num_channels, int samples_per_channel,
                    const std::vector<std::vector<float>>& separated_sources, const std::string& output_dir);

/**
 * @brief 生成IVA处理报告
 * @param config 配置参数
 * @param kws_output KWS输出数据
 * @param separated_sources 分离后的数据
 * @param output_dir 输出目录
 */
void SaveIvaReport(const KeywordSpotterConfig& config, const std::vector<float>& kws_output,
                  const std::vector<std::vector<float>>& separated_sources, const std::string& output_dir);

}  // namespace kws2k2_faith

#endif