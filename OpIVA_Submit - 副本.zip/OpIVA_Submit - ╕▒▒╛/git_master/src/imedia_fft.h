#ifndef _IMEDIA_FFT_H_
#define _IMEDIA_FFT_H_

#include "imedia_typedef.h"

namespace kws2k2_faith {
extern IMEDIA_VOID iMedia_K2NS_common_FFT(IMEDIA_INT16 sFftOrder, IMEDIA_FLOAT32 *fftBuf);
extern IMEDIA_VOID iMedia_K2NS_common_IFFT(IMEDIA_INT16 sFftOrder, IMEDIA_FLOAT32 *fftBuf);

}  // namespace kws2k2_faith
#endif
