#ifndef FRONTEND_FEATURE_PIPELINE_H_
#define FRONTEND_FEATURE_PIPELINE_H_

#include <mutex>
#include <queue>
#include <string>
#include <vector>
#include "fbank.h"

const int MILLISECOND = 1000;
const int FRAMELENGTH = 32;
const int FRAMESHIFT = 16;

namespace kws2k2_faith {
    struct FeaturePipelineConfig {
        int num_bins;
        int sample_rate;
        int frame_length;
        int frame_shift;
        FeaturePipelineConfig(int num_bins, int sample_rate)
            : num_bins(num_bins), // 80 dim fbank
              sample_rate(sample_rate)
        {                                           // 16k sample rate
            frame_length = sample_rate / MILLISECOND * FRAMELENGTH; // frame length 32ms
            frame_shift = sample_rate / MILLISECOND * FRAMESHIFT;  // frame shift 16ms
        }
    };

    class FeaturePipeline {
    public:
        explicit FeaturePipeline(const FeaturePipelineConfig &config);
        ~FeaturePipeline() {}

        // The feature extraction is done in AcceptWaveform().
        std::vector<std::vector<float>> AcceptWaveform(const std::vector<float> &wav);

        // Current extracted frames number.
        int num_frames() const { return num_frames_; }
        int feature_dim() const { return feature_dim_; }
        const FeaturePipelineConfig &config() const { return config_; }

    private:
        const FeaturePipelineConfig &config_;
        int feature_dim_;
        Fbank fbank_;
        int num_frames_;
    };

} // namespace kws2k2_faith

#endif // FRONTEND_FEATURE_PIPELINE_H_
