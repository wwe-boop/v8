
#include <vector>
#include <fstream>
#include <iostream>
#include <sys/stat.h>
#include <cstring>
#include <iomanip>
#include <cmath>
#include <chrono>
#include <sstream>
#include "keyword-spotter.h"
#include "transducer-keyword-decoder.h"
#include "context-graph.h"
#include "utils.h"
#include "symbol-table.h"
#include "faith_api.h"
#include "online-feature.h"
#include "alg_log.h"
#include "noise-reduction.h"
#include "E2EProcessor.h"
#include "iva/iva_processor.h"

#define LOG_TAG "kws2k2:keyword_spotter"
#define LOG_EPS (-23.025850929940457)

namespace kws2k2_faith {

/**
 * @brief 从文件名提取音频前缀
 * @param filename 完整文件路径
 * @return 不含路径和扩展名的文件名
 */
std::string ExtractAudioPrefix(const std::string& filename) {
    size_t last_slash = filename.find_last_of("/\\");
    std::string basename = (last_slash != std::string::npos) ?
                          filename.substr(last_slash + 1) : filename;
    size_t last_dot = basename.find_last_of(".");
    return (last_dot != std::string::npos) ?
           basename.substr(0, last_dot) : basename;
}

/**
 * @brief 创建输出目录
 * @param audio_prefix 音频文件前缀名
 * @return 创建的输出目录路径
 */
std::string CreateOutputDirectory(const std::string& audio_prefix) {
    std::string output_dir = "output/" + audio_prefix;

    // Create output directory if it doesn't exist
    struct stat st = {0};
    if (stat("output", &st) == -1) {
        mkdir("output", 0755);
    }
    if (stat(output_dir.c_str(), &st) == -1) {
        mkdir(output_dir.c_str(), 0755);
    }

    return output_dir;
}

const int OUTPUT_SIZE = 1 * 56 * 320;
const int INPUT_SIZE = 1 * 230 * 80;
const int MONO_2S_SHORT_LEN = 32000;
const string VERSION_WAKE = "25021716";
const int KWS1_MASK = 7587831; // ASC2 for KWS1
const short STRUCT_INFO_VERSION = 11016;
const short BEGIN_PAD = 30;
const short END_PAD = 30;
const short FEATURE_PAD = 30;
const int FRAME_LEN = 200;
const int AUDIO_EFFECTIVE_LENGTH = 30;
const int FRAME_SAMPLE = 160;
const float SHORT_MAX = 32768.0;
const short FEATURE_DIM = 80;
const float NS_RATE = 0.7;
const float K2_THRES_HIGH = 0.7;
const float K2_THRES_LOW = 0.25;
const float E2E_THRES_HIGH = 0.99;
const float E2E_THRES_LOW = 0.2;
const int MELHIGHFREQ = -400;

// Helper function to save merged WAV file with all separated sources
void SaveMergedWavFile(const std::vector<std::vector<float>>& separated_sources,
                      int samples_per_channel, int sample_rate, const std::string& output_dir) {
    if (separated_sources.empty()) {
        ALG_LOGE("No separated sources to save");
        return;
    }

    int num_channels = separated_sources.size();
    std::string filename = output_dir + "/iva_separated_merged.wav";

    // Create output directory if it doesn't exist
    system(("mkdir -p " + output_dir).c_str());

    FILE* wav_file = fopen(filename.c_str(), "wb");
    if (!wav_file) {
        ALG_LOGE("Failed to create WAV file: %s", filename.c_str());
        return;
    }

    // WAV header
    struct {
        char riff[4] = {'R', 'I', 'F', 'F'};
        uint32_t file_size;
        char wave[4] = {'W', 'A', 'V', 'E'};
        char fmt[4] = {'f', 'm', 't', ' '};
        uint32_t fmt_size = 16;
        uint16_t audio_format = 1; // PCM
        uint16_t num_channels;
        uint32_t sample_rate;
        uint32_t byte_rate;
        uint16_t block_align;
        uint16_t bits_per_sample = 16;
        char data[4] = {'d', 'a', 't', 'a'};
        uint32_t data_size;
    } wav_header;

    wav_header.num_channels = num_channels;
    wav_header.sample_rate = sample_rate;
    wav_header.byte_rate = sample_rate * num_channels * 2; // 16-bit
    wav_header.block_align = num_channels * 2;
    wav_header.data_size = samples_per_channel * num_channels * 2;
    wav_header.file_size = 36 + wav_header.data_size;

    // Write header
    fwrite(&wav_header, sizeof(wav_header), 1, wav_file);

    // Write interleaved audio data
    for (int i = 0; i < samples_per_channel; ++i) {
        for (int ch = 0; ch < num_channels; ++ch) {
            float sample = separated_sources[ch][i];
            // Convert to 16-bit
            if (sample > 1.0f) sample = 1.0f;
            if (sample < -1.0f) sample = -1.0f;
            int16_t sample_16 = static_cast<int16_t>(sample * 32767.0f);
            fwrite(&sample_16, sizeof(sample_16), 1, wav_file);
        }
    }

    fclose(wav_file);

    ALG_LOGI("Saved merged WAV file: %s (%d channels, %d samples, %d Hz)",
             filename.c_str(), num_channels, samples_per_channel, sample_rate);
}

// Helper function to save KWS input WAV file (single channel)
void SaveKwsInputWavFile(const std::vector<float>& kws_channel,
                        int samples_per_channel, int sample_rate, const std::string& output_dir) {
    std::string filename = output_dir + "/iva_kws_input.wav";

    // Create output directory if it doesn't exist
    system(("mkdir -p " + output_dir).c_str());

    FILE* wav_file = fopen(filename.c_str(), "wb");
    if (!wav_file) {
        ALG_LOGE("Failed to create KWS input WAV file: %s", filename.c_str());
        return;
    }

    // WAV header for mono file
    struct {
        char riff[4] = {'R', 'I', 'F', 'F'};
        uint32_t file_size;
        char wave[4] = {'W', 'A', 'V', 'E'};
        char fmt[4] = {'f', 'm', 't', ' '};
        uint32_t fmt_size = 16;
        uint16_t audio_format = 1; // PCM
        uint16_t num_channels = 1; // Mono
        uint32_t sample_rate;
        uint32_t byte_rate;
        uint16_t block_align = 2; // 1 channel * 2 bytes
        uint16_t bits_per_sample = 16;
        char data[4] = {'d', 'a', 't', 'a'};
        uint32_t data_size;
    } wav_header;

    wav_header.sample_rate = sample_rate;
    wav_header.byte_rate = sample_rate * 2; // 16-bit mono
    wav_header.data_size = samples_per_channel * 2;
    wav_header.file_size = 36 + wav_header.data_size;

    // Write header
    fwrite(&wav_header, sizeof(wav_header), 1, wav_file);

    // Write audio data
    for (int i = 0; i < samples_per_channel; ++i) {
        float sample = kws_channel[i];
        // Convert to 16-bit
        if (sample > 1.0f) sample = 1.0f;
        if (sample < -1.0f) sample = -1.0f;
        int16_t sample_16 = static_cast<int16_t>(sample * 32767.0f);
        fwrite(&sample_16, sizeof(sample_16), 1, wav_file);
    }

    fclose(wav_file);

    ALG_LOGI("Saved KWS input WAV file: %s (mono, %d samples, %d Hz)",
             filename.c_str(), samples_per_channel, sample_rate);
}

/**
 * @brief 检查文件是否不存在
 * @param file 文件路径
 * @return 文件不存在返回true
 */
bool checkFileNonExists(const std::string file) {
    std::ifstream keywordsStream(file);
    if (!keywordsStream.is_open()) {
        ALG_LOGE("load resource %s failed\n", file.c_str());
        return true;
    }
    return false;
}

/**
 * @brief 端到端模型处理主体函数
 * @param config 配置参数
 * @param samples 音频样本数据
 * @param e2eScore 输出的端到端得分
 * @param encoder 端到端编码器
 * @return 处理成功返回0
 */
int E2EMainBody(const KeywordSpotterConfig &config, const short *samples, float *e2eScore, std::shared_ptr<FaithInference> encoder) {
    ALG_LOGI("E2EMainBody is coming\n");

    std::shared_ptr<E2EProcessor> mE2EProcessor;
    mE2EProcessor = std::make_shared<E2EProcessor>();
    if (!mE2EProcessor) {
        ALG_LOGE("mE2EProcessor malloc error");
        return -1;
    }

    mE2EProcessor->RecAudioForE2E(samples, MONO_2S_SHORT_LEN);
    *e2eScore = mE2EProcessor->E2EProcess(encoder);

    ALG_LOGI("E2EMainBody end\n");
    return 0;
}

/**
 * @brief 噪声抑制处理函数
 * @param config 配置参数
 * @param samples 输入音频样本
 * @param sample_len 输入样本长度
 * @param out 输出处理后的音频
 * @param out_len 输出缓冲区长度
 * @param isEchoScene 是否为回声场景
 * @param isLowSNR 输出是否为低信噪比
 * @param inferNs 噪声抑制推理引擎
 * @param inferTse TSE推理引擎
 * @return 处理成功返回0
 */
int NoiseReductionFuc(const KeywordSpotterConfig &config, const short *samples, int sample_len, short *out, 
                int out_len, int isEchoScene, int *isLowSNR, std::shared_ptr<FaithInference> inferNs, std::shared_ptr<FaithInference> inferTse) {
    if(sample_len < MONO_2S_SHORT_LEN || out_len < MONO_2S_SHORT_LEN) {
        return -1;
    }

    *isLowSNR = 0;
    if(isEchoScene == 0) { //仅在非回声场景下，判断SNR
        NoiseReduction ns;
        ns.Apply(samples, sample_len, out, MONO_2S_SHORT_LEN, inferNs, 1); // 1:sqrt
        ALG_LOGI("norm ns\n");
        //SNR
        float signal_power = 0;
        float noise_power = 0;
        for(int i=0; i<MONO_2S_SHORT_LEN; i++) {
            float s_power = out[i] * out[i];
            signal_power += s_power;
            noise_power += samples[i] * samples[i] - s_power;
        }
        float snr = 10 * log10(signal_power / (noise_power + 1e-10));
        ALG_LOGI("snr=%f\n", snr);
        if(snr < -12.0) {
            *isLowSNR = 1;
        }
    }
    if((0 != isEchoScene) || (0 == *isLowSNR)) { //回声场景 或 非低SNR场景
        NoiseReduction ns;
        ns.Apply(samples, sample_len, out, MONO_2S_SHORT_LEN, inferTse, 0);
        for (int i = 0; i < MONO_2S_SHORT_LEN; i++) {
            out[i] = NS_RATE * out[i] + (1 - NS_RATE) * samples[i];
        }
        ALG_LOGI("yoyo ns\n");
    }
    for(int i=0; i<sizeof(DspInfo);i++){ // 保留头信息
        out[i] = samples[i];
    }
    return 0;
}

/**
 * @brief 执行KWS和E2E融合判定逻辑
 * @param kwsScore KWS模型得分
 * @param e2eScore E2E模型得分
 * @return 融合判定结果：1表示唤醒，0表示未唤醒
 */
int PerformFusionDecision(float kwsScore, float e2eScore) {
    ALG_LOGI("Fusion decision: KWS=%.4f, E2E=%.4f", kwsScore, e2eScore);

    if (e2eScore >= E2E_THRES_HIGH) {
        ALG_LOGI("E2E wakeup (high threshold)");
        return 1;
    } else if (kwsScore >= K2_THRES_HIGH) {
        ALG_LOGI("KWS wakeup (high threshold)");
        return 1;
    } else if ((e2eScore < E2E_THRES_HIGH && e2eScore > E2E_THRES_LOW) &&
               (kwsScore < K2_THRES_HIGH && kwsScore > K2_THRES_LOW)) {
        ALG_LOGI("E2E & KWS wakeup (both in middle range)");
        return 1;
    }

    ALG_LOGI("No wakeup detected");
    return 0;
}

/**
 * @brief 获取最终检测结果（保持向后兼容）
 * @param e2eScore 端到端模型得分
 * @param results 检测结果向量
 */
void GetFinalRes(float e2eScore, std::vector<KeywordResult> *results) {
    float K2Score = (*results)[0].ys_prob;

    // 保存E2E分数到结果结构体中
    (*results)[0].e2e_score = e2eScore;

    ALG_LOGI("e2eScore : %f\n", e2eScore);
    ALG_LOGI("K2Score : %f\n", K2Score);

    int finalRes = PerformFusionDecision(K2Score, e2eScore);

    if (finalRes == 0) {
        (*results)[0].keyword.clear();
    } else if (finalRes == 1 && (*results)[0].keyword.empty()) {
        (*results)[0].keyword = "\u4f60\u597d\u60a0\u60a0";
        (*results)[0].timestamps.push_back(-1); // 10
        (*results)[0].timestamps.push_back(-1); // 195
        ALG_LOGI("E2E adds (*results)[0].keyword %s!!!\n", (*results)[0].keyword.c_str());
    }
}

std::string KeywordSpotterConfig::ToString() const
{
    std::ostringstream os;

    os << "KeywordSpotterConfig(";
    os << "max_active_paths=" << max_active_paths << ", ";
    os << "num_tailing_blanks=" << num_tailing_blanks << ", ";
    os << "keywords_score=" << keywords_score << ", ";
    os << "keywords_threshold=" << keywords_threshold << ", ";
    os << "lexiconPath=\"" << lexiconPath << "\"";

    // Only include IVA fields in output when IVA is enabled to maintain compatibility
    if (enable_iva) {
        os << ", enable_iva=" << (enable_iva ? "true" : "false") << ", ";
        os << "iva_num_channels=" << iva_num_channels << ", ";
        os << "iva_sample_rate=" << iva_sample_rate << ", ";
        os << "iva_window_samples=" << iva_window_samples << ", ";
        os << "iva_target_index=" << iva_target_index << ", ";
        os << "iva_profile=\"" << iva_profile << "\"";
    }

    os << ")";
    return os.str();
}
void KeywordSpotter::GetVersion() {
    ALG_LOGI("get version %s\n", VERSION_WAKE.c_str());
}

/**
 * @brief 获取回声场景标识
 * @param in 输入音频数据
 * @return 回声场景标识值
 */
int GetIsEchoScene(const short *in) {
    int isLocalEchoScene = 0;
    struct DspInfo *dspStruct = (struct DspInfo *)in;
    if (dspStruct->kws1Mask == KWS1_MASK && dspStruct->version == STRUCT_INFO_VERSION) {
        isLocalEchoScene = dspStruct->isEchoScene; // echo: 0,1,2
        if (isLocalEchoScene > 10 || isLocalEchoScene < 0) { // 校验
            ALG_LOGE("isLocalEchoScene is error = %d\n", isLocalEchoScene);
            isLocalEchoScene = 0;
        }
    } else {
        isLocalEchoScene = 0;
    }
    isLocalEchoScene = 0;
    ALG_LOGI("isEchoScene:%d\n", isLocalEchoScene);
    return isLocalEchoScene;
}

/**
 * @brief 音频样本切分函数
 * @param in 输入音频数据
 * @param in_size 输入数据大小
 * @param out 输出切分后的数据
 * @param out_size 输出数据大小
 * @return 处理成功返回0
 */
int CutSamples(const short *in, int in_size, float *out, int out_size)
{
    struct DspInfo *dspStruct = (struct DspInfo *)in;
    int i = 0;
    int cut_begin = 0;
    int cut_end = 0;
    int length = dspStruct->sentenceEnd - dspStruct->sentenceBegin;
    ALG_LOGI("begin:%d, end:%d\n", dspStruct->sentenceBegin, dspStruct->sentenceEnd);

    if ((dspStruct->sentenceBegin >= 0) && (dspStruct->sentenceEnd <= FRAME_LEN) && (length > AUDIO_EFFECTIVE_LENGTH)) {
        cut_begin = (dspStruct->sentenceBegin - BEGIN_PAD) * FRAME_SAMPLE;
        cut_end = (dspStruct->sentenceEnd + END_PAD) * FRAME_SAMPLE;
        cut_begin = (cut_begin > 0) ? cut_begin: 0;
        cut_end = (cut_end < MONO_2S_SHORT_LEN) ? cut_end:MONO_2S_SHORT_LEN;
        ALG_LOGI("cut_begin:%d, cut_end:%d\n", cut_begin, cut_end);
        for (i = cut_begin; i < cut_end; i++) {
            out[i] = in[i] / SHORT_MAX;
        }
    } else {
        int head_size = sizeof(DspInfo) / 2;
        ALG_LOGE("the begin or end in wave is out of range head_size: %d\n", head_size);
        for (i = head_size; i < MONO_2S_SHORT_LEN; i++) {
            out[i] = in[i] / SHORT_MAX;
        }
    }

    return 0;
}

int KeywordSpotter::KwsInit(const KeywordSpotterConfig &config)
{
#ifdef QUENTION
    const std::string encoder_modelPath = config.lexiconPath + "encoder_kws2k2_f16.bolt";
    const std::string e2e_encoder_modelPath = config.lexiconPath + "e2e_encoder_f16.bolt";
#else
    const std::string encoder_modelPath = config.lexiconPath + "encoder_kws2k2_f32.bolt";
    const std::string e2e_encoder_modelPath = config.lexiconPath + "e2e_encoder_f32.bolt";
#endif
    const std::string ns_modelPath = config.lexiconPath + "noise_reduction_f32.norm.bolt";
    const std::string tse_modelPath = config.lexiconPath + "noise_reduction_f32.bolt";
    const std::string decoder_modelPath = config.lexiconPath + "decoder_kws2k2_f32.bolt";
    const std::string joiner_modelPath = config.lexiconPath + "joiner_kws2k2_f32.bolt";

    bool check = checkFileNonExists(encoder_modelPath) || checkFileNonExists(e2e_encoder_modelPath)
                || checkFileNonExists(ns_modelPath) || checkFileNonExists(tse_modelPath) 
                || checkFileNonExists(decoder_modelPath) || checkFileNonExists(joiner_modelPath);
    if (check) {
        ALG_LOGE("load resource failed\n");
        return -1;
    }

    // K2 encoder:: 输入 (1, 230, 80), 输出(1,56,320)
    faith_inference_encoder = MakeSharedNoThrow<FaithInference>();
    if (faith_inference_encoder == nullptr) {
        ALG_LOGE("faith_inference_encoder MakeSharedNoThrow failed.");
        return -1;
    }
    int ret = 0;
    ret = faith_inference_encoder->InitModelEng(encoder_modelPath.c_str());
    if (ret != 0) {
        ALG_LOGE("encoder InitModel failed.\n");
        return -1;
    }

    // E2E encoder:: 输入 (1, 124, 512),(1, 512, 105) 输出(1, 124, 512),(1, 512, 105),
    faith_inference_e2e_encoder = MakeSharedNoThrow<FaithInference>();
    if (faith_inference_e2e_encoder == nullptr) {
        ALG_LOGE("faith_inference_e2e_encoder MakeSharedNoThrow failed.");
        return -1;
    }
    ret = faith_inference_e2e_encoder->InitModelEng(e2e_encoder_modelPath.c_str());
    if (ret != 0) {
        ALG_LOGE("E2E encoder InitModel failed.\n");
        return -1;
    }
    
    // noise reduction
    faith_inference_ns = MakeSharedNoThrow<FaithInference>();
    if (faith_inference_ns == nullptr) {
        ALG_LOGE("faith_inference_ns MakeSharedNoThrow failed.");
        return -1;
    }
    ret = faith_inference_ns->InitModelEng(ns_modelPath.c_str());
    if (ret != 0) {
        ALG_LOGE("ns InitModel failed.\n");
        return -1;
    }
    faith_inference_tse = MakeSharedNoThrow<FaithInference>();
    if (faith_inference_tse == nullptr) {
        ALG_LOGE("faith_inference_tse MakeSharedNoThrow failed.");
        return -1;
    }
    ret = faith_inference_tse->InitModelEng(tse_modelPath.c_str());
    if (ret != 0) {
        ALG_LOGE("tse InitModel failed.\n");
        return -1;
    }

    //K2 decoder：输入 (1, 1, 2) 输出(1,320)
    //K2 joiner:  输入 (1,1,320) cat (1,1,320) 输出(1,1,197)
    faith_inference_decoder = MakeSharedNoThrow<FaithInference>();
    if (faith_inference_decoder == nullptr) {
        ALG_LOGE("faith_inference_decoder MakeSharedNoThrow failed.");
        return -1;
    }
    ret = faith_inference_decoder->InitModelEng(decoder_modelPath.c_str());
    if (ret != 0) {
        ALG_LOGE("decoder InitModel failed.\n");
        return -1;
    }
    faith_inference_joiner = MakeSharedNoThrow<FaithInference>();
    if (faith_inference_joiner == nullptr) {
        ALG_LOGE("faith_inference_joiner MakeSharedNoThrow failed.");
        return -1;
    }
    ret = faith_inference_joiner->InitModelEng(joiner_modelPath.c_str());
    if (ret != 0) {
        ALG_LOGE("joiner InitModel failed.\n");
        return -1;
    }

    // Initialize IVA processor
    iva_processor_ = new IvaProcessor();
    if (!iva_processor_) {
        ALG_LOGE("Failed to create IVA processor");
        return -1;
    }

    return 0;
}

int KeywordSpotter::KwsDestory()
{
    int ret = faith_inference_encoder->DestroyModelEng();
    if (ret != 0) {
        ALG_LOGE("encoder DestroyModelEng failed.\n");
        return -1;
    }

    ret = faith_inference_e2e_encoder->DestroyModelEng();
    if (ret != 0) {
        ALG_LOGE("E2E encoder Destroy failed.\n");
        return -1;
    }

    ret = faith_inference_ns->DestroyModelEng();
    if (ret != 0) {
        ALG_LOGE("faith_inference_ns DestroyModelEng failed.\n");
        return -1;
    }

    ret = faith_inference_tse->DestroyModelEng();
    if (ret != 0) {
        ALG_LOGE("faith_inference_tse DestroyModelEng failed.\n");
        return -1;
    }

    ret = faith_inference_decoder->DestroyModelEng();
    if (ret != 0) {
        ALG_LOGE("decoder DestroyModelEng failed.\n");
        return -1;
    }

    ret = faith_inference_joiner->DestroyModelEng();
    if (ret != 0) {
        ALG_LOGE("joiner DestroyModelEng failed.\n");
        return -1;
    }

    // Cleanup IVA processor
    if (iva_processor_) {
        iva_processor_->Destroy();
        delete iva_processor_;
        iva_processor_ = nullptr;
    }

    return 0;
}

int KeywordSpotter::ProcessInternal_(const short *samples, int samples_size, const KeywordSpotterConfig &config,
                            std::vector<KeywordResult> *results, bool from_iva)
{
    int isEchoScene = 0;
    int isLowSNR = 0;
    ALG_LOGI("kws2k2 process begin\n");
    GetVersion();
    if (samples == NULL) {
        ALG_LOGE("samples is null\n");
        return -1;
    }
    if (samples_size < MONO_2S_SHORT_LEN) {
        ALG_LOGE("samples_size not equal 32000\n");
        return -1;
    }

    if (results == NULL) {
        ALG_LOGE("results is null\n");
        return -1;
    }
    ALG_LOGI("config: %s\n", config.ToString().c_str());
    int32_t ret = 0;
    
    float *cut_samples = new float[MONO_2S_SHORT_LEN](); // encoder out 复用

    // Use the extracted PrepareInput_ method (from_iva controls NR路径)
    ret = PrepareInput_(samples, samples_size, cut_samples, config, from_iva);
    if (ret != 0) {
        ALG_LOGE("PrepareInput_ failed\n");
        delete [] cut_samples;
        return -1;
    }

    // 特征提取
    kws2k2_faith::FbankOptions opts_;
    opts_.frame_opts.dither = 0;
    opts_.frame_opts.snip_edges = false;
    opts_.mel_opts.num_bins = FEATURE_DIM;
    opts_.mel_opts.high_freq = MELHIGHFREQ;

    std::unique_ptr<kws2k2_faith::OnlineFbank> fbank_(new kws2k2_faith::OnlineFbank(opts_));
    fbank_->AcceptWaveform(opts_.frame_opts.samp_freq, cut_samples, MONO_2S_SHORT_LEN);
    fbank_->InputFinished();
    int32_t n = fbank_->NumFramesReady();
    std::vector<float> features(n * FEATURE_DIM + FEATURE_PAD * FEATURE_DIM, LOG_EPS);
    float *p = features.data();

    for (int32_t i = 0; i != n; ++i) {
        const float *f = fbank_->GetFrame(i);
        if (f != nullptr) {
            std::copy(f, f + FEATURE_DIM, p);
            p += FEATURE_DIM;
        } else {
            ALG_LOGE("copy feature error.\n");
            delete [] cut_samples;
            return -1;
        }
    }
    
    ret = faith_inference_encoder->Compute(features, INPUT_SIZE, cut_samples, OUTPUT_SIZE);
    if (ret != 0) {
        ALG_LOGE("encoder Compute failed.\n");
        delete [] cut_samples;
        return -1;
    }

    const std::string keywords_file = config.lexiconPath + "nihaoyouyou.txt";
    const std::string token_file = config.lexiconPath + "tokens.txt";
    bool check = checkFileNonExists(keywords_file) || checkFileNonExists(token_file);
    if (check) {
        ALG_LOGE("load token_file failed\n");
        return -1;
    }

    // 解码图创建
    std::shared_ptr<ContextGraph> keywords_graph_;
    SymbolTable sym_(token_file);
    int32_t unk_id_ = sym_["<unk>"];  // 2

    // 配置输入格式：n ǐ h ǎo y ōu y ōu :1.5 #0.35 @你好悠悠
    // 其中分隔符 :分数boost_scores_(音素个数或者1个) #阈值thresholds_ @keywords_ $pinyins_
    std::vector<std::vector<int32_t>> keywords_id_;
    std::vector<std::vector<float>> boost_scores_;
    std::vector<std::string> keywords_;
    std::vector<std::string> pinyins_;
    std::vector<float> thresholds_;
    std::ifstream is(keywords_file.c_str());
    if (!EncodeKeywords(is, sym_, &keywords_id_, &keywords_, &pinyins_, &boost_scores_, &thresholds_)) {
        ALG_LOGE("Encode keywords failed.\n");
        delete [] cut_samples;
        return -1;
    }
    keywords_graph_ = std::make_shared<ContextGraph>(keywords_id_, config.keywords_score, config.keywords_threshold,
                                                     boost_scores_, keywords_, pinyins_, thresholds_);
    std::unique_ptr<TransducerKeywordDecoder> kws_decoder_;
    kws_decoder_ =
        std::unique_ptr<TransducerKeywordDecoder>(new TransducerKeywordDecoder(config.max_active_paths, config.num_tailing_blanks, unk_id_));

    std::vector<TransducerKeywordResult> res(1);

    ret = kws_decoder_->Decode(cut_samples, OUTPUT_SIZE, keywords_graph_, &res, faith_inference_decoder, faith_inference_joiner, isEchoScene);
    if (ret != 0) {
        ALG_LOGE("Decode failed.\n");
        delete [] cut_samples;
        return -1;
    }
    (*results)[0].tokens = res[0].tokens;
    (*results)[0].keyword = res[0].keyword;
    (*results)[0].ys_probs = res[0].ys_probs;
    (*results)[0].ys_prob = res[0].ys_prob;
    (*results)[0].timestamps = res[0].timestamps;
    // wakeup_result
    std::ostringstream os;
    os << "sorted_ans: tokens:";
    for (int idx = 0; idx < (*results)[0].tokens.size(); idx++) {
        os << (*results)[0].tokens[idx] << ", ";
    }
    os << "timestamps:";
    for (int idx = 0; idx < (*results)[0].timestamps.size(); idx++) {
        os << (*results)[0].timestamps[idx] << ", ";
    }
    os << "ys_probs:";
    for (int idx = 0; idx < (*results)[0].ys_probs.size(); idx++) {
        os << (*results)[0].ys_probs[idx] << ", ";
    }
    os << (*results)[0].keyword.c_str()<< ",";
    os << (*results)[0].ys_prob<< ", ";
    ALG_LOGI("%s\n", os.str().c_str());
    delete [] cut_samples;
    ALG_LOGI("kws2k2 process end\n");
    // e2e
    if (isEchoScene == 0) {
        float e2eScore = 0.0f;
        ret = E2EMainBody(config, samples, &e2eScore, faith_inference_e2e_encoder);
        if (ret) {
            ALG_LOGE("E2E process failed.");
            return -1;
        }
        GetFinalRes(e2eScore, results);
    }
    return 0;
}

int KeywordSpotter::Process(const short *samples, int samples_size, const KeywordSpotterConfig &config,
                            std::vector<KeywordResult> *results)
{
    return ProcessInternal_(samples, samples_size, config, results, /*from_iva=*/false);
}

int KeywordSpotter::ProcessMultiChannel(const short* const* samples_by_channel,
                                       int num_channels,
                                       int samples_per_channel,
                                       const KeywordSpotterConfig& config,
                                       std::vector<KeywordResult>* results) {
    ALG_LOGI("ProcessMultiChannel begin: channels=%d, samples=%d", num_channels, samples_per_channel);

    // Validate inputs
    if (!samples_by_channel || !results) {
        ALG_LOGE("Null pointer in ProcessMultiChannel");
        return -1;
    }

    if (samples_per_channel != MONO_2S_SHORT_LEN) {
        ALG_LOGE("Invalid samples_per_channel: %d, expected %d", samples_per_channel, MONO_2S_SHORT_LEN);
        return -1;
    }

    // Initialize result structure with default values
    (*results)[0].kws_keyword_first.clear();
    (*results)[0].kws_score_first = -1.0f;
    (*results)[0].e2e_score_first = -1.0f;
    (*results)[0].final_decision_first = -1;
    (*results)[0].kws_keyword_second.clear();
    (*results)[0].kws_score_second = -1.0f;
    (*results)[0].e2e_score_second = -1.0f;
    (*results)[0].final_decision_second = -1;
    (*results)[0].stage1_time_ms = -1.0;
    (*results)[0].stage2_time_ms = -1.0;

    // Set pipeline information
    (*results)[0].pipeline_id = "kws_e2e_iva_v1.0";
    (*results)[0].pipeline_spec = "single_ch_first_then_iva_fallback";

    // Build module flags based on configuration
    std::string module_flags = "KWS+E2E";
    if (config.enable_iva && num_channels >= 2) {
        module_flags += "+IVA";
    }
    (*results)[0].module_flags = module_flags;

    // Build comprehensive module parameters JSON
    std::ostringstream params_json;
    params_json << "{"
                << "\"k2_thres_high\":" << K2_THRES_HIGH
                << ",\"k2_thres_low\":" << K2_THRES_LOW
                << ",\"e2e_thres_high\":" << E2E_THRES_HIGH
                << ",\"e2e_thres_low\":" << E2E_THRES_LOW
                << ",\"max_active_paths\":" << config.max_active_paths
                << ",\"num_tailing_blanks\":" << config.num_tailing_blanks
                << ",\"keywords_score\":" << config.keywords_score
                << ",\"keywords_threshold\":" << config.keywords_threshold;
    if (config.enable_iva) {
        params_json << ",\"iva_enabled\":true"
                    << ",\"iva_target_index\":" << config.iva_target_index
                    << ",\"iva_sample_rate\":" << config.iva_sample_rate
                    << ",\"iva_window_samples\":" << config.iva_window_samples
                    << ",\"iva_profile\":\"" << config.iva_profile << "\"";
    } else {
        params_json << ",\"iva_enabled\":false";
    }
    params_json << ",\"num_channels\":" << num_channels
                << ",\"samples_per_channel\":" << samples_per_channel
                << "}";
    (*results)[0].module_params_json = params_json.str();

    // Step A: Try single-channel processing on first channel with full pipeline
    ALG_LOGI("Step A: Single-channel processing on channel 0");
    auto stage1_start = std::chrono::high_resolution_clock::now();

    int ret = Process(samples_by_channel[0], samples_per_channel, config, results);
    if (ret != 0) {
        ALG_LOGE("Single-channel processing failed");
        return -1;
    }

    auto stage1_end = std::chrono::high_resolution_clock::now();
    (*results)[0].stage1_time_ms = std::chrono::duration_cast<std::chrono::microseconds>(stage1_end - stage1_start).count() / 1000.0;

    // Record first attempt results
    (*results)[0].kws_keyword_first = (*results)[0].keyword;
    (*results)[0].kws_score_first = (*results)[0].ys_prob;
    (*results)[0].e2e_score_first = (*results)[0].e2e_score;
    int first_decision = !(*results)[0].keyword.empty() ? 1 : 0;
    (*results)[0].final_decision_first = first_decision;

    ALG_LOGI("First attempt: KWS=%.4f, E2E=%.4f, Decision=%d, Time=%.2fms",
             (*results)[0].kws_score_first, (*results)[0].e2e_score_first, first_decision, (*results)[0].stage1_time_ms);

    // If first attempt succeeded, return immediately
    if (first_decision == 1) {
        ALG_LOGI("First attempt succeeded, no need for IVA fallback");
        return 0;
    }

    // Step B: If no wakeup and IVA is enabled, try IVA fallback
    bool use_iva = config.enable_iva && num_channels >= 2;

    if (use_iva) {
        ALG_LOGI("Step B: IVA fallback processing");
        auto stage2_start = std::chrono::high_resolution_clock::now();

        // 强制固定使用第一个源（零基0）
        int forced_target_index = 0;
        ALG_LOGI("[KWS] input_source=IVA, force_use_source_index=%d (zero_based)", forced_target_index);

        // Prepare IVA configuration
        IvaConfig iva_config;
        iva_config.sample_rate = config.iva_sample_rate;
        iva_config.num_channels = num_channels;
        iva_config.window_samples = config.iva_window_samples;
        iva_config.target_index = forced_target_index;
        iva_config.profile = config.iva_profile.c_str();

        // Check if IVA processor needs (re)initialization
        bool need_init = !iva_config_cache_.matches(iva_config);

        if (need_init) {
            ALG_LOGI("IVA configuration changed, reinitializing processor");
            ALG_LOGI("New config: channels=%d, samples=%d, target=%d, rate=%d",
                    iva_config.num_channels, iva_config.window_samples,
                    iva_config.target_index, iva_config.sample_rate);

            if (iva_processor_->Init(iva_config) != 0) {
                ALG_LOGE("Failed to initialize IVA processor");
                return -1;
            }

            // Update cache
            iva_config_cache_.update(iva_config);
            ALG_LOGI("IVA processor initialized and cached");
        } else {
            ALG_LOGI("Reusing cached IVA processor configuration");

            // Even if configuration is the same, reset algorithm state for new file
            if (iva_processor_->Reset() != 0) {
                ALG_LOGE("Failed to reset IVA processor state");
                return -1;
            }
            ALG_LOGI("IVA processor state reset for new file");
        }

        std::vector<std::vector<double>> double_channels(num_channels);
        std::vector<const double*> double_channel_ptrs(num_channels);

        for (int ch = 0; ch < num_channels; ++ch) {
            double_channels[ch].resize(samples_per_channel);
            for (int i = 0; i < samples_per_channel; ++i) {
                double_channels[ch][i] = static_cast<double>(samples_by_channel[ch][i]) / 32768.0;
            }
            double_channel_ptrs[ch] = double_channels[ch].data();
        }

        // 执行 IVA，获取所有分离源和目标源
        std::vector<std::vector<double>> all_separated_sources(num_channels);
        std::vector<double*> separated_ptrs(num_channels);
        std::vector<double> iva_output(samples_per_channel);

        for (int ch = 0; ch < num_channels; ++ch) {
            all_separated_sources[ch].resize(samples_per_channel);
            separated_ptrs[ch] = all_separated_sources[ch].data();
        }

        if (iva_processor_->ProcessAllSources(double_channel_ptrs.data(), num_channels, samples_per_channel,
                                            separated_ptrs.data(), iva_output.data()) != 0) {
            ALG_LOGE("IVA processing failed");
            return -1;
        }

        // 保存IVA产物（如果提供了文件名）
        if (!config.current_audio_filename.empty()) {
            std::string audio_prefix = ExtractAudioPrefix(config.current_audio_filename);
            std::string output_dir = CreateOutputDirectory(audio_prefix);

            ALG_LOGI("Saving IVA artifacts to: %s/", output_dir.c_str());

            std::vector<std::vector<float>> float_separated_sources(num_channels);
            for (int ch = 0; ch < num_channels; ++ch) {
                float_separated_sources[ch].resize(samples_per_channel);
                for (int i = 0; i < samples_per_channel; ++i) {
                    float_separated_sources[ch][i] = static_cast<float>(all_separated_sources[ch][i]);
                }
            }

            // 保存所有分离源的合并WAV文件
            SaveIvaSeparatedMergedWav(float_separated_sources, samples_per_channel, 16000, output_dir);

            // 保存KWS输入WAV文件（目标源）
            std::vector<float> kws_channel_vec(samples_per_channel);
            for (int i = 0; i < samples_per_channel; ++i) {
                kws_channel_vec[i] = static_cast<float>(iva_output[i]);
            }
            SaveIvaKwsInputWav(kws_channel_vec, samples_per_channel, 16000, output_dir);

            // 保存RAW文件和报告
            SaveIvaRawFiles(samples_by_channel, num_channels, samples_per_channel,
                           float_separated_sources, output_dir);
            SaveIvaReport(config, kws_channel_vec, float_separated_sources, output_dir);
        }

        // 转回 short 格式以复用下游接口
        std::vector<short> short_output(samples_per_channel);
        for (int i = 0; i < samples_per_channel; ++i) {
            double sample = iva_output[i] * 32768.0;
            if (sample > 32767.0) sample = 32767.0;
            if (sample < -32768.0) sample = -32768.0;
            short_output[i] = static_cast<short>(sample);
        }

        // 走“IVA→降噪→特征→KWS”的路径
        // Run KWS-only on IVA separated source (no NR/echo detection)
        // Create a temporary result for second attempt
        std::vector<KeywordResult> second_results(1);
        ret = ProcessInternal_(short_output.data(), samples_per_channel, config, &second_results, /*from_iva=*/true);
        if (ret != 0) {
            ALG_LOGE("Second KWS attempt failed");
            return -1;
        }

        // Record second attempt results
        (*results)[0].kws_keyword_second = second_results[0].keyword;
        (*results)[0].kws_score_second = second_results[0].ys_prob;

        // E2E score reuses first attempt result (E2E always uses original ch0, no need to recalculate)
        float e2e_score_second = (*results)[0].e2e_score_first;
        (*results)[0].e2e_score_second = e2e_score_second;

        // Perform fusion decision for second attempt
        int second_decision = PerformFusionDecision((*results)[0].kws_score_second, e2e_score_second);
        (*results)[0].final_decision_second = second_decision;

        // Record stage 2 timing
        auto stage2_end = std::chrono::high_resolution_clock::now();
        (*results)[0].stage2_time_ms = std::chrono::duration_cast<std::chrono::microseconds>(stage2_end - stage2_start).count() / 1000.0;

        ALG_LOGI("Second attempt: KWS=%.4f, E2E=%.4f, Decision=%d, Time=%.2fms",
                 (*results)[0].kws_score_second, e2e_score_second, second_decision, (*results)[0].stage2_time_ms);

        // Update final result based on second attempt
        if (second_decision == 1) {
            (*results)[0].keyword = second_results[0].keyword.empty() ? "\u4f60\u597d\u60a0\u60a0" : second_results[0].keyword;
            (*results)[0].ys_prob = (*results)[0].kws_score_second;
            (*results)[0].e2e_score = e2e_score_second;
            (*results)[0].tokens = second_results[0].tokens;
            (*results)[0].timestamps = second_results[0].timestamps;
            (*results)[0].ys_probs = second_results[0].ys_probs;
            ALG_LOGI("Second attempt succeeded, updating final result");
        } else {
            ALG_LOGI("Second attempt also failed, no wakeup detected");
        }

        return 0;

    } else {
        ALG_LOGI("IVA not enabled or insufficient channels, using single-channel fallback");
        return 0;
    }
}

int KeywordSpotter::PrepareInput_(const short* samples, int samples_size, float* cut_samples,
                                 const KeywordSpotterConfig& config, bool from_iva) {
    int isEchoScene = 0;
    int isLowSNR = 0;

    if (!from_iva) {

        isEchoScene = GetIsEchoScene(samples);
        short *ns_samples = new short[MONO_2S_SHORT_LEN]();

        int ret = NoiseReductionFuc(config, samples, samples_size, ns_samples, MONO_2S_SHORT_LEN,
                                   isEchoScene, &isLowSNR, faith_inference_ns, faith_inference_tse);
        if (ret != 0) {
            delete [] ns_samples;
            return -1;
        }

        if(isEchoScene == 0){
            CutSamples(ns_samples, samples_size, cut_samples, MONO_2S_SHORT_LEN);
        } else {
            for(int i=sizeof(DspInfo); i<MONO_2S_SHORT_LEN; i++) {
                cut_samples[i] = ns_samples[i] / SHORT_MAX;
            }
        }
        delete [] ns_samples;
    } else {

        ALG_LOGI("Processing IVA output: skipping NR/echo detection, doing minimal conversion");
        for(int i = 0; i < MONO_2S_SHORT_LEN; i++) {
            cut_samples[i] = samples[i] / SHORT_MAX;
        }

        ALG_LOGI("IVA output converted to float format without NR processing");
    }

    return 0;
}

float KeywordSpotter::RunE2EScore(const short* samples, int samples_size) {
    if (!samples || samples_size < MONO_2S_SHORT_LEN) {
        ALG_LOGE("Invalid parameters for RunE2EScore");
        return 0.0f;
    }

    float e2eScore = 0.0f;
    int ret = E2EMainBody(KeywordSpotterConfig(), samples, &e2eScore, faith_inference_e2e_encoder);
    if (ret != 0) {
        ALG_LOGE("E2E processing failed in RunE2EScore");
        return 0.0f;
    }

    ALG_LOGI("RunE2EScore: %.4f", e2eScore);
    return e2eScore;
}

int KeywordSpotter::GetIvaStats(double* process_time_ms) {
    if (!iva_processor_) {
        ALG_LOGE("IVA processor not initialized");
        return -1;
    }

    return iva_processor_->GetStats(process_time_ms, nullptr, 0, nullptr, nullptr);
}

//IVA分阶段耗时间
int KeywordSpotter::GetIvaDetailedStats(double* total_ms,
                                        double* convert_input_ms,
                                        double* stft_forward_ms,
                                        double* auxiva_ms,
                                        double* stft_inverse_ms,
                                        double* copy_outputs_ms) {
    if (!iva_processor_) {
        ALG_LOGE("IVA processor not initialized");
        return -1;
    }
    return iva_processor_->GetDetailedStats(total_ms, convert_input_ms, stft_forward_ms, auxiva_ms, stft_inverse_ms, copy_outputs_ms);
}



void SaveIvaSeparatedMergedWav(const std::vector<std::vector<float>>& separated_sources,
                              int samples_per_channel, int sample_rate, const std::string& output_dir) {
    if (separated_sources.empty()) return;

    std::string filename = output_dir + "/iva_separated_merged.wav";
    std::ofstream file(filename, std::ios::binary);
    if (!file.is_open()) {
        ALG_LOGE("Cannot create file: %s", filename.c_str());
        return;
    }

    int num_channels = separated_sources.size();

    // WAV header
    struct {
        char riff[4] = {'R', 'I', 'F', 'F'};
        uint32_t chunk_size;
        char wave[4] = {'W', 'A', 'V', 'E'};
        char fmt[4] = {'f', 'm', 't', ' '};
        uint32_t fmt_size = 16;
        uint16_t audio_format = 1; // PCM
        uint16_t num_channels_hdr;
        uint32_t sample_rate_hdr;
        uint32_t byte_rate;
        uint16_t block_align;
        uint16_t bits_per_sample = 16;
        char data[4] = {'d', 'a', 't', 'a'};
        uint32_t data_size;
    } header;

    header.num_channels_hdr = num_channels;
    header.sample_rate_hdr = sample_rate;
    header.block_align = num_channels * 2;
    header.byte_rate = sample_rate * header.block_align;
    header.data_size = samples_per_channel * num_channels * 2;
    header.chunk_size = 36 + header.data_size;

    file.write(reinterpret_cast<const char*>(&header), sizeof(header));

    // 写入交错音频数据
    for (int i = 0; i < samples_per_channel; i++) {
        for (int ch = 0; ch < num_channels; ch++) {
            float sample = separated_sources[ch][i];
            if (sample > 1.0f) sample = 1.0f;
            if (sample < -1.0f) sample = -1.0f;
            int16_t sample_16 = static_cast<int16_t>(sample * 32767.0f);
            file.write(reinterpret_cast<const char*>(&sample_16), sizeof(sample_16));
        }
    }

    file.close();
    ALG_LOGI("Saved: %s", filename.c_str());
}

void SaveIvaKwsInputWav(const std::vector<float>& kws_channel,
                       int samples_per_channel, int sample_rate, const std::string& output_dir) {
    std::string filename = output_dir + "/iva_kws_input.wav";
    std::ofstream file(filename, std::ios::binary);
    if (!file.is_open()) {
        ALG_LOGE("Cannot create file: %s", filename.c_str());
        return;
    }

    // WAV header (单声道)
    struct {
        char riff[4] = {'R', 'I', 'F', 'F'};
        uint32_t chunk_size;
        char wave[4] = {'W', 'A', 'V', 'E'};
        char fmt[4] = {'f', 'm', 't', ' '};
        uint32_t fmt_size = 16;
        uint16_t audio_format = 1; // PCM
        uint16_t num_channels = 1;
        uint32_t sample_rate_hdr;
        uint32_t byte_rate;
        uint16_t block_align = 2;
        uint16_t bits_per_sample = 16;
        char data[4] = {'d', 'a', 't', 'a'};
        uint32_t data_size;
    } header;

    header.sample_rate_hdr = sample_rate;
    header.byte_rate = sample_rate * 2;
    header.data_size = samples_per_channel * 2;
    header.chunk_size = 36 + header.data_size;

    file.write(reinterpret_cast<const char*>(&header), sizeof(header));

    // 写入音频数据
    for (int i = 0; i < samples_per_channel; i++) {
        float sample = kws_channel[i];
        if (sample > 1.0f) sample = 1.0f;
        if (sample < -1.0f) sample = -1.0f;
        int16_t sample_16 = static_cast<int16_t>(sample * 32767.0f);
        file.write(reinterpret_cast<const char*>(&sample_16), sizeof(sample_16));
    }

    file.close();
    ALG_LOGI("Saved: %s", filename.c_str());
}

void SaveIvaRawFiles(const short* const* original_channels, int num_channels, int samples_per_channel,
                    const std::vector<std::vector<float>>& separated_sources, const std::string& output_dir) {
    // 保存分离结果RAW文件
    if (!separated_sources.empty()) {
        std::string separated_file = output_dir + "/iva_separated.raw";
        std::ofstream file(separated_file, std::ios::binary);
        if (file.is_open()) {
            for (int i = 0; i < samples_per_channel; i++) {
                float sample = separated_sources[0][i]; // 使用第一路分离源
                if (sample > 1.0f) sample = 1.0f;
                if (sample < -1.0f) sample = -1.0f;
                int16_t sample_16 = static_cast<int16_t>(sample * 32767.0f);
                file.write(reinterpret_cast<const char*>(&sample_16), sizeof(sample_16));
            }
            file.close();
            ALG_LOGI("Saved: %s", separated_file.c_str());
        }
    }

    // 保存原始声道RAW文件（如果是双通道）
    if (num_channels >= 2) {
        // 原始左声道
        std::string left_file = output_dir + "/original_left.raw";
        std::ofstream left_stream(left_file, std::ios::binary);
        if (left_stream.is_open()) {
            left_stream.write(reinterpret_cast<const char*>(original_channels[0]),
                            samples_per_channel * sizeof(short));
            left_stream.close();
            ALG_LOGI("Saved: %s", left_file.c_str());
        }

        // 原始右声道
        std::string right_file = output_dir + "/original_right.raw";
        std::ofstream right_stream(right_file, std::ios::binary);
        if (right_stream.is_open()) {
            right_stream.write(reinterpret_cast<const char*>(original_channels[1]),
                             samples_per_channel * sizeof(short));
            right_stream.close();
            ALG_LOGI("Saved: %s", right_file.c_str());
        }
    }
}

void SaveIvaReport(const KeywordSpotterConfig& config, const std::vector<float>& kws_output,
                  const std::vector<std::vector<float>>& separated_sources, const std::string& output_dir) {
    std::string report_file = output_dir + "/iva_report.txt";
    std::ofstream file(report_file);
    if (!file.is_open()) {
        ALG_LOGE("Cannot create report file: %s", report_file.c_str());
        return;
    }

    // 计算统计信息
    double kws_rms = 0.0;
    for (float sample : kws_output) {
        kws_rms += sample * sample;
    }
    kws_rms = sqrt(kws_rms / kws_output.size());

    std::vector<double> source_energies(separated_sources.size());
    for (int ch = 0; ch < separated_sources.size(); ch++) {
        source_energies[ch] = 0.0;
        for (float sample : separated_sources[ch]) {
            source_energies[ch] += sample * sample;
        }
    }

    file << "IVA 处理报告\n";
    file << "=============\n\n";
    file << "配置参数:\n";
    file << "- 启用IVA: " << (config.enable_iva ? "是" : "否") << "\n";
    file << "- 通道数: " << config.iva_num_channels << "\n";
    file << "- 目标源索引: " << config.iva_target_index << " (零基索引)\n";
    file << "- 采样率: " << config.iva_sample_rate << " Hz\n";
    file << "- 窗口大小: " << config.iva_window_samples << " 样本\n";
    file << "- 配置文件: " << config.iva_profile << "\n\n";

    file << "输出统计:\n";
    file << "- KWS输入RMS: " << std::fixed << std::setprecision(6) << kws_rms << "\n";
    for (int ch = 0; ch < source_energies.size(); ch++) {
        file << "- 分离源" << ch << "能量: " << std::scientific << std::setprecision(3) << source_energies[ch] << "\n";
    }

    file << "\n产物文件:\n";
    file << "- iva_separated_merged.wav: 所有分离源的合并WAV文件\n";
    file << "- iva_kws_input.wav: KWS输入WAV文件（目标源）\n";
    file << "- iva_separated.raw: 分离后的目标源RAW文件\n";
    file << "- original_left.raw: 原始左声道RAW文件\n";
    file << "- original_right.raw: 原始右声道RAW文件\n";
    file << "- iva_report.txt: 本报告文件\n";

    file.close();
    ALG_LOGI("Saved: %s", report_file.c_str());
}

}  // namespace kws2k2_faith