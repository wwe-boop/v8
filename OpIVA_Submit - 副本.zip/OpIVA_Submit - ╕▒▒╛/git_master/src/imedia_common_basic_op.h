
#ifndef _IMEDIA_COMMON_BASIC_OP_H_
#define _IMEDIA_COMMON_BASIC_OP_H_

#include "imedia_typedef.h"

namespace kws2k2_faith {

/******************************************************************************
Function:      iMedia_sinf_c
Description:   浮点正弦函数
Input:         x : 弧度制角度
Output:        无
Return:        r = sin(x)
 *******************************************************************************/
extern IMEDIA_FLOAT32 iMedia_sinf_c(IMEDIA_FLOAT32 fVarin);

/******************************************************************************
Function:      iMedia_cosf_c
Description:   浮点余弦函数
Input:         x : 弧度制角度
Output:        无
Return:        r = cos(x)
 *******************************************************************************/
extern IMEDIA_FLOAT32 iMedia_cosf_c(IMEDIA_FLOAT32 fVarin);

/******************************************************************************
Function:       iMedia_atanf_c
Description:    浮点反正切函数
Input:          x: 弧度制角度
Output:         无
Return:         r = atanf_c(x)
 *******************************************************************************/
extern IMEDIA_FLOAT32 iMedia_atanf_c(IMEDIA_FLOAT32 fVarin);

/******************************************************************************
Function:      iMedia_fabsf_c
Description:   浮点绝对值函数
Input:         x : 浮点数
Output:        无
Return:        r = |x|
 *******************************************************************************/
extern IMEDIA_FLOAT32 iMedia_fabsf_c(IMEDIA_FLOAT32 fVarin);

}  // namespace kws2k2_faith
#endif
