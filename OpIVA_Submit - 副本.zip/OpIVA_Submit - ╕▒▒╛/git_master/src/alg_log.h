#ifndef _KWS2K2_ALG_LOG_H_
#define _KWS2K2_ALG_LOG_H_

// Logging levels:
// 0 = no logs
// 1 = errors only
// 2 = info/debug and errors
#ifndef ALG_LOG_LEVEL
#define ALG_LOG_LEVEL 1
#endif

#if 0
//#if defined(ANDROID) || defined(_ANDROID_) || defined(__ANDROID__)
  #include <android/log.h>
  #if ALG_LOG_LEVEL >= 2
    #define ALG_LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
    #define ALG_LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)
  #else
    #define ALG_LOGI(...) ((void)0)
    #define ALG_LOGD(...) ((void)0)
  #endif
  #if ALG_LOG_LEVEL >= 1
    #define ALG_LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
  #else
    #define ALG_LOGE(...) ((void)0)
  #endif
#else
  #include <stdio.h>
  #if ALG_LOG_LEVEL >= 2
    #define ALG_LOGI(...) printf(__VA_ARGS__)
    #define ALG_LOGD(...) printf(__VA_ARGS__)
  #else
    #define ALG_LOGI(...) ((void)0)
    #define ALG_LOGD(...) ((void)0)
  #endif
  #if ALG_LOG_LEVEL >= 1
    #define ALG_LOGE(...) printf(__VA_ARGS__)
  #else
    #define ALG_LOGE(...) ((void)0)
  #endif
#endif

#endif
