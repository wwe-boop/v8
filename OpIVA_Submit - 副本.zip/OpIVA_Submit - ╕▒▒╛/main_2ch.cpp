
#include <stdio.h>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <string.h>
#include <time.h>
#include <chrono>
#include <sys/stat.h>
#include <cstring>
#include <errno.h>
#include <unistd.h>
#include <dirent.h>
#include "git_master/src/keyword-spotter.h"

const int MONO_2S_SHORT_LEN = 32000;
const int FRAME_LEN = 200;  
using namespace kws2k2_faith;

int fsize(FILE *fp){
    int n;
    fpos_t fpos; //当前位置
    fgetpos(fp, &fpos); //获取当前位置
    fseek(fp, 0, SEEK_END);
    n = ftell(fp);
    fsetpos(fp,&fpos); //恢复之前的位置
    return n;
}

int remove_wav_header(FILE *file_wav) {
    int i;
    int headsize;
    char data[256];
    int numChan;
    fread(data, sizeof(char), sizeof(data), file_wav);
    //非pcm文件
    if (strncmp(data, "RIFF", 4) != 0 || strncmp(data + 8, "WAVEfmt", 7) != 0) {
        printf("ERROR: Not a valid WAV file\n");
        return 0;
    }

    numChan = ((short*)data)[11];
    printf("numChan=%d\n", numChan);

    //查找data标志
    for (i = 0; i < sizeof(data) - 4; i++) {
        if ('d' == data[i] && 'a' == data[i + 1] && 't' == data[i + 2] && 'a' == data[i + 3]) {
            break;
        }
    }
    if (i >= sizeof(data) - 1) {
        printf("错误：wav头中未找到data字节\n");
        return -1;
    }
    headsize = i;
    headsize += 4; // data
    headsize += 4; // len



    //跳过wav文件头
    fseek(file_wav, headsize, SEEK_SET);
    return numChan;
}

char TEST_LIST_FILE[512] = "./test_file.txt";

// Create artifacts directory if it doesn't exist
void ensure_artifacts_dir() {
    struct stat st = {0};
    if (stat("artifacts", &st) == -1) {
        mkdir("artifacts", 0700);
    }
}

int main(int32_t argc, char *argv[]) {
    if (argc > 1) {
        memset(TEST_LIST_FILE, 0, sizeof(TEST_LIST_FILE));
        memcpy(TEST_LIST_FILE, argv[1], strlen(argv[1]));
    }

    // Initialize CSV metrics file with simplified format
    ensure_artifacts_dir();
    std::ofstream csv_file("artifacts/kws_metrics.csv");
    csv_file << "filename,num_channels,result,kws_score_first,e2e_score_first,final_decision_first,kws_score_second,final_decision_second,detected_keyword,total_time_ms,iva_time_ms,iva_convert_ms,iva_stft_fwd_ms,iva_auxiva_ms,iva_stft_inv_ms,iva_copy_ms" << "\n";
    csv_file.close();

    // Initialize KeywordSpotter once for all files
    const std::string lexiconPath = "git_master/model/";
    KeywordSpotterConfig config(10, 8, 1.0, 0.1, lexiconPath);
    config.enable_iva = true;
    config.iva_num_channels = 2;
    config.iva_target_index = 0;
    config.iva_sample_rate = 16000;
    config.iva_window_samples = 32000;
    config.iva_profile = "default";

    KeywordSpotter keyword_spotter;
    int ret = keyword_spotter.KwsInit(config);
    if (ret != 0) {
        printf("kws2k2 init err\n");
        return -1;
    }

    // 读测试序列
    char cmdString[300];
    char wav_filename[1024];
    short in_short[32000*2] = { 0 };
    short in_short_L[32000] = { 0 };
    short in_short_R[32000] = { 0 };
    std::string filename;
    int length = 0;
    int cnt_success = 0;
    int cnt = 0;
    int numChan = 0;
    FILE *testList = fopen(TEST_LIST_FILE, "r");
    if (0 == testList) {
        printf("can not open list file:%s!\n", TEST_LIST_FILE);
        return -1;
    }
    while (!feof(testList)) {
        if (0 == fgets(cmdString, sizeof(cmdString) - 1, testList)) {
            break;
        }
        if (cmdString[0] == '#') {
            break;
        }
        ret = sscanf(cmdString, "%[^\n]", wav_filename);

        // 清理文件名中的空格和控制字符
        char* end = wav_filename + strlen(wav_filename) - 1;
        while (end >= wav_filename && (*end == ' ' || *end == '\t' || *end == '\r' || *end == '\n')) {
            *end = '\0';
            end--;
        }

        printf("%s\n", wav_filename);
        printf("Cleaned filename: '%s' (length: %zu)\n", wav_filename, strlen(wav_filename));
        filename = wav_filename;

        


        // 尝试打开文件
        printf("Calling fopen() with mode 'rb'...\n");
        errno = 0;  // 清除之前的错误
        FILE* fp = fopen(wav_filename, "rb");  // 使用二进制模式

        if (fp != nullptr) {
            printf("SUCCESS: File opened successfully: %s\n", wav_filename);
            printf("File pointer: %p\n", (void*)fp);

            // 获取文件描述符信息
            int fd = fileno(fp);
            printf("File descriptor: %d\n", fd);

            // 尝试读取文件大小
            fseek(fp, 0, SEEK_END);
            long file_size = ftell(fp);
            fseek(fp, 0, SEEK_SET);
            printf("File size from ftell(): %ld bytes\n", file_size);
            length = fsize(fp);
            if (filename.find(".wav") != std::string::npos) {
                //fread(in_short, 22, sizeof(short), fp);
                numChan = remove_wav_header(fp);
                printf("WAV file detected, channels: %d\n", numChan);
                fread(in_short, MONO_2S_SHORT_LEN*2, sizeof(short), fp);
                for(int i=0; i<MONO_2S_SHORT_LEN; i++){
                    in_short_L[i] = in_short[i*2];
                    in_short_R[i] = in_short[i*2+1];
                }
            }else{
                // PCM 文件格式检测：根据文件大小判断是单通道还是双通道
                if (file_size == MONO_2S_SHORT_LEN * 2 * sizeof(short)) {
                    // 双通道交织格式
                    printf("PCM file detected, 2-channel (interleaved)\n");
                    numChan = 2;
                    size_t items_read = fread(in_short, sizeof(short), MONO_2S_SHORT_LEN*2, fp);
                    if (items_read != MONO_2S_SHORT_LEN*2) {
                        printf("WARNING: PCM read total samples = %zu (expected %d)\n", items_read, MONO_2S_SHORT_LEN*2);
                    }
                    for(int i=0; i<MONO_2S_SHORT_LEN; i++){
                        in_short_L[i] = in_short[i*2];
                        in_short_R[i] = in_short[i*2+1];
                    }
                } else if (file_size == MONO_2S_SHORT_LEN * sizeof(short)) {
                    // 单通道格式
                    printf("PCM file detected, 1-channel (mono)\n");
                    numChan = 1;
                    size_t items_read = fread(in_short_L, sizeof(short), MONO_2S_SHORT_LEN, fp);
                    if (items_read != MONO_2S_SHORT_LEN) {
                        printf("WARNING: PCM read samples = %zu (expected %d)\n", items_read, MONO_2S_SHORT_LEN);
                    }
                    // 复制到右声道（或者可以置零）
                    for(int i=0; i<MONO_2S_SHORT_LEN; i++){
                        in_short_R[i] = in_short_L[i];  // 单声道复制到双声道
                    }
                } else {
                    printf("WARNING: Unknown PCM format, file size = %ld bytes\n", file_size);
                    printf("Expected: %d bytes (mono) or %d bytes (stereo)\n",
                           MONO_2S_SHORT_LEN * (int)sizeof(short),
                           MONO_2S_SHORT_LEN * 2 * (int)sizeof(short));
                    // 尝试按单通道读取
                    numChan = 1;
                    size_t max_samples = file_size / sizeof(short);
                    if (max_samples > MONO_2S_SHORT_LEN) max_samples = MONO_2S_SHORT_LEN;
                    size_t items_read = fread(in_short_L, sizeof(short), max_samples, fp);
                    printf("Read %zu samples from unknown format file\n", items_read);
                    for(int i=0; i<MONO_2S_SHORT_LEN; i++){
                        in_short_R[i] = (i < items_read) ? in_short_L[i] : 0;
                    }
                }
            }
            fclose(fp);
            printf("Successfully loaded file: %s, channels: %d, length: %d\n", wav_filename, numChan, length);
        } else {
            printf("FAILED: Cannot open file: %s\n", wav_filename);
            printf("fopen() returned NULL\n");
            printf("errno: %d (%s)\n", errno, strerror(errno));
            perror("fopen failed");

          
            // 尝试打开父目录并列出内容
            char parent_dir[1024];
            strncpy(parent_dir, wav_filename, sizeof(parent_dir) - 1);
            parent_dir[sizeof(parent_dir) - 1] = '\0';
            char* last_slash = strrchr(parent_dir, '/');
            if (last_slash != NULL) {
                *last_slash = '\0';
                printf("  Trying to open parent directory: %s\n", parent_dir);
                DIR* dir = opendir(parent_dir);
                if (dir != NULL) {
                    printf("  Parent directory opened successfully, listing contents:\n");
                    struct dirent* entry;
                    int file_count = 0;
                    while ((entry = readdir(dir)) != NULL) {
                        printf("    [%d] %s (type: %d)\n", file_count++, entry->d_name, entry->d_type);

                        // 检查是否是我们要找的文件
                        if (strcmp(entry->d_name, "long1.pcm") == 0) {
                            printf("    *** Found target file: long1.pcm ***\n");

                            // 尝试构建完整路径并测试
                            char full_path[1024];
                            snprintf(full_path, sizeof(full_path), "%s/%s", parent_dir, entry->d_name);
                            printf("    Testing full path: %s\n", full_path);

                            struct stat test_stat;
                            if (stat(full_path, &test_stat) == 0) {
                                printf("    SUCCESS: stat() works with full path!\n");
                                printf("    File size: %ld bytes\n", test_stat.st_size);
                            } else {
                                printf("    FAILED: stat() still fails with full path, errno: %d\n", errno);
                            }

                            // 尝试用完整路径打开文件
                            FILE* test_fp = fopen(full_path, "rb");
                            if (test_fp != NULL) {
                                printf("    SUCCESS: fopen() works with full path!\n");
                                fclose(test_fp);
                            } else {
                                printf("    FAILED: fopen() still fails with full path, errno: %d\n", errno);
                            }
                        }
                    }
                    printf("  Total files in directory: %d\n", file_count);
                    closedir(dir);
                } else {
                    printf("  Cannot open parent directory, errno: %d (%s)\n", errno, strerror(errno));
                }
            }
            numChan = 0;  // 确保失败时numChan为0

            // 记录失败的文件到CSV - 修复格式问题
            std::ofstream csv_file("artifacts/kws_metrics.csv", std::ios::app);
            csv_file << wav_filename << ",0,0,NA,NA,NA,NA,NA,NA,0.0,0.0\n";
            csv_file.close();

            continue;  // 跳过这个文件，继续处理下一个
        }

        // High precision timing for performance metrics
        auto start_time = std::chrono::high_resolution_clock::now();

        config.current_audio_filename = wav_filename;  // 设置当前音频文件名，用于输出目录创建
        std::vector<KeywordResult> results(1); // 输出

        printf("%s\n",config.ToString().c_str());
        cnt++;
        if(numChan==2){
            // Option 1: Use new ProcessMultiChannel API with IVA (if enabled)
            // Prepare channel pointers for multi-channel processing
            const short* channels[2] = {in_short_L, in_short_R};
            ret = keyword_spotter.ProcessMultiChannel(channels, 2, 32000, config, &results);

            // Option 2: Fallback to original single-channel processing (commented out)
            // ret = keyword_spotter.Process(in_short_L, 32000, config, &results);
        }else{
            ret  = keyword_spotter.Process(in_short, 32000, config, &results);
        }
        if (ret != 0) {
            printf("kws2k2 Process err\n");
        }

        // Calculate processing time
        auto end_time = std::chrono::high_resolution_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end_time - start_time);
        double process_time_ms = duration.count() / 1000.0;

        // Get IVA processing time if available 
        double iva_time_ms = 0.0;
        if (config.enable_iva) {
            // Check if IVA was actually used for this file
            if (numChan == 1) {
                // Single-channel files never use IVA processing
                iva_time_ms = 0.0;
            } else if (numChan == 2 && results[0].final_decision_first == 1) {
                // Multi-channel file: first attempt succeeded, no IVA processing was done
                iva_time_ms = 0.0;
            } else if (numChan == 2) {
                // Multi-channel file: IVA processing was performed, get the stats
                if (keyword_spotter.GetIvaStats(&iva_time_ms) != 0) {
                    // Failed to get IVA stats, set to 0
                    iva_time_ms = 0.0;
                }
            } else {
                // Unknown channel configuration, set to 0
                iva_time_ms = 0.0;
            }
        }

        int res = 0;
        printf("zxw 0113 results[0].keyword === %s\n", results[0].keyword.c_str());
        if (!results[0].keyword.empty()) {
            cnt_success++;
            res = 1;
#if 0
            char fn[300], *p, out_pcm[256]="out_pcm/";
            strcpy(fn, (p = strrchr(wav_filename, '/')) ? p + 1 : wav_filename); //去除路径的文件名
            strcat(out_pcm, fn);
            printf("out:%s\n", out_pcm);
            FILE *fpWrite = fopen(out_pcm,"wb");
            fwrite(in_short, 32000, 2, fpWrite);
            fclose(fpWrite);
#endif
        }

        // Record simplified metrics to CSV
        std::ofstream csv_file("artifacts/kws_metrics.csv", std::ios::app);
        csv_file << std::fixed << std::setprecision(4);

        // CSV format: filename,num_channels,result,kws_score_first,e2e_score_first,final_decision_first,kws_score_second,final_decision_second,detected_keyword,total_time_ms,iva_time_ms,iva_convert_ms,iva_stft_fwd_ms,iva_auxiva_ms,iva_stft_inv_ms,iva_copy_ms
        double d_total=0, d_conv=0, d_fwd=0, d_aux=0, d_inv=0, d_copy=0;
        if (config.enable_iva && numChan==2 && results[0].final_decision_first!=1) {
            // fetch detailed stats only when IVA actually ran
            KeywordSpotter* self = &keyword_spotter; // in this scope keyword_spotter exists
            if (self) {
                self->GetIvaDetailedStats(&d_total, &d_conv, &d_fwd, &d_aux, &d_inv, &d_copy);
            }
        }

        csv_file << wav_filename << ","
                 << numChan << ","
                 << res << ","
                 << (results[0].kws_score_first >= 0 ? std::to_string(results[0].kws_score_first) : "NA") << ","
                 << (results[0].e2e_score_first >= 0 ? std::to_string(results[0].e2e_score_first) : "NA") << ","
                 << (results[0].final_decision_first >= 0 ? std::to_string(results[0].final_decision_first) : "NA") << ","
                 << (results[0].kws_score_second >= 0 ? std::to_string(results[0].kws_score_second) : "NA") << ","
                 << (results[0].final_decision_second >= 0 ? std::to_string(results[0].final_decision_second) : "NA") << ","
                 << (results[0].keyword.empty() ? "NA" : results[0].keyword) << ","
                 << process_time_ms << ","
                 << (config.enable_iva ? iva_time_ms : 0.0) << ","
                 << (config.enable_iva ? d_conv : 0.0) << ","
                 << (config.enable_iva ? d_fwd : 0.0) << ","
                 << (config.enable_iva ? d_aux : 0.0) << ","
                 << (config.enable_iva ? d_inv : 0.0) << ","
                 << (config.enable_iva ? d_copy : 0.0) << "\n";

        csv_file.close();

        printf("use time: %.2f ms, cnt_success=%d\n", process_time_ms, cnt_success);
        printf("wav_filename:%s res:%d\n", wav_filename, res);
        // exit(0);
    }

    // Cleanup KeywordSpotter after processing all files
    ret = keyword_spotter.KwsDestory();
    if (ret != 0) {
        printf("kws2k2 KwsDestory err\n");
    }

    printf("cnt_success/cnt = %d/%d\n",cnt_success, cnt);
    printf("all_cnt:%d\n",cnt_success);

    FILE *fplog = fopen("logs/result.txt","a");
    fprintf(fplog,"%s %d\n", TEST_LIST_FILE, cnt_success);
    fclose(fplog);
}
